import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

const US_CITIES = [
  { name: 'Seattle', state: 'WA' },
  { name: 'Austin', state: 'TX' },
  { name: 'Miami', state: 'FL' },
  { name: 'Los Angeles', state: 'CA' },
  { name: 'New York', state: 'NY' },
  { name: 'Chicago', state: 'IL' },
];

const EU_CITIES = [
  { name: 'Munich', country: 'Germany' },
  { name: 'Milan', country: 'Italy' },
  { name: 'London', country: 'UK' },
  { name: 'Madrid', country: 'Spain' },
  { name: 'Berlin', country: 'Germany' },
  { name: 'Paris', country: 'France' },
  { name: 'Warsaw', country: 'Poland' },
  { name: 'Brussels', country: 'Belgium' },
];

const BMW_MODELS_2026 = [
  { name: '3 Series', color: 'Frozen Pure Grey', mods: ['Lowered suspension', 'M Sport wheels'] },
  { name: 'M340i', color: 'San Remo Green', mods: ['Stage 1 tune', 'Carbon fiber trim', 'Upgraded exhaust'] },
  { name: '4 Series', color: 'Mineral White', mods: ['Stock build'] },
  { name: 'M440i', color: 'Brooklyn Grey', mods: ['M Sport package', 'Carbon brakes'] },
  { name: '5 Series', color: 'Black Sapphire', mods: ['Premium wheels', 'Tinted windows'] },
  { name: 'M550i', color: 'Tanzanite Blue', mods: ['Stage 2 tune', 'Carbon hood', 'Track pads'] },
  { name: '7 Series', color: 'Frozen Pure White', mods: ['Luxury package', 'Air suspension'] },
  { name: 'i4', color: 'Mystic Bronze', mods: ['Performance software', 'Racing suspension'] },
  { name: 'X3', color: 'Phytonic Blue', mods: ['All-terrain tires', 'Roof rack'] },
  { name: 'X5 M50i', color: 'Mineral Grey', mods: ['M Sport suspension', 'Ceramic brakes', 'Stage 2 ECU'] },
  { name: 'X7', color: 'Alpine White', mods: ['Premium package', 'Panoramic roof'] },
  { name: 'Z4', color: 'Deep Sea Blue', mods: ['M Performance exhaust', 'Track suspension', 'Carbon spoiler'] },
  { name: 'M440i xDrive', color: 'Frozen Brilliant White', mods: ['M Package', 'Carbon wheels'] },
  { name: 'M340i sedan', color: 'Sochi Sapphire', mods: ['M Sport differential', 'Upgraded pads'] },
  { name: 'M2', color: 'Alpine White', mods: ['Carbon fiber wing', 'Adjusted suspension', 'Braided brake lines'] },
];

const FIRST_NAMES_US = ['James', 'Michael', 'David', 'Ryan', 'Chris', 'John', 'Alex', 'Kevin', 'Jason', 'Brian', 'Sarah', 'Emily', 'Jessica', 'Amanda', 'Jennifer'];
const LAST_NAMES_US = ['Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Miller', 'Davis', 'Wilson', 'Moore', 'Taylor', 'Anderson', 'Thomas', 'Jackson', 'Martin', 'Garcia'];

const FIRST_NAMES_EU = ['Hans', 'Lukas', 'Marco', 'Paolo', 'Giorgio', 'Stefan', 'Klaus', 'Thomas', 'Heinrich', 'Wolfgang', 'Anna', 'Maria', 'Sophie', 'Elena', 'Lucia'];
const LAST_NAMES_EU = ['Mueller', 'Schmidt', 'Rossi', 'Ferrari', 'Bianchi', 'Weber', 'Keller', 'Hoffman', 'Novak', 'Kowalski', 'Dubois', 'Garcia', 'Sanchez', 'Martinez', 'Petrov'];

const BIOS_TEMPLATE = [
  'BMW enthusiast since {year}. Track days on weekends. 0-60 addict.',
  'M-series lover. Autobahn dreams. Coffee and horsepower.',
  'Weekend warrior. {model} owner. Always tuning something.',
  'Performance over everything. {model} is my therapy.',
  'German engineering believer. {series} fan for life.',
  'Track day warrior. Road legality is optional.',
  'Modding junkie. {model} never stops evolving.',
];

const HIGHLIGHTS = [
  [
    'Daily driver to track beast.',
    'Upgraded to Stage 2 this month.',
    'Looking for Nürburgring buddies.',
    'DM for local meetups!'
  ],
  [
    'Just broke in new brake pads.',
    'Loving the new suspension setup.',
    'Track days every other weekend.',
    'Always looking for car buddies.'
  ],
  [
    'Autobahn runs on the horizon.',
    'Fresh carbon fiber upgrades.',
    'Looking to join a local club.',
    'Hit me up for car meets!'
  ],
  [
    'Twin turbo dreams incoming.',
    'Current build is stage one.',
    'Weekend track warrior.',
    'Seeking car crew in {city}.'
  ],
  [
    'Performance is the goal.',
    'Every mod counts.',
    'Club meetings are life.',
    'Let\'s meet up soon!'
  ],
  [
    'From stock to screaming machine.',
    'Handling upgrades made all the difference.',
    'Need new pads soon.',
    'Who\'s in for a cruise?'
  ],
  [
    'Engine bay is my happy place.',
    'Tuning is an art form.',
    'Looking for local enthusiasts.',
    'DM me your mod list!'
  ]
];

const VIDEO_URLS = [
  { type: 'walkaround', url: 'youtu.be/demo-walkaround-{id}' },
  { type: 'exhaust', url: 'youtu.be/exhaust-note-{id}' },
  { type: 'acceleration', url: 'youtu.be/0-60-test-{id}' },
  { type: 'review', url: 'youtu.be/full-review-{id}' },
  { type: 'interior', url: 'youtu.be/interior-tour-{id}' },
  { type: 'engine', url: 'youtu.be/engine-bay-{id}' }
];

const BMW_STOCK_PHOTOS = [
  'https://images.bmwgroup.com/images/1920x1080/M3_exterior.jpg',
  'https://images.bmwgroup.com/images/1920x1080/M340i_side.jpg',
  'https://images.bmwgroup.com/images/1920x1080/X5_profile.jpg',
  'https://images.bmwgroup.com/images/1920x1080/Z4_angle.jpg',
  'https://images.bmwgroup.com/images/1920x1080/i4_modern.jpg',
  'https://images.bmwgroup.com/images/1920x1080/M440i_dynamic.jpg',
];

const INTERIOR_PHOTOS = [
  'https://images.bmwgroup.com/images/1920x1080/interior_dash_leather.jpg',
  'https://images.bmwgroup.com/images/1920x1080/interior_cockpit_digital.jpg',
  'https://images.bmwgroup.com/images/1920x1080/M_sport_interior.jpg',
  'https://images.bmwgroup.com/images/1920x1080/premium_seats.jpg',
];

const ENGINE_PHOTOS = [
  'https://images.bmwgroup.com/images/1920x1080/engine_bay_m340.jpg',
  'https://images.bmwgroup.com/images/1920x1080/turbocharged_powerplant.jpg',
  'https://images.bmwgroup.com/images/1920x1080/engine_detail.jpg',
  'https://images.bmwgroup.com/images/1920x1080/m_engine_x.jpg',
];

function getRandomItem(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function generateUsername(firstName, lastName, location) {
  const locationCode = location.slice(-2).toUpperCase();
  const modelIndex = Math.floor(Math.random() * 5);
  const adjectives = ['Lover', 'Fan', 'King', 'Head', 'Master', 'Pro'];
  return `${firstName}${getRandomItem(adjectives)}_${locationCode}`.replace(/\s/g, '');
}

function generateEmail(firstName, lastName, idx) {
  return `demo${idx}@mflight.local`.toLowerCase();
}

function generateBio(bmwModel, year, location) {
  const bio = getRandomItem(BIOS_TEMPLATE)
    .replace('{year}', (2026 - Math.floor(Math.random() * 15)).toString())
    .replace('{model}', bmwModel.name)
    .replace('{series}', bmwModel.name.split(' ')[0]);
  return bio;
}

function generateHighlight(bmwModel, city) {
  const template = getRandomItem(HIGHLIGHTS);
  return template.map(line => 
    line.replace('{city}', city)
           .replace('{model}', bmwModel.name)
  );
}

async function createDemoProfile(base44, idx) {
  const isUSProfile = Math.random() > 0.4;
  const location = isUSProfile 
    ? getRandomItem(US_CITIES) 
    : getRandomItem(EU_CITIES);
  
  const locationStr = isUSProfile 
    ? `${location.name}, ${location.state}` 
    : `${location.name}, ${location.country}`;
  
  const firstName = isUSProfile 
    ? getRandomItem(FIRST_NAMES_US) 
    : getRandomItem(FIRST_NAMES_EU);
  const lastName = isUSProfile 
    ? getRandomItem(LAST_NAMES_US) 
    : getRandomItem(LAST_NAMES_EU);
  
  const fullName = `${firstName} ${lastName}`;
  const username = generateUsername(firstName, lastName, locationStr);
  const email = generateEmail(firstName, lastName, idx);
  
  const bmwModel = getRandomItem(BMW_MODELS_2026);
  const year = 2023 + Math.floor(Math.random() * 4);
  const mileage = 20000 + Math.floor(Math.random() * 60000);
  
  const carName = `${fullName}'s ${year} ${bmwModel.name}`;
  
  // Create Garage
  const garage = await base44.asServiceRole.entities.Garage.create({
    name: `${fullName}'s Garage`,
    description: `Home base for ${fullName}'s ${bmwModel.name}`,
    owner_email: email,
    owner_name: fullName,
    cover_image: getRandomItem(BMW_STOCK_PHOTOS),
    car_ids: []
  });

  // Create Car
  const car = await base44.asServiceRole.entities.Car.create({
    name: carName,
    make: 'BMW',
    model: bmwModel.name,
    year: year,
    color: bmwModel.color,
    owner_email: email,
    owner_name: fullName,
    garage_id: garage.id,
    image_url: getRandomItem(BMW_STOCK_PHOTOS),
    specifications: {
      engine: `3.0L Twin-Turbo Inline-6`,
      horsepower: '382 hp',
      torque: '369 lb-ft',
      '0_to_60': '4.2s',
      top_speed: '155 mph (electronic limiter)',
      transmission: 'Automatic 8-speed',
      suspension: bmwModel.mods.includes('Stage 2 tune') ? 'Lowered M Sport' : 'Standard',
      wheels: '19-inch M Sport wheels'
    },
    mods: bmwModel.mods.map((mod, midx) => ({
      id: `mod-${idx}-${midx}`,
      name: mod,
      category: mod.includes('tune') ? 'Engine' : mod.includes('wheel') || mod.includes('suspension') ? 'Suspension' : 'Other',
      description: `${mod} modification`,
      cost: `$${500 + Math.floor(Math.random() * 3000)}`,
      installation_date: `2024-${String(Math.floor(Math.random() * 12) + 1).padStart(2, '0')}-01`
    })),
    performance_metrics: [
      {
        id: 'perf-1',
        date: new Date().toISOString().split('T')[0],
        zero_to_60: 4.2 + (Math.random() * 0.5),
        top_speed: 155,
        quarter_mile: 12.5 + (Math.random() * 0.3),
        notes: 'Fresh tires, optimal conditions'
      }
    ],
    total_investment: `$${3000 + Math.floor(Math.random() * 8000)}`
  });

  // Add car to garage
  await base44.asServiceRole.entities.Garage.update(garage.id, {
    car_ids: [car.id]
  });

  // Create GarageItems (mods as inventory items)
  for (const mod of bmwModel.mods.slice(0, 2)) {
    await base44.asServiceRole.entities.GarageItem.create({
      garage_id: garage.id,
      owner_email: email,
      category: 'part',
      name: mod,
      brand: 'Performance',
      description: `${mod} for my ${bmwModel.name}`,
      image_url: getRandomItem(ENGINE_PHOTOS),
      purchase_date: `2024-${String(Math.floor(Math.random() * 12) + 1).padStart(2, '0')}-01`,
      condition: Math.random() > 0.7 ? 'excellent' : 'new',
      specifications: { fitment: bmwModel.name, material: 'Carbon fiber' }
    });
  }

  // Create GarageVideos
  const videoCount = Math.random() > 0.5 ? 2 : 1;
  for (let v = 0; v < videoCount; v++) {
    const videoTemplate = getRandomItem(VIDEO_URLS);
    await base44.asServiceRole.entities.GarageVideo.create({
      garage_id: garage.id,
      owner_email: email,
      youtube_video_id: `demo${idx}v${v}`,
      youtube_url: videoTemplate.url.replace('{id}', `${idx}-${v}`),
      title: `${fullName} ${bmwModel.name} - ${videoTemplate.type}`,
      category: videoTemplate.type,
      description: `Check out my ${year} ${bmwModel.name} in action`,
      views: Math.floor(Math.random() * 500)
    });
  }

  // Create Post (highlight)
  const highlight = generateHighlight(bmwModel, location.name);
  await base44.asServiceRole.entities.Post.create({
    content: highlight.join('\n'),
    author_name: fullName,
    author_email: email,
    author_avatar: `https://ui-avatars.com/api/?name=${fullName}&background=0066B1&color=fff`,
    image_url: getRandomItem(INTERIOR_PHOTOS),
    likes: [],
    comments: [],
    shares_count: 0
  });

  return {
    username,
    email,
    fullName,
    location: locationStr,
    car: `${year} ${bmwModel.name} (${bmwModel.color})`,
    mileage: `${mileage.toLocaleString()} miles`,
    garageId: garage.id,
    carId: car.id
  };
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (user?.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    const profiles = [];
    for (let i = 0; i < 50; i++) {
      const profile = await createDemoProfile(base44, i);
      profiles.push(profile);
      console.log(`Created profile ${i + 1}/50: ${profile.username}`);
    }

    return Response.json({
      success: true,
      message: '50 demo profiles created successfully',
      profileCount: profiles.length,
      sample: profiles.slice(0, 5),
      summary: {
        totalProfiles: profiles.length,
        totalGarages: profiles.length,
        totalCars: profiles.length,
        totalPosts: profiles.length
      }
    });
  } catch (error) {
    console.error('Error generating demo content:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});