import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { ThumbsUp, MessageCircle, UserPlus, UserCheck, MoreHorizontal, Settings, CheckCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { formatDistanceToNow } from 'date-fns';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion, AnimatePresence } from 'framer-motion';

const notificationIcons = {
  like: ThumbsUp,
  comment: MessageCircle,
  friend_request: UserPlus,
  friend_accepted: UserCheck,
};

const iconColors = {
  like: 'bg-[#1877F2] text-white',
  comment: 'bg-green-500 text-white',
  friend_request: 'bg-[#1877F2] text-white',
  friend_accepted: 'bg-[#1877F2] text-white',
};

function NotificationItem({ notification, onMarkAsRead }) {
  const Icon = notificationIcons[notification.type] || ThumbsUp;
  const avatar = notification.from_avatar || `https://ui-avatars.com/api/?name=${notification.from_name}&background=random`;

  const getLink = () => {
    if (notification.type === 'friend_request' || notification.type === 'friend_accepted') {
      return createPageUrl('Friends');
    }
    return createPageUrl('Home');
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
    >
      <Link
        to={getLink()}
        onClick={() => !notification.read && onMarkAsRead(notification.id)}
        className={`flex items-start gap-3 p-3 rounded-lg transition-colors ${
          notification.read ? 'hover:bg-gray-50' : 'bg-[#E7F3FF] hover:bg-[#D8E8F8]'
        }`}
      >
        <div className="relative flex-shrink-0">
          <img
            src={avatar}
            alt={notification.from_name}
            className="w-14 h-14 rounded-full object-cover"
          />
          <div className={`absolute -bottom-1 -right-1 w-7 h-7 rounded-full flex items-center justify-center ${iconColors[notification.type]}`}>
            <Icon className="w-4 h-4" />
          </div>
        </div>
        <div className="flex-1 min-w-0">
          <p className={`text-[15px] ${notification.read ? 'text-gray-700' : 'text-gray-900'}`}>
            <span className="font-semibold">{notification.from_name}</span>{' '}
            {notification.message.replace(notification.from_name, '').trim()}
          </p>
          <p className={`text-sm mt-0.5 ${notification.read ? 'text-gray-500' : 'text-[#1877F2] font-medium'}`}>
            {formatDistanceToNow(new Date(notification.created_date), { addSuffix: true })}
          </p>
        </div>
        {!notification.read && (
          <div className="w-3 h-3 bg-[#1877F2] rounded-full flex-shrink-0 mt-2" />
        )}
      </Link>
    </motion.div>
  );
}

export default function Notifications() {
  const [user, setUser] = useState(null);
  const [filter, setFilter] = useState('all');
  const queryClient = useQueryClient();

  useEffect(() => {
    const loadUser = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    };
    loadUser();
  }, []);

  const { data: notifications = [], isLoading } = useQuery({
    queryKey: ['notifications', user?.email],
    queryFn: () => base44.entities.Notification.filter({ user_email: user?.email }, '-created_date'),
    enabled: !!user?.email,
  });

  const markAsReadMutation = useMutation({
    mutationFn: (id) => base44.entities.Notification.update(id, { read: true }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['notifications'] }),
  });

  const markAllAsReadMutation = useMutation({
    mutationFn: async () => {
      const unread = notifications.filter(n => !n.read);
      await Promise.all(unread.map(n => base44.entities.Notification.update(n.id, { read: true })));
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['notifications'] }),
  });

  const filteredNotifications = filter === 'all' 
    ? notifications 
    : notifications.filter(n => !n.read);

  const unreadCount = notifications.filter(n => !n.read).length;

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#1877F2]" />
      </div>
    );
  }

  return (
    <div className="max-w-[680px] mx-auto p-4">
      <div className="bg-white rounded-xl shadow-sm overflow-hidden">
        <div className="p-4 border-b border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-bold text-gray-900">Notifications</h1>
            <div className="flex gap-2">
              {unreadCount > 0 && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => markAllAsReadMutation.mutate()}
                  className="text-[#1877F2] hover:bg-[#E7F3FF]"
                >
                  <CheckCheck className="w-4 h-4 mr-2" />
                  Mark all as read
                </Button>
              )}
              <button className="p-2 hover:bg-gray-100 rounded-full">
                <MoreHorizontal className="w-5 h-5 text-gray-600" />
              </button>
            </div>
          </div>
          
          <div className="flex gap-2">
            <Button
              variant={filter === 'all' ? 'default' : 'secondary'}
              size="sm"
              onClick={() => setFilter('all')}
              className={filter === 'all' ? 'bg-[#E7F3FF] text-[#1877F2] hover:bg-[#D8E8F8]' : ''}
            >
              All
            </Button>
            <Button
              variant={filter === 'unread' ? 'default' : 'secondary'}
              size="sm"
              onClick={() => setFilter('unread')}
              className={filter === 'unread' ? 'bg-[#E7F3FF] text-[#1877F2] hover:bg-[#D8E8F8]' : ''}
            >
              Unread
            </Button>
          </div>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#1877F2]" />
          </div>
        ) : filteredNotifications.length > 0 ? (
          <div className="divide-y divide-gray-50">
            <AnimatePresence>
              {filteredNotifications.map((notification) => (
                <NotificationItem
                  key={notification.id}
                  notification={notification}
                  onMarkAsRead={(id) => markAsReadMutation.mutate(id)}
                />
              ))}
            </AnimatePresence>
          </div>
        ) : (
          <div className="text-center py-12">
            <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Settings className="w-8 h-8 text-gray-400" />
            </div>
            <h2 className="text-xl font-semibold text-gray-900 mb-1">
              {filter === 'unread' ? 'No unread notifications' : 'No notifications yet'}
            </h2>
            <p className="text-gray-500">
              {filter === 'unread' 
                ? 'You\'re all caught up!' 
                : 'When you get notifications, they\'ll show up here'}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}