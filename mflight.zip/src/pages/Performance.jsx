import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { Plus, Upload, TrendingUp, Gauge, Wrench, Settings, Music, Wind, Palette, Cpu, ChevronRight, Calendar, DollarSign } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const modCategories = [
  { id: 'engine', label: 'Engine', icon: Settings, color: 'text-red-500', bg: 'bg-red-500/10' },
  { id: 'suspension', label: 'Suspension', icon: TrendingUp, color: 'text-blue-500', bg: 'bg-blue-500/10' },
  { id: 'wheels', label: 'Wheels & Tires', icon: Gauge, color: 'text-purple-500', bg: 'bg-purple-500/10' },
  { id: 'exhaust', label: 'Exhaust', icon: Wind, color: 'text-orange-500', bg: 'bg-orange-500/10' },
  { id: 'body', label: 'Body Kit', icon: Palette, color: 'text-pink-500', bg: 'bg-pink-500/10' },
  { id: 'audio', label: 'Audio System', icon: Music, color: 'text-cyan-500', bg: 'bg-cyan-500/10' },
  { id: 'electronics', label: 'Electronics', icon: Cpu, color: 'text-green-500', bg: 'bg-green-500/10' },
];

// Demo Data
const demoCar = {
  id: 'demo-1',
  name: 'Thunder',
  year: 2021,
  model: 'M3 Competition',
  make: 'BMW',
  mods: [
    {
      id: '1',
      category: 'engine',
      name: 'BMS N55 Performance Intake',
      description: 'High-flow cold air intake system providing improved throttle response and increased horsepower. Reduces intake air temperatures by 15-20°F.',
      specifications: 'Part #: BMS-N55-INT | Material: Carbon Fiber | Filter: Dry Flow',
      cost: '$549',
      installation_date: '2023-03-15',
      before_image: 'https://images.unsplash.com/photo-1486262715619-67b85e0b08d3?w=800',
      after_image: 'https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?w=800'
    },
    {
      id: '2',
      category: 'engine',
      name: 'Bootmod3 Stage 2+ Tune',
      description: 'Custom ECU tuning optimized for 93 octane fuel. Aggressive boost curves and torque management for maximum performance.',
      specifications: 'Target: 480HP / 520TQ | 93 Octane Required | Rev Limit: 7200 RPM',
      cost: '$650',
      installation_date: '2023-04-02',
      before_image: 'https://images.unsplash.com/photo-1619642751034-765dfdf7c58e?w=800',
      after_image: 'https://images.unsplash.com/photo-1621939514649-280e2ee25f60?w=800'
    },
    {
      id: '3',
      category: 'suspension',
      name: 'KW V3 Coilover System',
      description: 'Independently adjustable compression and rebound damping. Height adjustable from -0.4" to -2.4" front and rear.',
      specifications: 'Model: KW 35220087 | Adjustable Rebound: 16 Clicks | Load Capacity: 1190 lbs',
      cost: '$2,899',
      installation_date: '2023-05-10',
      before_image: 'https://images.unsplash.com/photo-1609521263047-f8f205293f24?w=800',
      after_image: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800'
    },
    {
      id: '4',
      category: 'suspension',
      name: 'Ground Control Camber Plates',
      description: 'Allows -3.5° to +1° camber adjustment. Spherical bearings eliminate binding and provide precise feedback.',
      specifications: 'Part #: GC-CP-E9X | Material: Billet Aluminum | Bearing Type: Spherical',
      cost: '$425',
      installation_date: '2023-05-10'
    },
    {
      id: '5',
      category: 'wheels',
      name: 'Apex ARC-8 Forged Wheels',
      description: 'Lightweight forged aluminum construction. 19x9.5" front, 19x10.5" rear. Hyper Black finish.',
      specifications: '19x9.5 ET22 (F) | 19x10.5 ET25 (R) | Weight: 22.5 lbs | Finish: Hyper Black',
      cost: '$2,400',
      installation_date: '2023-06-20',
      before_image: 'https://images.unsplash.com/photo-1617814076367-b759c7d7e738?w=800',
      after_image: 'https://images.unsplash.com/photo-1625231334168-35067f8853ed?w=800'
    },
    {
      id: '6',
      category: 'wheels',
      name: 'Michelin Pilot Sport 4S Tires',
      description: 'Max performance summer tire with hybrid belt technology. 265/35/19 front, 295/30/19 rear.',
      specifications: '265/35ZR19 (F) | 295/30ZR19 (R) | Speed Rating: Y | UTQG: 300AA',
      cost: '$1,850',
      installation_date: '2023-06-20'
    },
    {
      id: '7',
      category: 'exhaust',
      name: 'Akrapovic Evolution Titanium Exhaust',
      description: 'Full titanium cat-back system. Weight savings of 26 lbs over stock. Valve-controlled for street/track modes.',
      specifications: 'Part #: S-BM/T/6H | Material: Grade 1 Titanium | Diameter: 3.5" | dB: 102',
      cost: '$5,200',
      installation_date: '2023-07-15',
      before_image: 'https://images.unsplash.com/photo-1621361365424-06f0e1eb5c49?w=800',
      after_image: 'https://images.unsplash.com/photo-1609521263047-f8f205293f24?w=800'
    },
    {
      id: '8',
      category: 'body',
      name: 'Vorsteiner VRS Carbon Fiber Aero Kit',
      description: 'Full carbon fiber aerodynamics package. Front splitter, side skirts, rear diffuser, and trunk spoiler.',
      specifications: 'Material: 2x2 Twill Weave Carbon Fiber | Finish: Clear Coat | Downforce: +145 lbs @ 150mph',
      cost: '$6,500',
      installation_date: '2023-08-22',
      before_image: 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=800',
      after_image: 'https://images.unsplash.com/photo-1617886903355-9354bb57751f?w=800'
    },
    {
      id: '9',
      category: 'audio',
      name: 'Harman Kardon Logic 7 Upgrade',
      description: 'Premium 16-speaker surround sound system. Digital amplifier with 600W total output.',
      specifications: 'Speakers: 16 | Amplifier: 600W | Subwoofer: 200W | Channels: 7.1',
      cost: '$2,100',
      installation_date: '2023-09-05'
    },
    {
      id: '10',
      category: 'electronics',
      name: 'AIM MXG 1.2 Dash Logger',
      description: 'Professional-grade digital dashboard with GPS lap timer and integrated data logging.',
      specifications: 'Display: 7" TFT | GPS: 25Hz | Channels: 56 | Sampling: 1000Hz',
      cost: '$1,950',
      installation_date: '2023-10-12',
      before_image: 'https://images.unsplash.com/photo-1563584697-1ac06f6a3e87?w=800',
      after_image: 'https://images.unsplash.com/photo-1605559424843-9e4c228bf1c2?w=800'
    }
  ],
  performance_metrics: [
    {
      id: '1',
      date: '2023-11-15',
      horsepower: 485,
      torque: 525,
      zero_to_sixty: 3.6,
      quarter_mile: 11.8,
      top_speed: 180,
      notes: 'Dyno run at sea level, 72°F ambient temperature. 93 octane fuel. Stage 2+ tune with full bolt-ons.'
    }
  ]
};

export default function Performance() {
  const [selectedCategory, setSelectedCategory] = useState('engine');

  const categoryIcon = modCategories.find(c => c.id === selectedCategory)?.icon || Settings;
  const CategoryIcon = categoryIcon;
  const filteredMods = demoCar.mods.filter(mod => mod.category === selectedCategory);
  const latestDyno = demoCar.performance_metrics[0];

  return (
    <div className="min-h-screen bg-black text-white pb-20">
      {/* Header */}
      <div className="border-b border-gray-900 bg-black/50 backdrop-blur-sm sticky top-20 z-40">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-2xl font-light uppercase tracking-wider mb-2">Performance Demo</h1>
              <p className="text-gray-500 text-xs uppercase tracking-wider">Example build showcase</p>
            </div>
          </div>

          {/* Demo Car Display */}
          <div className="px-6 py-4 border-2 border-[#0066B1] bg-[#0066B1]/10">
            <div className="flex items-center gap-3">
              <div className="text-left">
                <p className="text-white text-sm font-medium uppercase tracking-wider">{demoCar.name}</p>
                <p className="text-gray-400 text-xs uppercase tracking-wider">{demoCar.year} {demoCar.make} {demoCar.model}</p>
              </div>
              <div className="ml-auto">
                <span className="text-xs text-[#0066B1] uppercase tracking-wider bg-[#0066B1]/20 px-3 py-1 border border-[#0066B1]">
                  Demo Vehicle
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Latest Dyno Stats */}
        {latestDyno && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8"
          >
            <div className="bg-gray-950 border border-gray-900 p-6">
              <p className="text-gray-500 text-xs uppercase tracking-wider mb-2">Horsepower</p>
              <p className="text-3xl font-light text-[#E22718]">{latestDyno.horsepower}</p>
              <p className="text-gray-600 text-xs uppercase tracking-wider mt-1">HP</p>
            </div>
            <div className="bg-gray-950 border border-gray-900 p-6">
              <p className="text-gray-500 text-xs uppercase tracking-wider mb-2">Torque</p>
              <p className="text-3xl font-light text-[#0066B1]">{latestDyno.torque}</p>
              <p className="text-gray-600 text-xs uppercase tracking-wider mt-1">LB-FT</p>
            </div>
            <div className="bg-gray-950 border border-gray-900 p-6">
              <p className="text-gray-500 text-xs uppercase tracking-wider mb-2">0-60</p>
              <p className="text-3xl font-light text-white">{latestDyno.zero_to_sixty}</p>
              <p className="text-gray-600 text-xs uppercase tracking-wider mt-1">SEC</p>
            </div>
            <div className="bg-gray-950 border border-gray-900 p-6">
              <p className="text-gray-500 text-xs uppercase tracking-wider mb-2">1/4 Mile</p>
              <p className="text-3xl font-light text-white">{latestDyno.quarter_mile}</p>
              <p className="text-gray-600 text-xs uppercase tracking-wider mt-1">SEC</p>
            </div>
            <div className="bg-gray-950 border border-gray-900 p-6">
              <p className="text-gray-500 text-xs uppercase tracking-wider mb-2">Top Speed</p>
              <p className="text-3xl font-light text-white">{latestDyno.top_speed}</p>
              <p className="text-gray-600 text-xs uppercase tracking-wider mt-1">MPH</p>
            </div>
          </motion.div>
        )}

        {/* Mod Categories - Horizontal */}
        <div className="mb-8">
          <h3 className="text-xs font-medium text-white mb-4 uppercase tracking-widest">Mod Categories</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
            {modCategories.map((category) => {
              const Icon = category.icon;
              const count = demoCar.mods.filter(m => m.category === category.id).length;
              return (
                <button
                  key={category.id}
                  onClick={() => setSelectedCategory(category.id)}
                  className={`flex flex-col items-center justify-center p-4 transition-all border ${
                    selectedCategory === category.id
                      ? `${category.bg} border-gray-800`
                      : 'bg-gray-950 border-gray-900 hover:border-gray-800'
                  }`}
                >
                  <Icon className={`w-6 h-6 mb-2 ${category.color}`} />
                  <span className="text-xs text-white uppercase tracking-wider text-center">{category.label}</span>
                  {count > 0 && (
                    <span className="text-xs text-gray-500 bg-gray-900 px-2 py-0.5 mt-2 rounded">{count}</span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Mods List */}
        <div>
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <CategoryIcon className={modCategories.find(c => c.id === selectedCategory)?.color} />
                <h2 className="text-xl font-light uppercase tracking-wider">
                  {modCategories.find(c => c.id === selectedCategory)?.label}
                </h2>
              </div>

            </div>

            {filteredMods.length === 0 ? (
              <div className="bg-gray-950 border border-gray-900 p-12 text-center">
                <CategoryIcon className="w-12 h-12 text-gray-700 mx-auto mb-4" />
                <p className="text-gray-600 text-sm uppercase tracking-wider">No modifications yet</p>
              </div>
            ) : (
              <div className="space-y-4">
                {filteredMods.map((mod) => (
                  <motion.div
                    key={mod.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-gray-950 border border-gray-900 p-6 hover:border-gray-800 transition-all"
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="text-lg font-medium text-white uppercase tracking-wide mb-1">{mod.name}</h3>
                        {mod.installation_date && (
                          <div className="flex items-center gap-2 text-gray-500 text-xs">
                            <Calendar className="w-3 h-3" />
                            <span className="uppercase tracking-wider">{new Date(mod.installation_date).toLocaleDateString()}</span>
                          </div>
                        )}
                      </div>
                      {mod.cost && (
                        <div className="flex items-center gap-1 text-[#0066B1]">
                          <DollarSign className="w-4 h-4" />
                          <span className="text-sm font-medium">{mod.cost}</span>
                        </div>
                      )}
                    </div>

                    {mod.description && (
                      <p className="text-gray-400 text-sm mb-4 leading-relaxed">{mod.description}</p>
                    )}

                    {mod.specifications && (
                      <div className="bg-black border border-gray-900 p-4 mb-4">
                        <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">Specifications</p>
                        <p className="text-white text-sm">{mod.specifications}</p>
                      </div>
                    )}

                    {(mod.before_image || mod.after_image) && (
                      <div className="grid grid-cols-2 gap-4">
                        {mod.before_image && (
                          <div>
                            <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">Before</p>
                            <img src={mod.before_image} alt="Before" className="w-full h-48 object-cover border border-gray-800" />
                          </div>
                        )}
                        {mod.after_image && (
                          <div>
                            <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">After</p>
                            <img src={mod.after_image} alt="After" className="w-full h-48 object-cover border border-gray-800" />
                          </div>
                        )}
                      </div>
                    )}
                  </motion.div>
                ))}
              </div>
            )}
        </div>
      </div>


    </div>
  );
}