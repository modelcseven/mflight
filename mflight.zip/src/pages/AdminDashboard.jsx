import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { Users, Activity, ShoppingCart, Calendar, TrendingUp, Eye, MessageCircle, FileText } from 'lucide-react';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const COLORS = ['#0066B1', '#E22718', '#00C853', '#FFB300', '#9C27B0'];

export default function AdminDashboard() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const loadUser = async () => {
      const currentUser = await base44.auth.me();
      if (!currentUser || currentUser.role !== 'admin') {
        window.location.href = createPageUrl('Home');
        return;
      }
      setUser(currentUser);
    };
    loadUser();
  }, []);

  const { data: users = [] } = useQuery({
    queryKey: ['all-users'],
    queryFn: () => base44.entities.User.list(),
  });

  const { data: posts = [] } = useQuery({
    queryKey: ['all-posts'],
    queryFn: () => base44.entities.Post.list('-created_date', 100),
  });

  const { data: listings = [] } = useQuery({
    queryKey: ['all-listings'],
    queryFn: () => base44.entities.MarketplaceListing.list(),
  });

  const { data: analytics = [] } = useQuery({
    queryKey: ['analytics'],
    queryFn: () => base44.entities.SiteAnalytics.list('-date', 30),
  });

  if (!user) return null;

  const stats = [
    { label: 'Total Users', value: users.length, icon: Users, color: '#0066B1' },
    { label: 'Total Posts', value: posts.length, icon: FileText, color: '#E22718' },
    { label: 'Active Listings', value: listings.filter(l => l.status === 'active').length, icon: ShoppingCart, color: '#00C853' },
    { label: 'Total Views', value: analytics.reduce((sum, a) => sum + (a.page_views || 0), 0), icon: Eye, color: '#FFB300' }
  ];

  const userGrowth = analytics.slice(0, 14).reverse().map(a => ({
    date: new Date(a.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
    users: a.new_users || 0
  }));

  const activityData = [
    { name: 'Posts', value: posts.length },
    { name: 'Listings', value: listings.length },
    { name: 'Users', value: users.length }
  ];

  return (
    <div className="min-h-screen bg-black text-white pb-20">
      <div className="max-w-7xl mx-auto px-6 py-12">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-12">
          <h1 className="text-4xl font-light uppercase tracking-wider mb-2">Admin Dashboard</h1>
          <p className="text-gray-500 text-sm uppercase tracking-wider">Platform Overview & Management</p>
        </motion.div>

        {/* Quick Links */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
          <Link to={createPageUrl('AdminCMS')} className="bg-gray-950 border border-gray-900 p-6 hover:border-[#0066B1] transition-colors">
            <FileText className="w-8 h-8 mb-3 text-[#0066B1]" />
            <h3 className="text-sm uppercase tracking-wider">CMS</h3>
          </Link>
          <Link to={createPageUrl('AdminCRM')} className="bg-gray-950 border border-gray-900 p-6 hover:border-[#E22718] transition-colors">
            <Users className="w-8 h-8 mb-3 text-[#E22718]" />
            <h3 className="text-sm uppercase tracking-wider">CRM</h3>
          </Link>
          <Link to={createPageUrl('AdminMarketing')} className="bg-gray-950 border border-gray-900 p-6 hover:border-[#00C853] transition-colors">
            <TrendingUp className="w-8 h-8 mb-3 text-[#00C853]" />
            <h3 className="text-sm uppercase tracking-wider">Marketing</h3>
          </Link>
          <Link to={createPageUrl('AdminAPIs')} className="bg-gray-950 border border-gray-900 p-6 hover:border-[#FFB300] transition-colors">
            <Activity className="w-8 h-8 mb-3 text-[#FFB300]" />
            <h3 className="text-sm uppercase tracking-wider">APIs</h3>
          </Link>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
          {stats.map((stat, idx) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className="bg-gray-950 border border-gray-900 p-6"
            >
              <div className="flex items-center justify-between mb-4">
                <stat.icon className="w-8 h-8" style={{ color: stat.color }} />
              </div>
              <div className="text-4xl font-light mb-2">{stat.value.toLocaleString()}</div>
              <div className="text-xs text-gray-500 uppercase tracking-wider">{stat.label}</div>
            </motion.div>
          ))}
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
          <div className="bg-gray-950 border border-gray-900 p-6">
            <h3 className="text-sm uppercase tracking-wider text-gray-400 mb-6">User Growth (14 Days)</h3>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={userGrowth}>
                <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                <XAxis dataKey="date" tick={{ fill: '#999' }} />
                <YAxis tick={{ fill: '#999' }} />
                <Tooltip contentStyle={{ backgroundColor: '#000', border: '1px solid #333' }} />
                <Line type="monotone" dataKey="users" stroke="#0066B1" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="bg-gray-950 border border-gray-900 p-6">
            <h3 className="text-sm uppercase tracking-wider text-gray-400 mb-6">Platform Activity</h3>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie data={activityData} cx="50%" cy="50%" labelLine={false} outerRadius={100} fill="#8884d8" dataKey="value" label>
                  {activityData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ backgroundColor: '#000', border: '1px solid #333' }} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Recent Activity */}
        <div className="bg-gray-950 border border-gray-900 p-6">
          <h3 className="text-sm uppercase tracking-wider text-gray-400 mb-6">Recent Posts</h3>
          <div className="space-y-3">
            {posts.slice(0, 5).map(post => (
              <div key={post.id} className="bg-black/50 border border-gray-900 p-4 flex items-center justify-between">
                <div>
                  <p className="font-medium mb-1">{post.author_name}</p>
                  <p className="text-sm text-gray-500 line-clamp-1">{post.content}</p>
                </div>
                <span className="text-xs text-gray-600">{new Date(post.created_date).toLocaleDateString()}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}