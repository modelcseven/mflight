import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Settings, Gauge, Activity, AlertTriangle, TrendingUp, Download, Thermometer, Zap, Target } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { 
  RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis, 
  BarChart, Bar, LineChart, Line, AreaChart, Area, ComposedChart,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  PieChart, Pie, Cell, Scatter, ScatterChart
} from 'recharts';

const modelData = {
  'M Performance': {
    engine: { 
      hp: 382, torque: 369, zeroToSixty: 4.1, quarterMile: 12.8, mpg: '23/32', 
      oilTemp: 98, oilPressure: 65, boost: 18, afr: 12.2, ignitionTiming: 12, 
      iat: 35, knockCount: 2, revLimit: 7000, turboSpeed: 180000, 
      compressorTemp: 85, fuelTrim: 3, risk: 12 
    },
    transmission: { 
      shiftTime: 150, gearRatios: '5.25/3.36/2.17/1.72/1.32/1.00/0.82/0.64', 
      fluidTemp: 85, clutchWear: 5, lockupSpeed: 1200, drivelogicMode: 'Sport+', risk: 8 
    },
    differential: { 
      lockingPct: 0, gearRatio: 3.15, oilTemp: 90, torqueBias: 1.0, 
      wearRate: 3, tractionGain: 0, lsdType: 'Open' 
    },
    tires: { grip: 1.15, treadWear: 300, rollResist: 8.5, dryBrake: 105, wetBrake: 125, riskIncrease: 8 },
    rims: { weight: 28, diameter: 19, width: 9.5, strength: 95, drag: 0.32, crackRisk: 5 },
    suspension: { damping: 4200, stiffness: 450, rideHeight: -15, corneringG: 1.08, strainRate: 10 },
    brakes: { rotorSize: 348, friction: 0.42, stoppingDist: 122, fadeResist: 8, heatDissipation: 85, padTemp: 220, rotorTemp: 280 },
    electronics: { ecuResponse: 45, batteryDrain: 2.8, compatibility: 92, errorFreq: 0.3, modReliability: 88, flashCount: 0, dmeUnlocked: false },
    audio: { power: 205, freqResponse: '20-20k', distortion: 0.8, speakerCount: 10, isolation: 68 }
  },
  'Full M': {
    engine: { 
      hp: 503, torque: 479, zeroToSixty: 3.4, quarterMile: 11.5, mpg: '16/23', 
      oilTemp: 102, oilPressure: 70, boost: 24, afr: 11.8, ignitionTiming: 15, 
      iat: 32, knockCount: 1, revLimit: 7200, turboSpeed: 220000, 
      compressorTemp: 95, fuelTrim: 2, risk: 8 
    },
    transmission: { 
      shiftTime: 100, gearRatios: '5.25/3.36/2.17/1.72/1.32/1.00/0.82/0.64', 
      fluidTemp: 88, clutchWear: 3, lockupSpeed: 1000, drivelogicMode: 'Sport+', risk: 5 
    },
    differential: { 
      lockingPct: 100, gearRatio: 3.15, oilTemp: 95, torqueBias: 1.5, 
      wearRate: 2, tractionGain: 15, lsdType: 'Active M' 
    },
    tires: { grip: 1.25, treadWear: 200, rollResist: 9.2, dryBrake: 98, wetBrake: 115, riskIncrease: 5 },
    rims: { weight: 24, diameter: 20, width: 10.5, strength: 98, drag: 0.30, crackRisk: 3 },
    suspension: { damping: 5800, stiffness: 620, rideHeight: -20, corneringG: 1.18, strainRate: 6 },
    brakes: { rotorSize: 380, friction: 0.48, stoppingDist: 108, fadeResist: 12, heatDissipation: 95, padTemp: 240, rotorTemp: 300 },
    electronics: { ecuResponse: 38, batteryDrain: 3.2, compatibility: 96, errorFreq: 0.2, modReliability: 94, flashCount: 0, dmeUnlocked: false },
    audio: { power: 464, freqResponse: '20-20k', distortion: 0.4, speakerCount: 16, isolation: 75 }
  }
};

const COLORS = ['#0066B1', '#E22718', '#00C853', '#FFB300', '#9C27B0'];

export default function PerformanceDashboard() {
  const [selectedModel, setSelectedModel] = useState('M Performance');
  const [modLevel, setModLevel] = useState(0);
  const [activeTab, setActiveTab] = useState('overview');
  const [dynoMode, setDynoMode] = useState(false);
  const [driveMode, setDriveMode] = useState('street');
  const [stage, setStage] = useState(0);

  const data = modelData[selectedModel];
  
  const overallScore = Math.round(
    (data.engine.hp / 6 + data.tires.grip * 80 + data.suspension.corneringG * 80 + 
     data.brakes.fadeResist * 7.5 + data.electronics.compatibility * 0.9) / 5
  );

  const riskLevel = data.engine.risk + modLevel > 20 ? 'high' : 
                    data.engine.risk + modLevel > 10 ? 'medium' : 'low';

  const improvementPotential = 100 - overallScore;

  const spiderData = [
    { category: 'Engine', mPerf: 85, fullM: 95, maxScore: 100 },
    { category: 'Tires', mPerf: 82, fullM: 90, maxScore: 100 },
    { category: 'Suspension', mPerf: 80, fullM: 92, maxScore: 100 },
    { category: 'Brakes', mPerf: 78, fullM: 94, maxScore: 100 },
    { category: 'Electronics', mPerf: 88, fullM: 94, maxScore: 100 },
    { category: 'Audio', mPerf: 75, fullM: 88, maxScore: 100 },
  ];

  const engineComparisonData = [
    { name: 'Horsepower', mPerf: 382, fullM: 503 },
    { name: 'Torque', mPerf: 369, fullM: 479 },
    { name: '0-60 Time', mPerf: 4.1, fullM: 3.4 },
  ];

  // Stage-based gains
  const stageGains = {
    0: { hp: 0, torque: 0, cost: 0, mods: 'Stock' },
    1: { hp: 35, torque: 40, cost: 1500, mods: 'ECU Tune + Intake' },
    2: { hp: 70, torque: 75, cost: 3500, mods: 'Stage 1 + Intercooler + Exhaust' },
    3: { hp: 103, torque: 95, cost: 6000, mods: 'Stage 2 + Turbos + TCU Tune' }
  };

  const currentStageGain = stageGains[stage];
  const totalHP = data.engine.hp + currentStageGain.hp + Math.round(data.engine.hp * modLevel / 100);
  const totalTorque = data.engine.torque + currentStageGain.torque + Math.round(data.engine.torque * modLevel / 100);

  const accelerationCurve = [
    { speed: 0, stock: 0, stage1: 0, stage2: 0, stage3: 0 },
    { speed: 30, stock: 1.8, stage1: 1.7, stage2: 1.6, stage3: 1.5 },
    { speed: 60, stock: 4.1, stage1: 3.8, stage2: 3.5, stage3: 3.2 },
    { speed: 100, stock: 8.5, stage1: 7.9, stage2: 7.2, stage3: 6.6 },
    { speed: 130, stock: 14.2, stage1: 13.1, stage2: 12.0, stage3: 10.8 },
  ];

  const dynoCurve = Array.from({ length: 20 }, (_, i) => {
    const rpm = 2000 + i * 300;
    const stockHP = data.engine.hp * (rpm / 6000) * Math.sin((rpm - 2000) / 5000 * Math.PI);
    const modHP = totalHP * (rpm / 6000) * Math.sin((rpm - 2000) / 5000 * Math.PI);
    return { rpm, stock: Math.max(0, stockHP), modified: Math.max(0, modHP) };
  });

  const modRiskData = [
    { modLevel: 0, risk: 0, gain: 0 },
    { modLevel: 10, risk: 5, gain: 35 },
    { modLevel: 20, risk: 12, gain: 65 },
    { modLevel: 30, risk: 25, gain: 85 },
    { modLevel: 40, risk: 45, gain: 95 },
  ];

  const brakeData = [
    { name: 'M Performance', distance: 122 },
    { name: 'Full M', distance: 108 },
    { name: 'Full M + Mod', distance: 102 },
  ];

  return (
    <div className="min-h-screen bg-black text-white pb-20">
      {/* Header */}
      <div className="border-b border-gray-900 bg-black/50 backdrop-blur-sm sticky top-20 z-40">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-2xl font-light uppercase tracking-wider mb-2">Performance Dashboard</h1>
              <p className="text-gray-500 text-xs uppercase tracking-wider">Comprehensive BMW M Analysis</p>
            </div>
            <Button className="bg-[#0066B1] hover:bg-[#0055A0]">
              <Download className="w-4 h-4 mr-2" />
              Export Report
            </Button>
          </div>

          {/* Filters */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
            <div>
              <label className="text-xs text-gray-500 uppercase tracking-wider mb-2 block">Model Type</label>
              <Select value={selectedModel} onValueChange={setSelectedModel}>
                <SelectTrigger className="bg-gray-950 border-gray-800 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-black border-gray-800">
                  <SelectItem value="M Performance">M Performance (M340i)</SelectItem>
                  <SelectItem value="Full M">Full M (M3 Competition)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-xs text-gray-500 uppercase tracking-wider mb-2 block">Model Year</label>
              <Select defaultValue="2024">
                <SelectTrigger className="bg-gray-950 border-gray-800 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-black border-gray-800">
                  <SelectItem value="2026">2026</SelectItem>
                  <SelectItem value="2025">2025</SelectItem>
                  <SelectItem value="2024">2024</SelectItem>
                  <SelectItem value="2023">2023</SelectItem>
                  <SelectItem value="2022">2022</SelectItem>
                  <SelectItem value="2021">2021</SelectItem>
                  <SelectItem value="2020">2020</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-xs text-gray-500 uppercase tracking-wider mb-2 block">Tune Stage</label>
              <Select value={stage.toString()} onValueChange={(val) => setStage(parseInt(val))}>
                <SelectTrigger className="bg-gray-950 border-gray-800 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-black border-gray-800">
                  <SelectItem value="0">Stock</SelectItem>
                  <SelectItem value="1">Stage 1 (+{stageGains[1].hp}HP)</SelectItem>
                  <SelectItem value="2">Stage 2 (+{stageGains[2].hp}HP)</SelectItem>
                  <SelectItem value="3">Stage 3 (+{stageGains[3].hp}HP)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-xs text-gray-500 uppercase tracking-wider mb-2 block">Drive Mode</label>
              <Select value={driveMode} onValueChange={setDriveMode}>
                <SelectTrigger className="bg-gray-950 border-gray-800 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-black border-gray-800">
                  <SelectItem value="street">Street</SelectItem>
                  <SelectItem value="track">Track</SelectItem>
                  <SelectItem value="eco">Eco</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-xs text-gray-500 uppercase tracking-wider mb-2 block">
                Additional Mod Level: +{modLevel}% Power
              </label>
              <Slider 
                value={[modLevel]} 
                onValueChange={(val) => setModLevel(val[0])}
                max={50}
                step={5}
                className="mt-2"
              />
            </div>
            <div className="flex items-end justify-end gap-4">
              <div className="flex items-center gap-2">
                <Switch checked={dynoMode} onCheckedChange={setDynoMode} />
                <label className="text-xs text-gray-400 uppercase tracking-wider">Virtual Dyno Mode</label>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="bg-gray-950 border border-gray-900 mb-8 flex-wrap">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="engine">Engine</TabsTrigger>
            <TabsTrigger value="transmission">Transmission</TabsTrigger>
            <TabsTrigger value="differential">Differential</TabsTrigger>
            <TabsTrigger value="brakes">Brakes</TabsTrigger>
            <TabsTrigger value="suspension">Suspension</TabsTrigger>
            <TabsTrigger value="tires">Tires</TabsTrigger>
            <TabsTrigger value="rims">Rims</TabsTrigger>
            <TabsTrigger value="electronics">Electronics</TabsTrigger>
            <TabsTrigger value="audio">Audio</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              {/* Overall Score */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-gray-950 border border-gray-900 p-6"
              >
                <div className="flex items-center gap-3 mb-4">
                  <Gauge className="w-5 h-5 text-[#0066B1]" />
                  <h3 className="text-xs uppercase tracking-wider text-gray-400">Overall Performance</h3>
                </div>
                <div className="text-center">
                  <div className="text-5xl font-light text-[#0066B1] mb-2">{overallScore}</div>
                  <p className="text-xs text-gray-500 uppercase tracking-wider">out of 100</p>
                </div>
              </motion.div>

              {/* Risk Level */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="bg-gray-950 border border-gray-900 p-6"
              >
                <div className="flex items-center gap-3 mb-4">
                  <AlertTriangle className={`w-5 h-5 ${
                    riskLevel === 'high' ? 'text-red-500' : 
                    riskLevel === 'medium' ? 'text-yellow-500' : 'text-green-500'
                  }`} />
                  <h3 className="text-xs uppercase tracking-wider text-gray-400">Modification Risk</h3>
                </div>
                <div className="text-center">
                  <div className={`text-3xl font-light uppercase mb-2 ${
                    riskLevel === 'high' ? 'text-red-500' : 
                    riskLevel === 'medium' ? 'text-yellow-500' : 'text-green-500'
                  }`}>
                    {riskLevel}
                  </div>
                  <p className="text-xs text-gray-500 uppercase tracking-wider">
                    {data.engine.risk + modLevel}% failure increase
                  </p>
                </div>
              </motion.div>

              {/* Improvement Potential */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="bg-gray-950 border border-gray-900 p-6"
              >
                <div className="flex items-center gap-3 mb-4">
                  <TrendingUp className="w-5 h-5 text-[#E22718]" />
                  <h3 className="text-xs uppercase tracking-wider text-gray-400">Improvement Potential</h3>
                </div>
                <div className="text-center">
                  <div className="text-5xl font-light text-[#E22718] mb-2">{improvementPotential}</div>
                  <p className="text-xs text-gray-500 uppercase tracking-wider">points available</p>
                </div>
              </motion.div>
            </div>

            {/* Spider Chart */}
            <div className="bg-gray-950 border border-gray-900 p-6 mb-8">
              <h3 className="text-sm uppercase tracking-wider text-white mb-6">Component Comparison</h3>
              <ResponsiveContainer width="100%" height={400}>
                <RadarChart data={spiderData}>
                  <PolarGrid stroke="#333" />
                  <PolarAngleAxis dataKey="category" tick={{ fill: '#999', fontSize: 12 }} />
                  <PolarRadiusAxis angle={90} domain={[0, 100]} tick={{ fill: '#999' }} />
                  <Radar name="M Performance" dataKey="mPerf" stroke="#0066B1" fill="#0066B1" fillOpacity={0.3} />
                  <Radar name="Full M" dataKey="fullM" stroke="#E22718" fill="#E22718" fillOpacity={0.3} />
                  <Legend />
                </RadarChart>
              </ResponsiveContainer>
            </div>

            {/* Stage Info */}
            {stage > 0 && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-blue-950/30 border border-blue-900 p-6 mb-6"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3">
                    <Zap className="w-5 h-5 text-[#0066B1] flex-shrink-0 mt-1" />
                    <div>
                      <h4 className="text-sm font-medium text-[#0066B1] mb-2 uppercase tracking-wider">
                        Stage {stage} Tune Active
                      </h4>
                      <p className="text-sm text-gray-400 mb-2">
                        {currentStageGain.mods}
                      </p>
                      <p className="text-xs text-gray-500">
                        Gains: +{currentStageGain.hp} HP / +{currentStageGain.torque} lb-ft | 
                        Est. Cost: ${currentStageGain.cost.toLocaleString()}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-3xl font-light text-[#0066B1]">{totalHP}</div>
                    <p className="text-xs text-gray-500 uppercase tracking-wider">Total HP</p>
                  </div>
                </div>
              </motion.div>
            )}

            {/* Temperature Alerts */}
            {(data.engine.oilTemp + modLevel > 110 || data.transmission.fluidTemp + modLevel / 2 > 120) && (
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="bg-red-950/30 border border-red-900 p-6 mb-6"
              >
                <div className="flex items-start gap-3">
                  <Thermometer className="w-5 h-5 text-red-500 flex-shrink-0 mt-1" />
                  <div className="space-y-2">
                    <h4 className="text-sm font-medium text-red-400 uppercase tracking-wider">
                      Temperature Warning
                    </h4>
                    {data.engine.oilTemp + modLevel > 110 && (
                      <p className="text-sm text-gray-400">
                        • Engine oil temp: {data.engine.oilTemp + modLevel}°C (Exceeds 110°C threshold)
                      </p>
                    )}
                    {data.transmission.fluidTemp + modLevel / 2 > 120 && (
                      <p className="text-sm text-gray-400">
                        • Transmission fluid: {Math.round(data.transmission.fluidTemp + modLevel / 2)}°C (Exceeds 120°C threshold)
                      </p>
                    )}
                    <p className="text-sm text-red-400 mt-2">
                      Recommend cooling system upgrades and reduced load until temps stabilize.
                    </p>
                  </div>
                </div>
              </motion.div>
            )}

            {/* Knock Alert */}
            {(data.engine.knockCount + Math.floor(modLevel / 10) > 5) && (
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="bg-red-950/30 border border-red-900 p-6 mb-6"
              >
                <div className="flex items-start gap-3">
                  <AlertTriangle className="w-5 h-5 text-red-500 flex-shrink-0 mt-1" />
                  <div>
                    <h4 className="text-sm font-medium text-red-400 mb-2 uppercase tracking-wider">
                      High Knock Counts Detected
                    </h4>
                    <p className="text-sm text-gray-400">
                      Knock count: {data.engine.knockCount + Math.floor(modLevel / 10)} events. 
                      Risk 20% detonation with current tune. Reduce ignition timing advance or use higher octane fuel (93+).
                    </p>
                  </div>
                </div>
              </motion.div>
            )}
          </TabsContent>

          {/* Engine Tab */}
          <TabsContent value="engine">
            <div className="space-y-6">
              {/* Key Metrics */}
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                <div className="bg-gray-950 border border-gray-900 p-4">
                  <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">Horsepower</p>
                  <p className="text-3xl font-light text-[#E22718]">{totalHP}</p>
                  <p className="text-xs text-gray-600 uppercase tracking-wider mt-1">HP (Wheel)</p>
                </div>
                <div className="bg-gray-950 border border-gray-900 p-4">
                  <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">Torque</p>
                  <p className="text-3xl font-light text-[#0066B1]">{totalTorque}</p>
                  <p className="text-xs text-gray-600 uppercase tracking-wider mt-1">LB-FT</p>
                </div>
                <div className="bg-gray-950 border border-gray-900 p-4">
                  <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">0-60 MPH</p>
                  <p className="text-3xl font-light text-white">{(data.engine.zeroToSixty * (1 - (modLevel + stage * 10) / 200)).toFixed(1)}</p>
                  <p className="text-xs text-gray-600 uppercase tracking-wider mt-1">SECONDS</p>
                </div>
                <div className="bg-gray-950 border border-gray-900 p-4">
                  <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">Boost</p>
                  <p className="text-3xl font-light text-white">{data.engine.boost + Math.round((modLevel + stage * 2) / 5)}</p>
                  <p className="text-xs text-gray-600 uppercase tracking-wider mt-1">PSI</p>
                </div>
                <div className="bg-gray-950 border border-gray-900 p-4">
                  <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">AFR</p>
                  <p className="text-3xl font-light text-white">{(data.engine.afr - modLevel / 50).toFixed(1)}</p>
                  <p className="text-xs text-gray-600 uppercase tracking-wider mt-1">Ratio</p>
                </div>
              </div>

              {/* Advanced Metrics Grid */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-gray-950 border border-gray-900 p-4">
                  <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">Oil Temp</p>
                  <p className={`text-2xl font-light ${data.engine.oilTemp + modLevel > 110 ? 'text-red-500' : 'text-white'}`}>
                    {data.engine.oilTemp + modLevel}°C
                  </p>
                </div>
                <div className="bg-gray-950 border border-gray-900 p-4">
                  <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">Oil Pressure</p>
                  <p className="text-2xl font-light text-white">{data.engine.oilPressure} PSI</p>
                </div>
                <div className="bg-gray-950 border border-gray-900 p-4">
                  <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">IAT</p>
                  <p className="text-2xl font-light text-white">{data.engine.iat + Math.round(modLevel / 2)}°C</p>
                </div>
                <div className="bg-gray-950 border border-gray-900 p-4">
                  <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">Knock Count</p>
                  <p className={`text-2xl font-light ${data.engine.knockCount + Math.floor(modLevel / 10) > 5 ? 'text-red-500' : 'text-white'}`}>
                    {data.engine.knockCount + Math.floor(modLevel / 10)}
                  </p>
                </div>
                <div className="bg-gray-950 border border-gray-900 p-4">
                  <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">Ignition Timing</p>
                  <p className="text-2xl font-light text-white">{data.engine.ignitionTiming + Math.round(modLevel / 10)}°</p>
                </div>
                <div className="bg-gray-950 border border-gray-900 p-4">
                  <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">Fuel Trim</p>
                  <p className="text-2xl font-light text-white">{data.engine.fuelTrim + Math.round(modLevel / 5)}%</p>
                </div>
                <div className="bg-gray-950 border border-gray-900 p-4">
                  <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">Turbo Speed</p>
                  <p className="text-2xl font-light text-white">{(data.engine.turboSpeed / 1000).toFixed(0)}K RPM</p>
                </div>
                <div className="bg-gray-950 border border-gray-900 p-4">
                  <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">Rev Limit</p>
                  <p className="text-2xl font-light text-white">{data.engine.revLimit}</p>
                </div>
              </div>

              {/* HP/Torque Comparison */}
              <div className="bg-gray-950 border border-gray-900 p-6">
                <h3 className="text-sm uppercase tracking-wider text-white mb-6">Power Comparison</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={engineComparisonData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                    <XAxis dataKey="name" tick={{ fill: '#999' }} />
                    <YAxis tick={{ fill: '#999' }} />
                    <Tooltip contentStyle={{ backgroundColor: '#000', border: '1px solid #333' }} />
                    <Legend />
                    <Bar dataKey="mPerf" name="M Performance" fill="#0066B1" />
                    <Bar dataKey="fullM" name="Full M" fill="#E22718" />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              {/* Virtual Dyno / Acceleration Curve */}
              <div className="bg-gray-950 border border-gray-900 p-6">
                <h3 className="text-sm uppercase tracking-wider text-white mb-6">
                  {dynoMode ? 'Virtual Dyno - Power Curve' : 'Acceleration Curve'}
                </h3>
                <ResponsiveContainer width="100%" height={350}>
                  {dynoMode ? (
                    <ComposedChart data={dynoCurve}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                      <XAxis dataKey="rpm" label={{ value: 'Engine RPM', position: 'insideBottom', offset: -5, fill: '#999' }} tick={{ fill: '#999' }} />
                      <YAxis label={{ value: 'Horsepower', angle: -90, position: 'insideLeft', fill: '#999' }} tick={{ fill: '#999' }} />
                      <Tooltip contentStyle={{ backgroundColor: '#000', border: '1px solid #333' }} />
                      <Legend />
                      <Area type="monotone" dataKey="stock" stroke="#666" fill="#333" fillOpacity={0.3} name="Stock" />
                      <Line type="monotone" dataKey="modified" stroke="#E22718" strokeWidth={3} name={`Stage ${stage} Modified`} />
                    </ComposedChart>
                  ) : (
                    <LineChart data={accelerationCurve}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                      <XAxis dataKey="speed" label={{ value: 'Speed (MPH)', position: 'insideBottom', offset: -5, fill: '#999' }} tick={{ fill: '#999' }} />
                      <YAxis label={{ value: 'Time (sec)', angle: -90, position: 'insideLeft', fill: '#999' }} tick={{ fill: '#999' }} />
                      <Tooltip contentStyle={{ backgroundColor: '#000', border: '1px solid #333' }} />
                      <Legend />
                      <Line type="monotone" dataKey="stock" stroke="#666" strokeWidth={2} name="Stock" strokeDasharray="5 5" />
                      <Line type="monotone" dataKey="stage1" stroke="#0066B1" strokeWidth={2} name="Stage 1" />
                      <Line type="monotone" dataKey="stage2" stroke="#FFB300" strokeWidth={2} name="Stage 2" />
                      <Line type="monotone" dataKey="stage3" stroke="#E22718" strokeWidth={2} name="Stage 3" />
                    </LineChart>
                  )}
                </ResponsiveContainer>
              </div>

              {/* Modification Risk */}
              <div className="bg-gray-950 border border-gray-900 p-6">
                <h3 className="text-sm uppercase tracking-wider text-white mb-6">Modification Risk vs Performance Gain</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={modRiskData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                    <XAxis dataKey="modLevel" label={{ value: '% Power Increase', position: 'insideBottom', offset: -5, fill: '#999' }} tick={{ fill: '#999' }} />
                    <YAxis tick={{ fill: '#999' }} />
                    <Tooltip contentStyle={{ backgroundColor: '#000', border: '1px solid #333' }} />
                    <Legend />
                    <Area type="monotone" dataKey="gain" stackId="1" stroke="#00C853" fill="#00C853" fillOpacity={0.6} name="Performance Gain %" />
                    <Area type="monotone" dataKey="risk" stackId="2" stroke="#E22718" fill="#E22718" fillOpacity={0.6} name="Failure Risk %" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>

              {/* Recommendations */}
              <div className="bg-blue-950/30 border border-blue-900 p-6">
                <h4 className="text-sm font-medium text-[#0066B1] mb-3 uppercase tracking-wider">
                  Improvement Suggestions
                </h4>
                <ul className="space-y-2 text-sm text-gray-400">
                  <li>• For M Performance: Add intercooler upgrades to handle +50 HP mods without overheating</li>
                  <li>• For Full M: Monitor ECU remaps to avoid warranty voids</li>
                  <li>• Install oil cooler for sustained track use above 20% power gains</li>
                  <li>• Upgrade fuel injectors when exceeding 25% power increase</li>
                </ul>
              </div>
            </div>
          </TabsContent>

          {/* Brakes Tab */}
          <TabsContent value="brakes">
            <div className="space-y-6">
              {/* Key Metrics */}
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                <div className="bg-gray-950 border border-gray-900 p-4">
                  <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">Rotor Size</p>
                  <p className="text-3xl font-light text-white">{data.brakes.rotorSize}</p>
                  <p className="text-xs text-gray-600 uppercase tracking-wider mt-1">MM</p>
                </div>
                <div className="bg-gray-950 border border-gray-900 p-4">
                  <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">Friction Coef.</p>
                  <p className="text-3xl font-light text-white">{data.brakes.friction}</p>
                  <p className="text-xs text-gray-600 uppercase tracking-wider mt-1">μ</p>
                </div>
                <div className="bg-gray-950 border border-gray-900 p-4">
                  <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">Stopping Dist.</p>
                  <p className="text-3xl font-light text-[#E22718]">{data.brakes.stoppingDist}</p>
                  <p className="text-xs text-gray-600 uppercase tracking-wider mt-1">FEET</p>
                </div>
                <div className="bg-gray-950 border border-gray-900 p-4">
                  <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">Fade Resist.</p>
                  <p className="text-3xl font-light text-white">{data.brakes.fadeResist}</p>
                  <p className="text-xs text-gray-600 uppercase tracking-wider mt-1">LAPS</p>
                </div>
                <div className="bg-gray-950 border border-gray-900 p-4">
                  <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">Heat Dissip.</p>
                  <p className="text-3xl font-light text-white">{data.brakes.heatDissipation}</p>
                  <p className="text-xs text-gray-600 uppercase tracking-wider mt-1">°C/MIN</p>
                </div>
              </div>

              {/* Stopping Distance Comparison */}
              <div className="bg-gray-950 border border-gray-900 p-6">
                <h3 className="text-sm uppercase tracking-wider text-white mb-6">Stopping Distance (100 MPH)</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={brakeData} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                    <XAxis type="number" tick={{ fill: '#999' }} label={{ value: 'Distance (feet)', position: 'insideBottom', offset: -5, fill: '#999' }} />
                    <YAxis dataKey="name" type="category" tick={{ fill: '#999' }} width={150} />
                    <Tooltip contentStyle={{ backgroundColor: '#000', border: '1px solid #333' }} />
                    <Bar dataKey="distance" fill="#E22718" />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              {/* Recommendations */}
              <div className="bg-blue-950/30 border border-blue-900 p-6">
                <h4 className="text-sm font-medium text-[#0066B1] mb-3 uppercase tracking-wider">
                  Improvement Suggestions
                </h4>
                <ul className="space-y-2 text-sm text-gray-400">
                  <li>• Upgrade to carbon-ceramic brakes on Full M for high-heat track scenarios</li>
                  <li>• For M Performance: Add ventilated rotors to handle +100 HP mods safely</li>
                  <li>• Install brake cooling ducts for sustained performance driving</li>
                  <li>• Use high-performance brake fluid (DOT 5.1) for better heat resistance</li>
                </ul>
              </div>
            </div>
          </TabsContent>

          {/* Transmission Tab */}
          <TabsContent value="transmission">
            <div className="space-y-6">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-gray-950 border border-gray-900 p-4">
                  <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">Shift Time</p>
                  <p className="text-3xl font-light text-[#0066B1]">{data.transmission.shiftTime - stage * 20}</p>
                  <p className="text-xs text-gray-600 uppercase tracking-wider mt-1">MS</p>
                </div>
                <div className="bg-gray-950 border border-gray-900 p-4">
                  <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">Fluid Temp</p>
                  <p className={`text-3xl font-light ${data.transmission.fluidTemp + modLevel / 2 > 120 ? 'text-red-500' : 'text-white'}`}>
                    {Math.round(data.transmission.fluidTemp + modLevel / 2)}°C
                  </p>
                </div>
                <div className="bg-gray-950 border border-gray-900 p-4">
                  <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">Clutch Wear</p>
                  <p className="text-3xl font-light text-white">{data.transmission.clutchWear + stage * 2}%</p>
                </div>
                <div className="bg-gray-950 border border-gray-900 p-4">
                  <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">Drivelogic</p>
                  <p className="text-xl font-light text-white">{data.transmission.drivelogicMode}</p>
                </div>
              </div>

              <div className="bg-gray-950 border border-gray-900 p-6">
                <h3 className="text-sm uppercase tracking-wider text-white mb-4">Gear Ratios (8-Speed)</h3>
                <p className="text-sm text-gray-400 font-mono">{data.transmission.gearRatios}</p>
              </div>

              <div className="bg-blue-950/30 border border-blue-900 p-6">
                <h4 className="text-sm font-medium text-[#0066B1] mb-3 uppercase tracking-wider">Tuning Suggestions</h4>
                <ul className="space-y-2 text-sm text-gray-400">
                  <li>• TCU tune with Dinan software for -50ms shift improvement</li>
                  <li>• Monitor fluid temp via OBD sensor (BMW part 28107842851) to prevent overheating</li>
                  <li>• For manual models: Add short shifter for precise changes</li>
                </ul>
              </div>
            </div>
          </TabsContent>

          {/* Differential Tab */}
          <TabsContent value="differential">
            <div className="space-y-6">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-gray-950 border border-gray-900 p-4">
                  <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">Locking %</p>
                  <p className="text-3xl font-light text-[#E22718]">{data.differential.lockingPct}%</p>
                </div>
                <div className="bg-gray-950 border border-gray-900 p-4">
                  <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">Gear Ratio</p>
                  <p className="text-3xl font-light text-white">{data.differential.gearRatio}:1</p>
                </div>
                <div className="bg-gray-950 border border-gray-900 p-4">
                  <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">Oil Temp</p>
                  <p className={`text-3xl font-light ${data.differential.oilTemp > 130 ? 'text-red-500' : 'text-white'}`}>
                    {data.differential.oilTemp}°C
                  </p>
                </div>
                <div className="bg-gray-950 border border-gray-900 p-4">
                  <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">Type</p>
                  <p className="text-xl font-light text-white">{data.differential.lsdType}</p>
                </div>
              </div>

              <div className="bg-gray-950 border border-gray-900 p-6">
                <h3 className="text-sm uppercase tracking-wider text-white mb-4">Torque Bias Ratio</h3>
                <div className="text-center">
                  <p className="text-5xl font-light text-[#0066B1]">{data.differential.torqueBias}:1</p>
                  <p className="text-sm text-gray-500 mt-2">Traction Improvement: +{data.differential.tractionGain}%</p>
                </div>
              </div>

              <div className="bg-blue-950/30 border border-blue-900 p-6">
                <h4 className="text-sm font-medium text-[#0066B1] mb-3 uppercase tracking-wider">Upgrade Path</h4>
                <ul className="space-y-2 text-sm text-gray-400">
                  <li>• Upgrade to Wavetrac LSD for better traction (1.5:1 bias ratio)</li>
                  <li>• Remap e-diff ECU for custom locking profiles (requires actuator removal)</li>
                  <li>• Monitor oil temp with BMW sensor 33107847469 to avoid failures</li>
                  <li>• Consider 3.73:1 gearing swap for +10% quicker launches</li>
                </ul>
              </div>
            </div>
          </TabsContent>

          {/* Electronics Tab */}
          <TabsContent value="electronics">
            <div className="space-y-6">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-gray-950 border border-gray-900 p-4">
                  <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">ECU Response</p>
                  <p className="text-3xl font-light text-white">{data.electronics.ecuResponse - stage * 5}</p>
                  <p className="text-xs text-gray-600 uppercase tracking-wider mt-1">MS</p>
                </div>
                <div className="bg-gray-950 border border-gray-900 p-4">
                  <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">Compatibility</p>
                  <p className="text-3xl font-light text-[#0066B1]">{data.electronics.compatibility}%</p>
                </div>
                <div className="bg-gray-950 border border-gray-900 p-4">
                  <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">Flash Count</p>
                  <p className={`text-3xl font-light ${stage > 0 ? 'text-yellow-500' : 'text-white'}`}>{stage}</p>
                </div>
                <div className="bg-gray-950 border border-gray-900 p-4">
                  <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">DME Status</p>
                  <p className="text-xl font-light text-white">{stage > 0 ? 'Unlocked' : 'Stock'}</p>
                </div>
              </div>

              <div className="bg-gray-950 border border-gray-900 p-6">
                <h3 className="text-sm uppercase tracking-wider text-white mb-6">ECU Tuning Gains by Stage</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={[
                    { stage: 'Stock', hp: data.engine.hp, torque: data.engine.torque },
                    { stage: 'Stage 1', hp: data.engine.hp + 35, torque: data.engine.torque + 40 },
                    { stage: 'Stage 2', hp: data.engine.hp + 70, torque: data.engine.torque + 75 },
                    { stage: 'Stage 3', hp: data.engine.hp + 103, torque: data.engine.torque + 95 }
                  ]}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                    <XAxis dataKey="stage" tick={{ fill: '#999' }} />
                    <YAxis tick={{ fill: '#999' }} />
                    <Tooltip contentStyle={{ backgroundColor: '#000', border: '1px solid #333' }} />
                    <Legend />
                    <Bar dataKey="hp" fill="#E22718" name="HP" />
                    <Bar dataKey="torque" fill="#0066B1" name="Torque" />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              <div className="bg-blue-950/30 border border-blue-900 p-6">
                <h4 className="text-sm font-medium text-[#0066B1] mb-3 uppercase tracking-wider">ECU Tuning Options</h4>
                <ul className="space-y-2 text-sm text-gray-400">
                  <li>• Flash ECU with MHD app for mobile tuning</li>
                  <li>• Support bench unlocks for locked DMEs</li>
                  <li>• Alert on &gt;5 flash cycles to prevent DME wear</li>
                  <li>• Integrate with e-diff remaps for seamless upgrades</li>
                  <li>• Monitor OBD-II error codes via diagnostic port</li>
                </ul>
              </div>
            </div>
          </TabsContent>

          {/* Other tabs */}
          <TabsContent value="tires">
            <div className="bg-gray-950 border border-gray-900 p-12 text-center">
              <p className="text-gray-500 text-sm uppercase tracking-wider">Tire analysis with grip coefficients and alignment data...</p>
            </div>
          </TabsContent>

          <TabsContent value="rims">
            <div className="bg-gray-950 border border-gray-900 p-12 text-center">
              <p className="text-gray-500 text-sm uppercase tracking-wider">Rim weight and rotational inertia analysis...</p>
            </div>
          </TabsContent>

          <TabsContent value="suspension">
            <div className="bg-gray-950 border border-gray-900 p-12 text-center">
              <p className="text-gray-500 text-sm uppercase tracking-wider">Suspension damping and cornering analysis...</p>
            </div>
          </TabsContent>

          <TabsContent value="audio">
            <div className="bg-gray-950 border border-gray-900 p-12 text-center">
              <p className="text-gray-500 text-sm uppercase tracking-wider">Audio system power and frequency response...</p>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}