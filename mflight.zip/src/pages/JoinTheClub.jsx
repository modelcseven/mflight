import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

export default function JoinTheClub() {
  const [user, setUser] = useState(null);
  const [step, setStep] = useState(0);
  const [preferredName, setPreferredName] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [location, setLocation] = useState(null);
  const [selectedModelType, setSelectedModelType] = useState(null);
  const [selectedModels, setSelectedModels] = useState([]);
  const [submitted, setSubmitted] = useState(false);

  const mPerformanceModels = [
    'M240i', 'M340i', 'M440i', 'M550i', 'M760i',
    'X3 M40i', 'X4 M40i', 'X5 M50i', 'X6 M50i', 'X7 M60i'
  ];

  const fullMModels = [
    // SUVs and Sports Activity Coupes
    'X3 M Competition', 'X4 M Competition', 'X5 M Competition', 
    'X6 M Competition', 'XM', 'XM Label', 'XM 50e',
    // Sedans
    'M3', 'M3 Competition', 'M3 Competition xDrive', 
    'M5 (plug-in hybrid)',
    // Tourings
    'M3 Competition Touring', 'M3 CS Touring', 'M5 Touring (plug-in hybrid)',
    // Coupes
    'M2', 'M2 CS', 'M4', 'M4 Competition', 'M4 Competition xDrive', 
    'M4 CSL', 'M8 Competition',
    // Convertibles
    'M4 Competition Convertible', 'M4 Competition xDrive Convertible',
    'M8 Competition Convertible',
    // Gran Coupes
    'M8 Competition Gran Coupe'
  ];

  useEffect(() => {
    const loadUser = async () => {
      const currentUser = await base44.auth.me().catch(() => null);
      if (!currentUser) {
        base44.auth.redirectToLogin();
      } else {
        setUser(currentUser);
        // Show greeting after a brief delay
        setTimeout(() => setStep(1), 500);
      }
    };
    loadUser();
  }, []);

  const handleNameSubmit = () => {
    if (preferredName.trim()) {
      setStep(2); // Go to email
    }
  };

  const handleEmailSubmit = () => {
    if (contactEmail.trim() && contactEmail.includes('@')) {
      setStep(3); // Go to phone
    }
  };

  const handlePhoneSubmit = () => {
    setStep(4); // Go to location (phone is optional)
  };

  const handleLocationSelect = (loc) => {
    setLocation(loc);
    setStep(5); // Go to model type selection
  };

  const handleModelTypeSelect = (modelType) => {
    setSelectedModelType(modelType);
    setStep(6); // Go to model selection
  };

  const toggleModel = (model) => {
    if (selectedModels.includes(model)) {
      setSelectedModels(selectedModels.filter(m => m !== model));
    } else {
      setSelectedModels([...selectedModels, model]);
    }
  };

  const submitApplication = async (modelType, models) => {
    try {
      // Create application
      await base44.entities.MembershipApplication.create({
        user_email: user.email,
        user_name: user.full_name,
        preferred_name: preferredName,
        contact_email: contactEmail,
        phone_number: phoneNumber || null,
        location: location,
        model_type: modelType,
        selected_models: models,
        status: 'pending'
      });

      // Auto-create garages for selected models
      for (const model of models) {
        await base44.entities.Garage.create({
          name: `${model} Garage`,
          owner_email: user.email,
          owner_name: user.full_name,
          description: `My ${model} build`,
          car_ids: []
        });
      }

      setTimeout(() => setSubmitted(true), 800);
    } catch (error) {
      console.error('Failed to submit application:', error);
    }
  };

  const handleSubmitModels = () => {
    setStep(7);
    submitApplication(selectedModelType, selectedModels);
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#0066B1]" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white flex items-center justify-center px-6">
      <div className="max-w-3xl w-full">
        <AnimatePresence mode="wait">
          {/* Step 1: Name */}
          {step === 1 && !submitted && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-8"
            >
              <div className="bg-gray-950 border border-gray-900 p-8 rounded-lg">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-[#0066B1] flex items-center justify-center rounded-lg flex-shrink-0">
                    <span className="text-white font-bold text-sm">MF</span>
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xs font-medium text-[#0066B1] mb-2 uppercase tracking-widest">MFlight Assistant</h3>
                    <p className="text-white text-base leading-relaxed mb-6">
                      Hello! Welcome to <span className="font-semibold">MFlight</span>, an Exclusive BMW M Performance Car Club. What name would you like us to call you?
                    </p>
                    <Input
                      value={preferredName}
                      onChange={(e) => setPreferredName(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleNameSubmit()}
                      placeholder="Enter your name"
                      className="bg-black border-gray-800 text-white mb-4"
                      autoFocus
                    />
                    <Button
                      onClick={handleNameSubmit}
                      disabled={!preferredName.trim()}
                      className="w-full bg-[#0066B1] hover:bg-[#0055A0] text-white px-6 py-6 text-sm uppercase tracking-widest"
                    >
                      Continue
                    </Button>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {/* Step 2: Email */}
          {step === 2 && !submitted && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-8"
            >
              <div className="bg-gray-950 border border-gray-900 p-8 rounded-lg">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-[#0066B1] flex items-center justify-center rounded-lg flex-shrink-0">
                    <span className="text-white font-bold text-sm">MF</span>
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xs font-medium text-[#0066B1] mb-2 uppercase tracking-widest">MFlight Assistant</h3>
                    <p className="text-white text-base leading-relaxed mb-6">
                      Thanks, <span className="text-[#0066B1]">{preferredName}</span>! What's your email address?
                    </p>
                    <Input
                      type="email"
                      value={contactEmail}
                      onChange={(e) => setContactEmail(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleEmailSubmit()}
                      placeholder="Enter your email"
                      className="bg-black border-gray-800 text-white mb-4"
                      autoFocus
                    />
                    <Button
                      onClick={handleEmailSubmit}
                      disabled={!contactEmail.trim() || !contactEmail.includes('@')}
                      className="w-full bg-[#0066B1] hover:bg-[#0055A0] text-white px-6 py-6 text-sm uppercase tracking-widest"
                    >
                      Continue
                    </Button>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {/* Step 3: Phone */}
          {step === 3 && !submitted && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-8"
            >
              <div className="bg-gray-950 border border-gray-900 p-8 rounded-lg">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-[#0066B1] flex items-center justify-center rounded-lg flex-shrink-0">
                    <span className="text-white font-bold text-sm">MF</span>
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xs font-medium text-[#0066B1] mb-2 uppercase tracking-widest">MFlight Assistant</h3>
                    <p className="text-white text-base leading-relaxed mb-2">
                      Phone number? <span className="text-gray-500">(Optional)</span>
                    </p>
                    <Input
                      type="tel"
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handlePhoneSubmit()}
                      placeholder="Enter your phone number"
                      className="bg-black border-gray-800 text-white mb-4"
                      autoFocus
                    />
                    <div className="flex gap-3">
                      <Button
                        onClick={handlePhoneSubmit}
                        variant="outline"
                        className="flex-1 border-gray-800 text-gray-400 hover:text-white hover:bg-gray-900"
                      >
                        Skip
                      </Button>
                      <Button
                        onClick={handlePhoneSubmit}
                        className="flex-1 bg-[#0066B1] hover:bg-[#0055A0] text-white"
                      >
                        Continue
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {/* Step 4: Location */}
          {step === 4 && !submitted && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-8"
            >
              <div className="bg-gray-950 border border-gray-900 p-8 rounded-lg">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-[#0066B1] flex items-center justify-center rounded-lg flex-shrink-0">
                    <span className="text-white font-bold text-sm">MF</span>
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xs font-medium text-[#0066B1] mb-2 uppercase tracking-widest">MFlight Assistant</h3>
                    <p className="text-white text-base leading-relaxed mb-6">
                      Great to meet you, <span className="text-[#0066B1]">{preferredName}</span>! Where are you located?
                    </p>
                    <div className="grid grid-cols-2 gap-4">
                      <motion.button
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        onClick={() => handleLocationSelect('Europe')}
                        className={`p-6 text-center transition-all rounded-lg border-2 ${
                          location === 'Europe'
                            ? 'bg-[#0066B1] border-[#0066B1]'
                            : 'bg-black border-gray-800 hover:border-[#0066B1]'
                        }`}
                      >
                        <h4 className="text-white font-medium text-lg uppercase tracking-wide mb-2">Europe</h4>
                        {location === 'Europe' && (
                          <CheckCircle className="w-6 h-6 text-white mx-auto" />
                        )}
                      </motion.button>
                      <motion.button
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        onClick={() => handleLocationSelect('USA')}
                        className={`p-6 text-center transition-all rounded-lg border-2 ${
                          location === 'USA'
                            ? 'bg-[#0066B1] border-[#0066B1]'
                            : 'bg-black border-gray-800 hover:border-[#0066B1]'
                        }`}
                      >
                        <h4 className="text-white font-medium text-lg uppercase tracking-wide mb-2">USA</h4>
                        {location === 'USA' && (
                          <CheckCircle className="w-6 h-6 text-white mx-auto" />
                        )}
                      </motion.button>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {/* Step 5: Model Type */}
          {step === 5 && !submitted && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="mb-8"
            >
              <div className="bg-gray-950 border border-gray-900 p-8 rounded-lg">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-[#0066B1] flex items-center justify-center rounded-lg flex-shrink-0">
                    <span className="text-white font-bold text-sm">MF</span>
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xs font-medium text-[#0066B1] mb-2 uppercase tracking-widest">MFlight Assistant</h3>
                    <p className="text-white text-base leading-relaxed mb-6">
                      Which type of BMW M vehicle do you own?
                    </p>

                    {/* Model Selection */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <motion.button
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        onClick={() => handleModelTypeSelect('M Performance')}
                        className={`p-6 text-left transition-all rounded-lg border-2 ${
                          selectedModelType === 'M Performance'
                            ? 'bg-[#0066B1] border-[#0066B1]'
                            : 'bg-black border-gray-800 hover:border-[#0066B1]'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-3">
                          <h4 className="text-white font-medium text-lg uppercase tracking-wide">M Performance</h4>
                          <div className={`w-8 h-8 border-2 rounded-full transition-colors flex items-center justify-center ${
                            selectedModelType === 'M Performance'
                              ? 'border-white bg-white'
                              : 'border-gray-800'
                          }`}>
                            {selectedModelType === 'M Performance' && (
                              <CheckCircle className="w-6 h-6 text-[#0066B1]" />
                            )}
                          </div>
                        </div>
                        <p className={`text-sm leading-relaxed ${
                          selectedModelType === 'M Performance' ? 'text-gray-200' : 'text-gray-500'
                        }`}>
                          e.g., M340i, X3 M40i, M440i
                        </p>
                        <p className={`text-xs mt-2 ${
                          selectedModelType === 'M Performance' ? 'text-gray-300' : 'text-gray-600'
                        }`}>
                          Enhanced performance variants of standard BMW models
                        </p>
                      </motion.button>

                      <motion.button
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        onClick={() => handleModelTypeSelect('Full M Model')}
                        className={`p-6 text-left transition-all rounded-lg border-2 ${
                          selectedModelType === 'Full M Model'
                            ? 'bg-[#E22718] border-[#E22718]'
                            : 'bg-black border-gray-800 hover:border-[#E22718]'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-3">
                          <h4 className="text-white font-medium text-lg uppercase tracking-wide">Full M Model</h4>
                          <div className={`w-8 h-8 border-2 rounded-full transition-colors flex items-center justify-center ${
                            selectedModelType === 'Full M Model'
                              ? 'border-white bg-white'
                              : 'border-gray-800'
                          }`}>
                            {selectedModelType === 'Full M Model' && (
                              <CheckCircle className="w-6 h-6 text-[#E22718]" />
                            )}
                          </div>
                        </div>
                        <p className={`text-sm leading-relaxed ${
                          selectedModelType === 'Full M Model' ? 'text-gray-200' : 'text-gray-500'
                        }`}>
                          e.g., M2, M3, M4, M5, X5 M
                        </p>
                        <p className={`text-xs mt-2 ${
                          selectedModelType === 'Full M Model' ? 'text-gray-300' : 'text-gray-600'
                        }`}>
                          Fully engineered by BMW M GmbH for track-level performance
                        </p>
                      </motion.button>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {/* Step 6: Model Selection */}
          {step === 6 && !submitted && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="mb-8"
            >
              <div className="bg-gray-950 border border-gray-900 p-8 rounded-lg">
                <div className="flex items-start gap-4">
                  <div className={`w-12 h-12 ${selectedModelType === 'M Performance' ? 'bg-[#0066B1]' : 'bg-[#E22718]'} flex items-center justify-center rounded-lg flex-shrink-0`}>
                    <span className="text-white font-bold text-sm">MF</span>
                  </div>
                  <div className="flex-1">
                    <h3 className={`text-xs font-medium ${selectedModelType === 'M Performance' ? 'text-[#0066B1]' : 'text-[#E22718]'} mb-2 uppercase tracking-widest`}>MFlight Assistant</h3>
                    <p className="text-white text-base leading-relaxed mb-6">
                      {selectedModelType === 'M Performance' 
                        ? 'Great! Which M Performance models do you own? Select all that apply.'
                        : 'Excellent choice! Which Full M models do you own? Select all that apply.'}
                    </p>

                    {/* Model Grid */}
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-6 max-h-[500px] overflow-y-auto pr-2">
                      {(selectedModelType === 'M Performance' ? mPerformanceModels : fullMModels).map((model) => (
                        <motion.button
                          key={model}
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          onClick={() => toggleModel(model)}
                          className={`p-4 text-left transition-all rounded-lg border-2 ${
                            selectedModels.includes(model)
                              ? selectedModelType === 'M Performance'
                                ? 'bg-[#0066B1] border-[#0066B1] text-white'
                                : 'bg-[#E22718] border-[#E22718] text-white'
                              : 'bg-black border-gray-800 text-gray-400 hover:border-gray-600'
                          }`}
                        >
                          <div className="flex items-center justify-between gap-2">
                            <span className="font-medium text-xs uppercase tracking-wide">
                              {model}
                            </span>
                            {selectedModels.includes(model) && (
                              <CheckCircle className="w-4 h-4 flex-shrink-0" />
                            )}
                          </div>
                        </motion.button>
                      ))}
                    </div>

                    {/* Submit Button */}
                    <Button
                      onClick={handleSubmitModels}
                      disabled={selectedModels.length === 0}
                      className={`w-full ${selectedModelType === 'M Performance' ? 'bg-[#0066B1] hover:bg-[#0055A0]' : 'bg-[#E22718] hover:bg-[#C01F12]'} text-white px-6 py-6 text-sm uppercase tracking-widest disabled:opacity-50 disabled:cursor-not-allowed`}
                    >
                      Submit ({selectedModels.length} model{selectedModels.length !== 1 ? 's' : ''} selected)
                    </Button>

                    {selectedModels.length > 0 && (
                      <p className="text-gray-600 text-xs mt-3 text-center">
                        A garage will be automatically created for each selected model
                      </p>
                    )}
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {/* Step 7: Confirmation */}
          {submitted && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-center"
            >
              <div className="bg-gray-950 border border-gray-900 p-12 rounded-lg">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
                  className="w-20 h-20 bg-[#0066B1] rounded-full flex items-center justify-center mx-auto mb-6"
                >
                  <CheckCircle className="w-10 h-10 text-white" />
                </motion.div>

                <h2 className="text-2xl font-light text-white mb-4 uppercase tracking-wide">
                  Thank You!
                </h2>

                <div className="bg-black border border-gray-900 p-6 rounded-lg mb-6 max-w-xl mx-auto">
                  <p className="text-gray-400 text-sm leading-relaxed">
                    Thanks for your submission. Our admin team is reviewing your request and will determine your membership status shortly.
                  </p>
                </div>

                <div className="flex items-center justify-center gap-2 text-xs text-gray-600 uppercase tracking-wider">
                  <div className="w-2 h-2 bg-[#0066B1] rounded-full animate-pulse" />
                  <span>Your application is pending review</span>
                </div>

                <div className="mt-8">
                  <p className="text-gray-600 text-xs uppercase tracking-wider mb-4">
                    You will receive a notification once your application is processed
                  </p>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}