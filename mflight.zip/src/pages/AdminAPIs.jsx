import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { Key, Webhook, Plus, Trash2, Copy } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';

export default function AdminAPIs() {
  const [user, setUser] = useState(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    const loadUser = async () => {
      const currentUser = await base44.auth.me();
      if (!currentUser || currentUser.role !== 'admin') {
        window.location.href = '/';
        return;
      }
      setUser(currentUser);
    };
    loadUser();
  }, []);

  const { data: apiKeys = [] } = useQuery({
    queryKey: ['api-keys'],
    queryFn: () => base44.entities.APIKey.list(),
  });

  const { data: webhooks = [] } = useQuery({
    queryKey: ['webhooks'],
    queryFn: () => base44.entities.WebhookConfig.list(),
  });

  const deleteKeyMutation = useMutation({
    mutationFn: (id) => base44.entities.APIKey.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['api-keys'] }),
  });

  const deleteWebhookMutation = useMutation({
    mutationFn: (id) => base44.entities.WebhookConfig.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['webhooks'] }),
  });

  if (!user) return null;

  return (
    <div className="min-h-screen bg-black text-white pb-20">
      <div className="max-w-7xl mx-auto px-6 py-12">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-12">
          <h1 className="text-4xl font-light uppercase tracking-wider mb-2">API & Webhooks</h1>
          <p className="text-gray-500 text-sm uppercase tracking-wider">Manage integrations</p>
        </motion.div>

        {/* API Keys Section */}
        <div className="mb-12">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-light uppercase tracking-wider">API Keys</h2>
            <CreateAPIKeyDialog />
          </div>
          <div className="space-y-4">
            {apiKeys.map(key => (
              <div key={key.id} className="bg-gray-950 border border-gray-900 p-6 flex items-center justify-between">
                <div className="flex-1">
                  <h3 className="text-lg font-light mb-2">{key.name}</h3>
                  <div className="flex items-center gap-4 text-sm text-gray-500">
                    <span>Used: {key.usage_count} times</span>
                    <Badge className={key.active ? 'bg-[#00C853]' : 'bg-gray-700'}>
                      {key.active ? 'Active' : 'Inactive'}
                    </Badge>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm" className="border-gray-800" onClick={() => navigator.clipboard.writeText(key.key)}>
                    <Copy className="w-4 h-4" />
                  </Button>
                  <Button variant="outline" size="sm" className="border-gray-800 text-red-500" onClick={() => deleteKeyMutation.mutate(key.id)}>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Webhooks Section */}
        <div>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-light uppercase tracking-wider">Webhooks</h2>
            <CreateWebhookDialog />
          </div>
          <div className="space-y-4">
            {webhooks.map(webhook => (
              <div key={webhook.id} className="bg-gray-950 border border-gray-900 p-6">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-light mb-2">{webhook.name}</h3>
                    <p className="text-sm text-gray-500 mb-2">{webhook.url}</p>
                    <div className="flex gap-2">
                      {webhook.events.map(event => (
                        <Badge key={event} variant="outline" className="border-gray-800 text-gray-400">{event}</Badge>
                      ))}
                    </div>
                  </div>
                  <Button variant="outline" size="sm" className="border-gray-800 text-red-500" onClick={() => deleteWebhookMutation.mutate(webhook.id)}>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
                <div className="grid grid-cols-3 gap-4 text-sm">
                  <div><span className="text-gray-500">Success:</span> {webhook.success_count}</div>
                  <div><span className="text-gray-500">Failures:</span> {webhook.failure_count}</div>
                  <div><Badge className={webhook.active ? 'bg-[#00C853]' : 'bg-gray-700'}>{webhook.active ? 'Active' : 'Inactive'}</Badge></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function CreateAPIKeyDialog() {
  const [name, setName] = useState('');
  const [open, setOpen] = useState(false);
  const queryClient = useQueryClient();

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.APIKey.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['api-keys'] });
      setOpen(false);
      setName('');
    }
  });

  const handleCreate = () => {
    const key = 'sk_' + Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
    createMutation.mutate({ name, key, permissions: ['read', 'write'] });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="bg-[#0066B1]"><Plus className="w-4 h-4 mr-2" />Create API Key</Button>
      </DialogTrigger>
      <DialogContent className="bg-black border-gray-900 text-white">
        <DialogHeader><DialogTitle>Create API Key</DialogTitle></DialogHeader>
        <div className="space-y-4">
          <Input placeholder="API Key Name" value={name} onChange={(e) => setName(e.target.value)} className="bg-gray-950 border-gray-800" />
          <Button onClick={handleCreate} className="w-full bg-[#E22718]">Create</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function CreateWebhookDialog() {
  const [formData, setFormData] = useState({ name: '', url: '', events: [] });
  const [open, setOpen] = useState(false);
  const queryClient = useQueryClient();

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.WebhookConfig.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['webhooks'] });
      setOpen(false);
      setFormData({ name: '', url: '', events: [] });
    }
  });

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="bg-[#0066B1]"><Plus className="w-4 h-4 mr-2" />Create Webhook</Button>
      </DialogTrigger>
      <DialogContent className="bg-black border-gray-900 text-white">
        <DialogHeader><DialogTitle>Create Webhook</DialogTitle></DialogHeader>
        <div className="space-y-4">
          <Input placeholder="Webhook Name" value={formData.name} onChange={(e) => setFormData({...formData, name: e.target.value})} className="bg-gray-950 border-gray-800" />
          <Input placeholder="URL" value={formData.url} onChange={(e) => setFormData({...formData, url: e.target.value})} className="bg-gray-950 border-gray-800" />
          <Button onClick={() => createMutation.mutate({ ...formData, secret: Math.random().toString(36) })} className="w-full bg-[#E22718]">Create</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}