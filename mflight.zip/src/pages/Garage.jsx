import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { 
  Wrench, Plus, Trash2, Edit, Video, Upload, X, Loader2,
  Package, Gauge, Zap, ArrowLeft, Image, Share2, MessageCircle
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import GarageSlideshow from '@/components/garage/GarageSlideshow';

const CATEGORIES = {
  tool: { icon: Wrench, color: 'text-blue-400', label: 'Tools' },
  tire: { icon: Package, color: 'text-yellow-400', label: 'Tires' },
  rim: { icon: Gauge, color: 'text-purple-400', label: 'Rims' },
  part: { icon: Zap, color: 'text-green-400', label: 'Parts' }
};

export default function Garage() {
  const [user, setUser] = useState(null);
  const [garage, setGarage] = useState(null);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [isAddItemOpen, setIsAddItemOpen] = useState(false);
  const [isAddVideoOpen, setIsAddVideoOpen] = useState(false);
  const [itemForm, setItemForm] = useState({ category: 'tool', name: '', brand: '', video_url: '', for_sale: false, for_trade: false, sale_price: '' });
  const [videoForm, setVideoForm] = useState({ youtube_url: '', category: 'how-to' });
  const [isUploading, setIsUploading] = useState(false);
  const [isShareOpen, setIsShareOpen] = useState(false);
  const [shareSlide, setShareSlide] = useState(null);
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const fileInputRef = React.useRef(null);
  const quickImageInputRef = React.useRef(null);

  const urlParams = new URLSearchParams(window.location.search);
  const garageId = urlParams.get('id');

  useEffect(() => {
    const loadUser = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    };
    loadUser();
  }, []);

  const { data: garages = [] } = useQuery({
    queryKey: ['garages', user?.email],
    queryFn: () => base44.entities.Garage.filter({ owner_email: user?.email }),
    enabled: !!user?.email,
  });

  useEffect(() => {
    if (garages.length > 0 && garageId) {
      const found = garages.find(g => g.id === garageId);
      setGarage(found);
    } else if (garages.length > 0) {
      setGarage(garages[0]);
    }
  }, [garages, garageId]);

  const { data: cars = [] } = useQuery({
    queryKey: ['cars', garage?.id],
    queryFn: () => base44.entities.Car.filter({ garage_id: garage?.id }),
    enabled: !!garage?.id,
  });

  const { data: items = [] } = useQuery({
    queryKey: ['garage-items', garage?.id],
    queryFn: () => base44.entities.GarageItem.filter({ garage_id: garage?.id }),
    enabled: !!garage?.id,
  });

  const { data: videos = [] } = useQuery({
    queryKey: ['garage-videos', garage?.id],
    queryFn: () => base44.entities.GarageVideo.filter({ garage_id: garage?.id }),
    enabled: !!garage?.id,
  });

  const addItemMutation = useMutation({
    mutationFn: (data) => base44.entities.GarageItem.create({
      garage_id: garage.id,
      owner_email: user.email,
      ...data
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['garage-items'] });
      setItemForm({ category: 'tool', name: '', brand: '', video_url: '', for_sale: false, for_trade: false, sale_price: '' });
      setIsAddItemOpen(false);
    },
  });

  const addVideoMutation = useMutation({
    mutationFn: (data) => {
      const videoId = extractYoutubeId(data.youtube_url);
      return base44.entities.GarageVideo.create({
        garage_id: garage.id,
        owner_email: user.email,
        youtube_video_id: videoId,
        title: data.youtube_url.includes('youtube.com') ? 'YouTube Video' : 'Video',
        ...data
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['garage-videos'] });
      setVideoForm({ youtube_url: '', category: 'how-to' });
      setIsAddVideoOpen(false);
    },
  });

  const deleteItemMutation = useMutation({
    mutationFn: (id) => base44.entities.GarageItem.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['garage-items'] }),
  });

  const deleteVideoMutation = useMutation({
    mutationFn: (id) => base44.entities.GarageVideo.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['garage-videos'] }),
  });

  const extractYoutubeId = (url) => {
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
    const match = url.match(regExp);
    return (match && match[2].length === 11) ? match[2] : null;
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    try {
      const response = await base44.integrations.Core.UploadFile({ file });
      setItemForm({ ...itemForm, image_url: response.file_url });
    } catch (error) {
      console.error('Upload failed:', error);
    } finally {
      setIsUploading(false);
    }
  };

  const handleQuickImageUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    try {
      const response = await base44.integrations.Core.UploadFile({ file });
      await base44.entities.GarageItem.create({
        garage_id: garage.id,
        owner_email: user.email,
        category: 'part',
        name: file.name.split('.')[0] || 'Garage Image',
        image_url: response.file_url
      });
      queryClient.invalidateQueries({ queryKey: ['garage-items'] });
    } catch (error) {
      console.error('Upload failed:', error);
    } finally {
      setIsUploading(false);
    }
  };

  const isOwnGarage = user?.email === garage?.owner_email;

  const filteredItems = selectedCategory === 'all' 
    ? items 
    : items.filter(i => i.category === selectedCategory);

  if (!garage) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-black">
        <Loader2 className="w-8 h-8 animate-spin text-[#0066B1]" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white pb-20">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-7xl mx-auto px-6 py-8"
      >
        <Button
          variant="ghost"
          onClick={() => navigate(-1)}
          className="text-gray-400 hover:text-white mb-6 text-xs uppercase tracking-wider"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>

        {/* Garage Hero */}
        <div className="bg-gradient-to-r from-gray-950 to-black border border-gray-900 p-8 mb-8">
          <div className="flex items-start justify-between">
            <div>
              <h1 className="text-4xl font-light uppercase tracking-wider mb-2">{garage.name}</h1>
              <p className="text-gray-500 text-sm uppercase tracking-widest">{garage.description}</p>
            </div>
            {isOwnGarage && (
              <div className="flex gap-2">
                <Button 
                  onClick={() => quickImageInputRef.current?.click()}
                  className="bg-[#0066B1] hover:bg-[#0055A0]"
                  disabled={isUploading}
                >
                  {isUploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
                </Button>
                <input
                  ref={quickImageInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleQuickImageUpload}
                  className="hidden"
                />
                <Dialog open={isAddItemOpen} onOpenChange={setIsAddItemOpen}>
                  <DialogTrigger asChild>
                    <Button className="bg-[#0066B1] hover:bg-[#0055A0]">
                      <Plus className="w-4 h-4 mr-2" />
                      Add Item
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="bg-gray-900 border-gray-700">
                    <DialogHeader>
                      <DialogTitle className="text-white">Add Garage Item</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div>
                        <label className="text-xs text-gray-300 uppercase tracking-wider mb-2 block">Category</label>
                        <Select value={itemForm.category} onValueChange={(val) => setItemForm({...itemForm, category: val})}>
                          <SelectTrigger className="bg-gray-800 border-gray-600 text-white hover:border-[#0066B1]">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent className="bg-gray-800 border-gray-600 text-white">
                            {Object.keys(CATEGORIES).map(cat => (
                              <SelectItem key={cat} value={cat} className="text-white">{CATEGORIES[cat].label}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <Input
                        placeholder="Item name"
                        value={itemForm.name}
                        onChange={(e) => setItemForm({...itemForm, name: e.target.value})}
                        className="bg-gray-800 border-gray-600 text-white placeholder-gray-500"
                      />
                      <Input
                        placeholder="Brand"
                        value={itemForm.brand}
                        onChange={(e) => setItemForm({...itemForm, brand: e.target.value})}
                        className="bg-gray-800 border-gray-600 text-white placeholder-gray-500"
                      />
                      <Input
                        placeholder="Video URL (YouTube)"
                        value={itemForm.video_url}
                        onChange={(e) => setItemForm({...itemForm, video_url: e.target.value})}
                        className="bg-gray-800 border-gray-600 text-white placeholder-gray-500"
                      />
                      <div className="flex gap-4">
                        <label className="flex items-center gap-2 text-sm text-gray-300">
                          <input
                            type="checkbox"
                            checked={itemForm.for_sale}
                            onChange={(e) => setItemForm({...itemForm, for_sale: e.target.checked})}
                            className="w-4 h-4"
                          />
                          For Sale
                        </label>
                        <label className="flex items-center gap-2 text-sm text-gray-300">
                          <input
                            type="checkbox"
                            checked={itemForm.for_trade}
                            onChange={(e) => setItemForm({...itemForm, for_trade: e.target.checked})}
                            className="w-4 h-4"
                          />
                          For Trade
                        </label>
                      </div>
                      {itemForm.for_sale && (
                        <Input
                          type="number"
                          placeholder="Sale Price"
                          value={itemForm.sale_price}
                          onChange={(e) => setItemForm({...itemForm, sale_price: e.target.value})}
                          className="bg-gray-800 border-gray-600 text-white placeholder-gray-500"
                        />
                      )}
                      <div>
                        <label className="text-xs text-gray-300 uppercase tracking-wider mb-2 block">Image</label>
                        <button
                          onClick={() => fileInputRef.current?.click()}
                          className="w-full border-2 border-dashed border-gray-600 p-4 text-center hover:border-[#0066B1] transition text-gray-400"
                        >
                          {isUploading ? 'Uploading...' : 'Click to upload image'}
                        </button>
                        <input
                          ref={fileInputRef}
                          type="file"
                          accept="image/*"
                          onChange={handleImageUpload}
                          className="hidden"
                        />
                        {itemForm.image_url && (
                          <p className="text-xs text-green-400 mt-2">Image added</p>
                        )}
                      </div>
                      <Button
                        onClick={() => addItemMutation.mutate(itemForm)}
                        className="w-full bg-[#0066B1] hover:bg-[#0055A0]"
                        disabled={!itemForm.name}
                      >
                        Add Item
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>

                <Dialog open={isAddVideoOpen} onOpenChange={setIsAddVideoOpen}>
                  <DialogTrigger asChild>
                    <Button className="bg-[#E22718] hover:bg-[#CC1F14]">
                      <Video className="w-4 h-4 mr-2" />
                      Add Video
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="bg-black border-gray-900">
                    <DialogHeader>
                      <DialogTitle className="text-white">Add YouTube Video</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div>
                        <label className="text-xs text-gray-400 uppercase tracking-wider mb-2 block">Type</label>
                        <Select value={videoForm.category} onValueChange={(val) => setVideoForm({...videoForm, category: val})}>
                          <SelectTrigger className="bg-gray-950 border-gray-800 text-white">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent className="bg-black border-gray-800">
                            <SelectItem value="how-to">How-to</SelectItem>
                            <SelectItem value="build">Build</SelectItem>
                            <SelectItem value="maintenance">Maintenance</SelectItem>
                            <SelectItem value="review">Review</SelectItem>
                            <SelectItem value="tutorial">Tutorial</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <Input
                        placeholder="YouTube URL (https://youtube.com/watch?v=...)"
                        value={videoForm.youtube_url}
                        onChange={(e) => setVideoForm({...videoForm, youtube_url: e.target.value})}
                        className="bg-gray-950 border-gray-800 text-white"
                      />
                      <Button
                        onClick={() => addVideoMutation.mutate(videoForm)}
                        className="w-full bg-[#E22718] hover:bg-[#CC1F14]"
                        disabled={!videoForm.youtube_url}
                      >
                        Add Video
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            )}
          </div>
        </div>
      </motion.div>

      <div className="max-w-7xl mx-auto px-6 space-y-8">
        {/* Slideshow */}
        <GarageSlideshow 
          items={items} 
          videos={videos} 
          isOwnGarage={isOwnGarage}
          onDeleteItem={(id) => deleteItemMutation.mutate(id)}
          onDeleteVideo={(id) => deleteVideoMutation.mutate(id)}
          onAddImage={() => quickImageInputRef.current?.click()}
          onShare={(slide) => {
            setShareSlide(slide);
            setIsShareOpen(true);
          }}
        />

        {/* Vehicles Section */}
        {cars.length > 0 && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-light uppercase tracking-wider">Vehicles</h2>
              {isOwnGarage && (
                <Button
                  onClick={() => quickImageInputRef.current?.click()}
                  size="icon"
                  className="bg-[#0066B1] hover:bg-[#0055A0]"
                  disabled={isUploading}
                >
                  {isUploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
                </Button>
              )}
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {cars.map(car => (
                <Link key={car.id} to={createPageUrl(`CarDetail?id=${car.id}`)}>
                  <div className="bg-gray-950 border border-gray-900 overflow-hidden hover:border-[#0066B1] transition group">
                    {car.image_url && (
                      <div className="h-48 overflow-hidden">
                        <img src={car.image_url} alt={car.name} className="w-full h-full object-cover group-hover:scale-105 transition" />
                      </div>
                    )}
                    <div className="p-4">
                      <h3 className="text-white font-light uppercase tracking-wide">{car.name || car.model}</h3>
                      <p className="text-gray-500 text-xs uppercase tracking-wider">{car.year} {car.make}</p>
                      {car.specifications?.horsepower && (
                        <p className="text-[#E22718] text-sm mt-2">{car.specifications.horsepower}</p>
                      )}
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </motion.div>
        )}

        {/* Items Section */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-light uppercase tracking-wider">Equipment</h2>
            <div className="flex items-center gap-2">
              {isOwnGarage && (
                <Button
                  onClick={() => setIsAddItemOpen(true)}
                  size="icon"
                  className="bg-[#0066B1] hover:bg-[#0055A0]"
                >
                  <Plus className="w-4 h-4" />
                </Button>
              )}
              <div className="flex gap-2">
                {['all', ...Object.keys(CATEGORIES)].map(cat => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-4 py-2 text-xs uppercase tracking-wider transition ${
                      selectedCategory === cat
                        ? 'bg-[#0066B1] text-white'
                        : 'bg-gray-950 border border-gray-900 text-gray-400 hover:border-[#0066B1]'
                    }`}
                  >
                    {cat === 'all' ? 'All' : CATEGORIES[cat].label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {filteredItems.length > 0 ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
              {filteredItems.map(item => {
                const Cat = CATEGORIES[item.category];
                return (
                  <motion.div
                    key={item.id}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="bg-gray-950 border border-gray-900 p-4 group"
                  >
                    {item.image_url && (
                      <img src={item.image_url} alt={item.name} className="w-full h-32 object-cover mb-3 border border-gray-800" />
                    )}
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h3 className="text-white font-light uppercase tracking-wide text-sm">{item.name}</h3>
                        <p className="text-gray-500 text-xs">{item.brand}</p>
                      </div>
                      {isOwnGarage && (
                        <button
                          onClick={() => deleteItemMutation.mutate(item.id)}
                          className="text-gray-500 hover:text-[#E22718] transition opacity-0 group-hover:opacity-100"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                    <div className="flex items-center justify-between mb-2">
                      {item.condition && (
                        <span className="text-xs text-gray-500 uppercase tracking-wider">{item.condition}</span>
                      )}
                      {item.for_sale && item.sale_price && (
                        <div className="flex items-center gap-2">
                          <span className="text-sm text-[#0066B1] font-medium">${item.sale_price}</span>
                          <Link to={createPageUrl('Messages')}>
                            <button className="text-[#0066B1] hover:text-[#0055A0] transition">
                              <MessageCircle className="w-4 h-4" />
                            </button>
                          </Link>
                        </div>
                      )}
                    </div>
                     {(item.for_sale || item.for_trade) && (
                       <div className="flex gap-2 text-xs">
                         {item.for_sale && <span className="bg-[#0066B1]/20 text-[#0066B1] px-2 py-1 rounded">For Sale</span>}
                         {item.for_trade && <span className="bg-[#E22718]/20 text-[#E22718] px-2 py-1 rounded">For Trade</span>}
                       </div>
                     )}
                  </motion.div>
                );
              })}
            </div>
          ) : (
            <div className="bg-gray-950 border border-gray-900 p-8 text-center text-gray-500">
              No items yet
            </div>
          )}
        </motion.div>

        {/* Videos Section */}
        {videos.length > 0 && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-light uppercase tracking-wider">How-to Videos</h2>
              {isOwnGarage && (
                <Button
                  onClick={() => setIsAddVideoOpen(true)}
                  size="icon"
                  className="bg-[#E22718] hover:bg-[#CC1F14]"
                >
                  <Plus className="w-4 h-4" />
                </Button>
              )}
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {videos.map(video => (
                <motion.a
                  key={video.id}
                  href={`https://youtube.com/watch?v=${video.youtube_video_id}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  whileHover={{ scale: 1.02 }}
                  className="group"
                >
                  <div className="bg-black border border-gray-900 overflow-hidden hover:border-[#E22718] transition relative">
                    <img
                      src={`https://img.youtube.com/vi/${video.youtube_video_id}/maxresdefault.jpg`}
                      alt="Video"
                      className="w-full h-48 object-cover"
                    />
                    <div className="absolute inset-0 bg-black/60 group-hover:bg-black/40 transition flex items-center justify-center">
                      <Video className="w-12 h-12 text-[#E22718]" />
                    </div>
                    <div className="p-4">
                      <span className="text-xs text-gray-500 uppercase tracking-wider">{video.category}</span>
                      {isOwnGarage && (
                        <button
                          onClick={(e) => {
                            e.preventDefault();
                            deleteVideoMutation.mutate(video.id);
                          }}
                          className="absolute top-2 right-2 p-2 bg-black border border-gray-800 hover:border-[#E22718] text-gray-500 hover:text-[#E22718] transition"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                </motion.a>
              ))}
            </div>
          </motion.div>
        )}
        </div>

        {/* Share Dialog */}
        <Dialog open={isShareOpen} onOpenChange={setIsShareOpen}>
        <DialogContent className="bg-gray-900 border-gray-700">
          <DialogHeader>
            <DialogTitle className="text-white">Share</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <button
              onClick={() => {
                const url = encodeURIComponent(window.location.href);
                const text = encodeURIComponent(`Check out my ${garage?.name}!`);
                window.open(`https://www.facebook.com/sharer/sharer.php?u=${url}`, '_blank');
                setIsShareOpen(false);
              }}
              className="w-full flex items-center gap-3 p-4 bg-[#1877F2] hover:bg-[#166FE5] text-white transition"
            >
              <Share2 className="w-5 h-5" />
              <span>Share on Facebook</span>
            </button>
            <button
              onClick={() => {
                navigator.clipboard.writeText(window.location.href);
                alert('Link copied! Open Instagram and paste in your story or post.');
                setIsShareOpen(false);
              }}
              className="w-full flex items-center gap-3 p-4 bg-gradient-to-r from-[#833AB4] via-[#FD1D1D] to-[#F77737] hover:opacity-90 text-white transition"
            >
              <Share2 className="w-5 h-5" />
              <span>Share on Instagram</span>
            </button>
            {shareSlide?.type === 'video' && shareSlide?.videoId && (
              <button
                onClick={() => {
                  window.open(`https://youtube.com/watch?v=${shareSlide.videoId}`, '_blank');
                  setIsShareOpen(false);
                }}
                className="w-full flex items-center gap-3 p-4 bg-[#FF0000] hover:bg-[#CC0000] text-white transition"
              >
                <Video className="w-5 h-5" />
                <span>Open on YouTube</span>
              </button>
            )}
          </div>
        </DialogContent>
        </Dialog>
        </div>
        );
        }