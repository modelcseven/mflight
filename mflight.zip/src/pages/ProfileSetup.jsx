import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { MapPin, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const MILITARY_BASES = {
  Belgium: [
    'Chievres Air Base',
    'Kleine Brogel Air Base',
    'US Army Garrison (USAG) Benelux Brussels',
    'US Army Garrison (USAG) Benelux Chievres',
    'US Army Garrison (USAG) Benelux SHAPE'
  ],
  Bulgaria: [
    'Aitos Logistics Center',
    'Bezmer Air Base',
    'Graf Ignatievo Air Base',
    'Novo Selo Range'
  ],
  Germany: [
    'Ansbach US Army Garrison',
    'Buechel Air Base',
    'Geilenkirchen NATO Air Base',
    'Kalkar US Air Force Element',
    'Ramstein Air Base',
    'Spangdahlem Air Base',
    'US Army Garrison (USAG) Bavaria',
    'US Army Garrison (USAG) Bavaria Garmisch',
    'US Army Garrison (USAG) Bavaria Hohenfels',
    'US Army Garrison (USAG) Rheinland-Pfalz Kaiserslautern Military Community',
    'US Army Garrison (USAG) Rheinland-Pfalz Baumholder',
    'US Army Garrison (USAG) Stuttgart',
    'US Army Garrison (USAG) Wiesbaden'
  ],
  Greece: ['Souda Bay Naval Support Activity'],
  Italy: [
    'Aviano Air Base',
    'Camp Darby',
    'Ghedi Air Base',
    'Naval Support Activity (NSA) Gaeta',
    'Naval Support Activity (NSA) Naples',
    'Naval Air Station (NAS) Sigonella',
    'US Army Garrison (USAG) Italy (Vicenza)',
    'US Army Garrison (USAG) Livorno'
  ],
  Kosovo: ['Camp Bondsteel'],
  Netherlands: [
    'US Army Garrison (USAG) Benelux Brunssum',
    'Volkel Air Base'
  ],
  Norway: ['Marine Corps Prepositioning Program-Norway'],
  Poland: [
    'Lask Air Base',
    'US Army Garrison (USAG) Poland'
  ],
  Portugal: ['Lajes Field'],
  Romania: [
    'Deveselu Naval Base',
    'Mihail Kogalniceanu Air Base'
  ],
  Spain: [
    'Moron Air Base',
    'Naval Station (NS) Rota'
  ],
  Turkey: [
    'Incirlik Air Base',
    'Izmir Air Station'
  ],
  'United Kingdom': [
    'RAF Alconbury',
    'RAF Croughton',
    'RAF Fairford',
    'RAF Lakenheath',
    'RAF Menwith Hill',
    'RAF Mildenhall',
    'RAF Molesworth'
  ]
};

const USA_STATES = [
  'Alabama', 'Alaska', 'Arizona', 'Arkansas', 'California', 'Colorado', 'Connecticut', 'Delaware',
  'Florida', 'Georgia', 'Hawaii', 'Idaho', 'Illinois', 'Indiana', 'Iowa', 'Kansas', 'Kentucky',
  'Louisiana', 'Maine', 'Maryland', 'Massachusetts', 'Michigan', 'Minnesota', 'Mississippi',
  'Missouri', 'Montana', 'Nebraska', 'Nevada', 'New Hampshire', 'New Jersey', 'New Mexico',
  'New York', 'North Carolina', 'North Dakota', 'Ohio', 'Oklahoma', 'Oregon', 'Pennsylvania',
  'Rhode Island', 'South Carolina', 'South Dakota', 'Tennessee', 'Texas', 'Utah', 'Vermont',
  'Virginia', 'Washington', 'West Virginia', 'Wisconsin', 'Wyoming'
];

export default function ProfileSetup() {
  const [user, setUser] = useState(null);
  const [region, setRegion] = useState('');
  const [country, setCountry] = useState('');
  const [militaryBase, setMilitaryBase] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const loadUser = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
      if (currentUser.region) {
        setRegion(currentUser.region);
        setCountry(currentUser.country || '');
        setMilitaryBase(currentUser.military_base || '');
      }
    };
    loadUser();
  }, []);

  const handleSave = async () => {
    await base44.auth.updateMe({
      region,
      country: region === 'Europe' ? country : null,
      military_base: militaryBase,
      location: region === 'Europe' ? `${militaryBase}, ${country}` : militaryBase
    });
    navigate(createPageUrl('Home'));
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-black text-white flex items-center justify-center px-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-2xl w-full"
      >
        <div className="bg-gray-950 border border-gray-900 p-8">
          <div className="flex items-center gap-3 mb-6">
            <MapPin className="w-8 h-8 text-[#0066B1]" />
            <div>
              <h1 className="text-2xl font-light uppercase tracking-wider">Location Setup</h1>
              <p className="text-gray-500 text-sm">Select your region and base</p>
            </div>
          </div>

          <div className="space-y-6">
            {/* Region Selection */}
            <div>
              <label className="text-sm text-gray-400 mb-2 block uppercase tracking-wider">Region</label>
              <Select value={region} onValueChange={(val) => { setRegion(val); setCountry(''); setMilitaryBase(''); }}>
                <SelectTrigger className="bg-black border-gray-800 text-white">
                  <SelectValue placeholder="Select Region" />
                </SelectTrigger>
                <SelectContent className="bg-black border-gray-800">
                  <SelectItem value="USA">USA</SelectItem>
                  <SelectItem value="Europe">Europe</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Country Selection (Europe only) */}
            {region === 'Europe' && (
              <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
                <label className="text-sm text-gray-400 mb-2 block uppercase tracking-wider">Country</label>
                <Select value={country} onValueChange={(val) => { setCountry(val); setMilitaryBase(''); }}>
                  <SelectTrigger className="bg-black border-gray-800 text-white">
                    <SelectValue placeholder="Select Country" />
                  </SelectTrigger>
                  <SelectContent className="bg-black border-gray-800 max-h-60">
                    {Object.keys(MILITARY_BASES).map(c => (
                      <SelectItem key={c} value={c}>{c}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </motion.div>
            )}

            {/* USA State Selection */}
            {region === 'USA' && (
              <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
                <label className="text-sm text-gray-400 mb-2 block uppercase tracking-wider">State</label>
                <Select value={country} onValueChange={setCountry}>
                  <SelectTrigger className="bg-black border-gray-800 text-white">
                    <SelectValue placeholder="Select State" />
                  </SelectTrigger>
                  <SelectContent className="bg-black border-gray-800 max-h-60">
                    {USA_STATES.map(state => (
                      <SelectItem key={state} value={state}>{state}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </motion.div>
            )}

            {/* Base Selection */}
            {region === 'Europe' && country && (
              <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
                <label className="text-sm text-gray-400 mb-2 block uppercase tracking-wider">Military Base</label>
                <Select value={militaryBase} onValueChange={setMilitaryBase}>
                  <SelectTrigger className="bg-black border-gray-800 text-white">
                    <SelectValue placeholder="Select Base" />
                  </SelectTrigger>
                  <SelectContent className="bg-black border-gray-800 max-h-60">
                    {MILITARY_BASES[country]?.map(base => (
                      <SelectItem key={base} value={base}>{base}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </motion.div>
            )}

            {region === 'USA' && country && (
              <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
                <label className="text-sm text-gray-400 mb-2 block uppercase tracking-wider">Military Base / Location</label>
                <Select value={militaryBase} onValueChange={setMilitaryBase}>
                  <SelectTrigger className="bg-black border-gray-800 text-white">
                    <SelectValue placeholder="Select Base" />
                  </SelectTrigger>
                  <SelectContent className="bg-black border-gray-800">
                    <SelectItem value={`${country} Base`}>{country} Base</SelectItem>
                  </SelectContent>
                </Select>
              </motion.div>
            )}

            {/* Save Button */}
            <Button
              onClick={handleSave}
              disabled={!region || (region === 'Europe' && (!country || !militaryBase)) || (region === 'USA' && !country)}
              className="w-full bg-[#0066B1] hover:bg-[#0055A0] py-6"
            >
              Save Location
              <ChevronRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}