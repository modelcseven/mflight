import React from 'react';
import BMWHud from '../components/bmw/BMWHud.jsx';

export default function BMWHUDPage() {
  return <BMWHud />;
}