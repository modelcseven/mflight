import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { Car, Zap, MapPin, Briefcase, GraduationCap, Calendar, Heart, Award, Gauge, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function Bio() {
  const [user, setUser] = useState(null);
  const [profileUser, setProfileUser] = useState(null);
  const navigate = useNavigate();

  const urlParams = new URLSearchParams(window.location.search);
  const profileEmail = urlParams.get('email');

  useEffect(() => {
    const loadUsers = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    };
    loadUsers();
  }, []);

  const { data: users = [] } = useQuery({
    queryKey: ['users'],
    queryFn: () => base44.entities.User.list(),
    enabled: !!profileEmail,
  });

  useEffect(() => {
    if (users.length > 0 && profileEmail) {
      const found = users.find(u => u.email === profileEmail);
      setProfileUser(found);
    }
  }, [users, profileEmail]);

  const { data: garages = [] } = useQuery({
    queryKey: ['garages', profileEmail],
    queryFn: () => base44.entities.Garage.filter({ owner_email: profileEmail }),
    enabled: !!profileEmail && !!profileUser,
  });

  const { data: cars = [] } = useQuery({
    queryKey: ['cars', profileEmail],
    queryFn: () => base44.entities.Car.filter({ owner_email: profileEmail }),
    enabled: !!profileEmail && !!profileUser,
  });

  const isOwnProfile = user?.email === profileEmail;
  const avatar = profileUser?.avatar || `https://ui-avatars.com/api/?name=${profileUser?.full_name || 'User'}&background=0066B1&color=fff&size=200`;

  if (!profileUser) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-black">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#0066B1]" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white pb-20">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-5xl mx-auto px-6 py-8"
      >
        <Button
          variant="ghost"
          onClick={() => navigate(-1)}
          className="text-gray-400 hover:text-white mb-6 text-xs uppercase tracking-wider"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Profile
        </Button>

        {/* Profile Hero */}
        <div className="bg-gradient-to-br from-gray-950 to-black border border-gray-900 p-8 mb-6">
          <div className="flex items-start gap-6">
            <div className="relative">
              <img
                src={avatar}
                alt={profileUser.full_name}
                className="w-24 h-24 rounded-full border-2 border-[#0066B1] object-cover"
              />
              <div className="absolute -bottom-2 -right-2 bg-[#E22718] rounded-full p-2">
                <Car className="w-4 h-4 text-white" />
              </div>
            </div>
            <div className="flex-1">
              <h1 className="text-3xl font-light uppercase tracking-wider text-white mb-2">
                {profileUser.full_name}
              </h1>
              <p className="text-gray-500 text-sm uppercase tracking-widest mb-4">
                BMW Enthusiast • MFlight Member
              </p>
              <div className="flex gap-3">
                <div className="bg-black border border-gray-900 px-4 py-2">
                  <span className="text-[#0066B1] font-light text-lg">{garages.length}</span>
                  <span className="text-gray-500 text-xs ml-2 uppercase">Garages</span>
                </div>
                <div className="bg-black border border-gray-900 px-4 py-2">
                  <span className="text-[#E22718] font-light text-lg">{cars.length}</span>
                  <span className="text-gray-500 text-xs ml-2 uppercase">Vehicles</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Bio Content */}
      <div className="max-w-5xl mx-auto px-6 grid md:grid-cols-2 gap-6">
        {/* Left Column - Info Cards */}
        <div className="space-y-6">
          {/* Personal Details */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-gray-950 border border-gray-900 p-6"
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 bg-[#0066B1]/10 border border-[#0066B1]/20">
                <Gauge className="w-5 h-5 text-[#0066B1]" />
              </div>
              <h2 className="text-sm uppercase tracking-wider text-white">Personal Info</h2>
            </div>
            <div className="space-y-4">
              {profileUser.location && (
                <div className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 text-gray-500 mt-0.5" />
                  <div>
                    <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Location</p>
                    <p className="text-white">{profileUser.location}</p>
                  </div>
                </div>
              )}
              {profileUser.work && (
                <div className="flex items-start gap-3">
                  <Briefcase className="w-5 h-5 text-gray-500 mt-0.5" />
                  <div>
                    <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Work</p>
                    <p className="text-white">{profileUser.work}</p>
                  </div>
                </div>
              )}
              {profileUser.education && (
                <div className="flex items-start gap-3">
                  <GraduationCap className="w-5 h-5 text-gray-500 mt-0.5" />
                  <div>
                    <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Education</p>
                    <p className="text-white">{profileUser.education}</p>
                  </div>
                </div>
              )}
              <div className="flex items-start gap-3">
                <Calendar className="w-5 h-5 text-gray-500 mt-0.5" />
                <div>
                  <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Member Since</p>
                  <p className="text-white">
                    {new Date(profileUser.created_date).toLocaleDateString('en-US', { 
                      month: 'long', 
                      year: 'numeric' 
                    })}
                  </p>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Bio Text */}
          {profileUser.bio && (
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
              className="bg-gray-950 border border-gray-900 p-6"
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-[#E22718]/10 border border-[#E22718]/20">
                  <Zap className="w-5 h-5 text-[#E22718]" />
                </div>
                <h2 className="text-sm uppercase tracking-wider text-white">About Me</h2>
              </div>
              <p className="text-gray-300 leading-relaxed">{profileUser.bio}</p>
            </motion.div>
          )}
        </div>

        {/* Right Column - Garage Highlights */}
        <div className="space-y-6">
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-gray-950 border border-gray-900 p-6"
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 bg-[#FFB300]/10 border border-[#FFB300]/20">
                <Car className="w-5 h-5 text-[#FFB300]" />
              </div>
              <h2 className="text-sm uppercase tracking-wider text-white">Garage Collection</h2>
            </div>
            
            {cars.length > 0 ? (
              <div className="space-y-4">
                {cars.slice(0, 3).map((car) => (
                  <Link
                    key={car.id}
                    to={createPageUrl(`CarDetail?id=${car.id}`)}
                    className="block group"
                  >
                    <div className="bg-black border border-gray-900 p-4 hover:border-[#0066B1] transition-all">
                      <div className="flex items-center gap-4">
                        {car.image_url && (
                          <img
                            src={car.image_url}
                            alt={car.name}
                            className="w-20 h-20 object-cover border border-gray-800"
                          />
                        )}
                        <div className="flex-1">
                          <h3 className="text-white font-light uppercase tracking-wide mb-1">
                            {car.name || car.model}
                          </h3>
                          <p className="text-gray-500 text-xs uppercase tracking-wider">
                            {car.year} {car.make} {car.model}
                          </p>
                          {car.specifications?.horsepower && (
                            <div className="flex items-center gap-2 mt-2">
                              <Gauge className="w-3 h-3 text-[#E22718]" />
                              <span className="text-[#E22718] text-xs">{car.specifications.horsepower}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </Link>
                ))}
                {cars.length > 3 && (
                  <Link to={createPageUrl(`Profile?email=${profileEmail}`)}>
                    <Button variant="outline" className="w-full border-gray-800 text-gray-400 hover:text-white hover:border-[#0066B1]">
                      View All {cars.length} Vehicles
                    </Button>
                  </Link>
                )}
              </div>
            ) : (
              <div className="text-center py-8">
                <Car className="w-12 h-12 text-gray-700 mx-auto mb-3" />
                <p className="text-gray-600 text-xs uppercase tracking-wider">No vehicles yet</p>
              </div>
            )}
          </motion.div>

          {/* Achievements */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-gray-950 border border-gray-900 p-6"
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 bg-[#00C853]/10 border border-[#00C853]/20">
                <Award className="w-5 h-5 text-[#00C853]" />
              </div>
              <h2 className="text-sm uppercase tracking-wider text-white">Achievements</h2>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {garages.length > 0 && (
                <div className="bg-black border border-gray-900 p-4 text-center">
                  <div className="text-2xl font-light text-[#0066B1] mb-1">{garages.length}</div>
                  <p className="text-xs text-gray-500 uppercase tracking-wider">Garages</p>
                </div>
              )}
              {cars.length > 0 && (
                <div className="bg-black border border-gray-900 p-4 text-center">
                  <div className="text-2xl font-light text-[#E22718] mb-1">{cars.length}</div>
                  <p className="text-xs text-gray-500 uppercase tracking-wider">Builds</p>
                </div>
              )}
              <div className="bg-black border border-gray-900 p-4 text-center">
                <div className="text-2xl font-light text-[#FFB300] mb-1">
                  {new Date().getFullYear() - new Date(profileUser.created_date).getFullYear()}
                </div>
                <p className="text-xs text-gray-500 uppercase tracking-wider">Years</p>
              </div>
              <div className="bg-black border border-gray-900 p-4 text-center">
                <div className="text-2xl font-light text-[#00C853] mb-1">BMW</div>
                <p className="text-xs text-gray-500 uppercase tracking-wider">Lover</p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}