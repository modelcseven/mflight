import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Plus, ArrowLeft, Edit, Trash2, Zap, Gauge, Fuel } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { motion, AnimatePresence } from 'framer-motion';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import MaintenanceSection from '@/components/garage/MaintenanceSection';
import InsuranceSection from '@/components/garage/InsuranceSection';
import FuelSection from '@/components/garage/FuelSection';
import ExpenseTracker from '@/components/garage/ExpenseTracker';

function CarCard({ car, onEdit, onDelete }) {
  const totalModCost = car.mods?.reduce((sum, mod) => sum + (parseFloat(mod.cost) || 0), 0) || 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-gray-800 border border-gray-700 rounded-lg overflow-hidden hover:border-cyan-500 transition-colors group"
    >
      {car.image_url && (
        <div className="h-48 overflow-hidden bg-gray-700">
          <img src={car.image_url} alt={car.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300" />
        </div>
      )}
      <div className="p-4">
        <h3 className="text-xl font-bold text-white mb-1">{car.name}</h3>
        <p className="text-cyan-400 text-sm mb-3">{car.year} {car.make} {car.model}</p>

        {car.specifications && (
          <div className="grid grid-cols-2 gap-2 mb-4 text-sm">
            {car.specifications.horsepower && (
              <div className="flex items-center gap-1 text-gray-400">
                <Zap className="w-4 h-4 text-yellow-500" />
                <span>{car.specifications.horsepower}</span>
              </div>
            )}
            {car.specifications.torque && (
              <div className="flex items-center gap-1 text-gray-400">
                <Gauge className="w-4 h-4 text-orange-500" />
                <span>{car.specifications.torque}</span>
              </div>
            )}
          </div>
        )}

        <div className="mb-4 pb-4 border-t border-gray-700 pt-4">
          <p className="text-gray-400 text-xs mb-1">Modifications: {car.mods?.length || 0}</p>
          {totalModCost > 0 && (
            <p className="text-cyan-400 font-semibold text-sm">
              Total Investment: €{totalModCost.toFixed(2)}
            </p>
          )}
        </div>

        <div className="flex gap-2">
          <Link to={createPageUrl(`CarDetail?id=${car.id}`)} className="flex-1">
            <Button variant="secondary" className="w-full bg-gray-700 hover:bg-gray-600 text-white">
              View Details
            </Button>
          </Link>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => onEdit(car)}
            className="text-cyan-400 hover:bg-gray-700"
          >
            <Edit className="w-4 h-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => onDelete(car.id)}
            className="text-red-500 hover:bg-gray-700"
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </motion.div>
  );
}

export default function GarageDetail() {
  const [user, setUser] = useState(null);
  const [garage, setGarage] = useState(null);
  const [isCarDialogOpen, setIsCarDialogOpen] = useState(false);
  const [carFormData, setCarFormData] = useState({
    name: '',
    year: new Date().getFullYear(),
    make: '',
    model: '',
    color: '',
    image_url: '',
    specifications: {}
  });
  const queryClient = useQueryClient();

  const garageId = new URLSearchParams(window.location.search).get('id');

  const { data: garageData = [] } = useQuery({
    queryKey: ['garage', garageId],
    queryFn: async () => {
      if (!garageId) return [];
      const result = await base44.entities.Garage.list();
      return result.filter(g => g.id === garageId);
    },
    enabled: !!garageId,
  });

  useEffect(() => {
    const loadUser = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    };
    loadUser();
  }, []);

  useEffect(() => {
    if (garageData?.length > 0) {
      setGarage(garageData[0]);
    }
  }, [garageData]);

  const { data: cars = [] } = useQuery({
    queryKey: ['garage-cars', garageId],
    queryFn: () => base44.entities.Car.filter({ garage_id: garageId }),
    enabled: !!garageId,
  });

  const createCarMutation = useMutation({
    mutationFn: (data) => base44.entities.Car.create({
      ...data,
      garage_id: garageId,
      owner_email: user.email,
      owner_name: user.full_name,
      mods: [],
      total_investment: '0'
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['garage-cars'] });
      setIsCarDialogOpen(false);
      setCarFormData({
        name: '',
        year: new Date().getFullYear(),
        make: '',
        model: '',
        color: '',
        image_url: '',
        specifications: {}
      });
    },
  });

  const deleteCarMutation = useMutation({
    mutationFn: (id) => base44.entities.Car.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['garage-cars'] }),
  });

  const handleCreateCar = async () => {
    if (!carFormData.name.trim() || !carFormData.make.trim() || !carFormData.model.trim()) return;
    await createCarMutation.mutateAsync(carFormData);
  };

  if (!user || !garage) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-56px)]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-cyan-400" />
      </div>
    );
  }

  return (
    <div className="min-h-[calc(100vh-56px)] bg-gray-900">
      {/* Cover */}
      {garage.cover_image && (
        <div className="h-64 overflow-hidden bg-gray-800 relative">
          <img src={garage.cover_image} alt={garage.name} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-gray-900" />
        </div>
      )}

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-start justify-between mb-8">
          <div>
            <Link to={createPageUrl('Garage')} className="inline-flex items-center gap-2 text-cyan-400 hover:text-cyan-300 mb-4">
              <ArrowLeft className="w-4 h-4" />
              Back to Garage
            </Link>
            <h1 className="text-4xl font-bold text-white mb-2">{garage.name}</h1>
            <p className="text-gray-400">{garage.description}</p>
          </div>
          <Button
            onClick={() => setIsCarDialogOpen(true)}
            className="bg-gradient-to-r from-cyan-500 to-blue-600"
          >
            <Plus className="w-5 h-5 mr-2" />
            Add Car
          </Button>
        </div>

        {/* Cars Grid */}
        {cars.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <AnimatePresence>
              {cars.map((car) => (
                <CarCard
                  key={car.id}
                  car={car}
                  onEdit={(car) => {
                    setCarFormData(car);
                  }}
                  onDelete={(id) => deleteCarMutation.mutate(id)}
                />
              ))}
            </AnimatePresence>
          </div>
        ) : (
          <div className="bg-gray-800 border border-gray-700 rounded-xl p-12 text-center">
            <Fuel className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-white mb-2">No Cars Yet</h2>
            <p className="text-gray-400 mb-6">Add your first car to this garage</p>
            <Button
              onClick={() => setIsCarDialogOpen(true)}
              className="bg-gradient-to-r from-cyan-500 to-blue-600"
            >
              <Plus className="w-5 h-5 mr-2" />
              Add Your First Car
            </Button>
          </div>
        )}
      </div>

      {/* Car Management Sections */}
      {cars.length > 0 && (
        <div className="mt-12 space-y-8 pb-8">
          {cars.map(car => (
            <div key={car.id} className="space-y-6 border-t border-gray-800 pt-8">
              <h2 className="text-2xl font-light text-white uppercase tracking-wide">{car.name || car.model}</h2>
              
              <div className="grid grid-cols-1 gap-6">
                <MaintenanceSection 
                  carId={car.id} 
                  garageId={garageId} 
                  userEmail={user?.email}
                  isOwner={user?.email === garage.owner_email}
                />
                <InsuranceSection 
                  carId={car.id} 
                  garageId={garageId} 
                  userEmail={user?.email}
                  isOwner={user?.email === garage.owner_email}
                />
                <FuelSection 
                  carId={car.id} 
                  garageId={garageId} 
                  userEmail={user?.email}
                  isOwner={user?.email === garage.owner_email}
                />
                <ExpenseTracker 
                  carId={car.id} 
                  garageId={garageId} 
                  userEmail={user?.email}
                  isOwner={user?.email === garage.owner_email}
                />
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add Car Dialog */}
      <Dialog open={isCarDialogOpen} onOpenChange={setIsCarDialogOpen}>
        <DialogContent className="bg-gray-800 border-gray-700 max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-white">Add New Car</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 max-h-[70vh] overflow-y-auto">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Car Name/Nickname</label>
              <Input
                placeholder="e.g., Project M340i"
                value={carFormData.name}
                onChange={(e) => setCarFormData({ ...carFormData, name: e.target.value })}
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Year</label>
                <Input
                  type="number"
                  value={carFormData.year}
                  onChange={(e) => setCarFormData({ ...carFormData, year: parseInt(e.target.value) })}
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Make</label>
                <Input
                  placeholder="BMW"
                  value={carFormData.make}
                  onChange={(e) => setCarFormData({ ...carFormData, make: e.target.value })}
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Model</label>
                <Input
                  placeholder="M340i"
                  value={carFormData.model}
                  onChange={(e) => setCarFormData({ ...carFormData, model: e.target.value })}
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Color</label>
                <Input
                  placeholder="Alpine White"
                  value={carFormData.color}
                  onChange={(e) => setCarFormData({ ...carFormData, color: e.target.value })}
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Image URL</label>
              <Input
                placeholder="https://..."
                value={carFormData.image_url}
                onChange={(e) => setCarFormData({ ...carFormData, image_url: e.target.value })}
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>

            <div className="border-t border-gray-700 pt-4">
              <h3 className="text-sm font-semibold text-white mb-3">Specifications</h3>
              <div className="space-y-3">
                <Input
                  placeholder="Engine (e.g., 3.0L Twin-Turbo)"
                  value={carFormData.specifications?.engine || ''}
                  onChange={(e) => setCarFormData({
                    ...carFormData,
                    specifications: { ...carFormData.specifications, engine: e.target.value }
                  })}
                  className="bg-gray-700 border-gray-600 text-white text-sm"
                />
                <Input
                  placeholder="Horsepower (e.g., 382 hp)"
                  value={carFormData.specifications?.horsepower || ''}
                  onChange={(e) => setCarFormData({
                    ...carFormData,
                    specifications: { ...carFormData.specifications, horsepower: e.target.value }
                  })}
                  className="bg-gray-700 border-gray-600 text-white text-sm"
                />
                <Input
                  placeholder="Torque (e.g., 500 Nm)"
                  value={carFormData.specifications?.torque || ''}
                  onChange={(e) => setCarFormData({
                    ...carFormData,
                    specifications: { ...carFormData.specifications, torque: e.target.value }
                  })}
                  className="bg-gray-700 border-gray-600 text-white text-sm"
                />
              </div>
            </div>

            <div className="flex gap-3 pt-4">
              <Button
                variant="secondary"
                onClick={() => setIsCarDialogOpen(false)}
                className="flex-1 bg-gray-700 hover:bg-gray-600"
              >
                Cancel
              </Button>
              <Button
                onClick={handleCreateCar}
                className="flex-1 bg-gradient-to-r from-cyan-500 to-blue-600"
              >
                Add Car
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}