import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { TrendingUp, Users, Eye, Target } from 'lucide-react';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

export default function AdminMarketing() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const loadUser = async () => {
      const currentUser = await base44.auth.me();
      if (!currentUser || currentUser.role !== 'admin') {
        window.location.href = '/';
        return;
      }
      setUser(currentUser);
    };
    loadUser();
  }, []);

  const { data: analytics = [] } = useQuery({
    queryKey: ['marketing-analytics'],
    queryFn: () => base44.entities.SiteAnalytics.list('-date', 30),
  });

  const trafficData = analytics.slice(0, 14).reverse().map(a => ({
    date: new Date(a.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
    views: a.page_views || 0,
    users: a.unique_visitors || 0
  }));

  const conversionData = analytics.slice(0, 7).reverse().map(a => ({
    date: new Date(a.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
    registrations: a.event_registrations || 0,
    listings: a.marketplace_listings || 0
  }));

  if (!user) return null;

  return (
    <div className="min-h-screen bg-black text-white pb-20">
      <div className="max-w-7xl mx-auto px-6 py-12">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-12">
          <h1 className="text-4xl font-light uppercase tracking-wider mb-2">Marketing Analytics</h1>
          <p className="text-gray-500 text-sm uppercase tracking-wider">Track growth & engagement</p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
          <div className="bg-gray-950 border border-gray-900 p-6">
            <TrendingUp className="w-8 h-8 text-[#0066B1] mb-3" />
            <div className="text-3xl font-light mb-2">{analytics.reduce((sum, a) => sum + (a.page_views || 0), 0).toLocaleString()}</div>
            <p className="text-xs text-gray-500 uppercase tracking-wider">Total Views</p>
          </div>
          <div className="bg-gray-950 border border-gray-900 p-6">
            <Users className="w-8 h-8 text-[#E22718] mb-3" />
            <div className="text-3xl font-light mb-2">{analytics.reduce((sum, a) => sum + (a.new_users || 0), 0)}</div>
            <p className="text-xs text-gray-500 uppercase tracking-wider">New Users</p>
          </div>
          <div className="bg-gray-950 border border-gray-900 p-6">
            <Eye className="w-8 h-8 text-[#00C853] mb-3" />
            <div className="text-3xl font-light mb-2">{analytics.reduce((sum, a) => sum + (a.unique_visitors || 0), 0)}</div>
            <p className="text-xs text-gray-500 uppercase tracking-wider">Unique Visitors</p>
          </div>
          <div className="bg-gray-950 border border-gray-900 p-6">
            <Target className="w-8 h-8 text-[#FFB300] mb-3" />
            <div className="text-3xl font-light mb-2">{((analytics.reduce((sum, a) => sum + (a.new_users || 0), 0) / analytics.reduce((sum, a) => sum + (a.unique_visitors || 1), 1)) * 100).toFixed(1)}%</div>
            <p className="text-xs text-gray-500 uppercase tracking-wider">Conversion Rate</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-gray-950 border border-gray-900 p-6">
            <h3 className="text-sm uppercase tracking-wider text-gray-400 mb-6">Traffic Overview</h3>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={trafficData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                <XAxis dataKey="date" tick={{ fill: '#999' }} />
                <YAxis tick={{ fill: '#999' }} />
                <Tooltip contentStyle={{ backgroundColor: '#000', border: '1px solid #333' }} />
                <Legend />
                <Line type="monotone" dataKey="views" stroke="#0066B1" strokeWidth={2} name="Page Views" />
                <Line type="monotone" dataKey="users" stroke="#E22718" strokeWidth={2} name="Unique Users" />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="bg-gray-950 border border-gray-900 p-6">
            <h3 className="text-sm uppercase tracking-wider text-gray-400 mb-6">Conversions</h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={conversionData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                <XAxis dataKey="date" tick={{ fill: '#999' }} />
                <YAxis tick={{ fill: '#999' }} />
                <Tooltip contentStyle={{ backgroundColor: '#000', border: '1px solid #333' }} />
                <Legend />
                <Bar dataKey="registrations" fill="#00C853" name="Event Registrations" />
                <Bar dataKey="listings" fill="#FFB300" name="Marketplace Listings" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}