import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Plus, Users, Search, Flame } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { motion, AnimatePresence } from 'framer-motion';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const bmwModels = [
  { name: 'E46', category: '3-Series' },
  { name: 'E90', category: '3-Series' },
  { name: 'F30', category: '3-Series' },
  { name: 'E92', category: '4-Series' },
  { name: 'F82', category: '4-Series' },
  { name: 'E39', category: '5-Series' },
  { name: 'E60', category: '5-Series' },
  { name: 'F10', category: '5-Series' },
  { name: 'X5', category: 'SUV' },
  { name: 'X3', category: 'SUV' },
  { name: 'M3', category: 'M-Sport' },
  { name: 'M4', category: 'M-Sport' },
  { name: 'M5', category: 'M-Sport' }
];

function GroupCard({ group, isMember, onJoin }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white border border-[#D6D6D6] rounded-none overflow-hidden hover:border-[#0066B1] transition-colors"
    >
      {group.cover_image && (
        <div className="h-32 bg-gray-200 overflow-hidden">
          <img src={group.cover_image} alt={group.name} className="w-full h-full object-cover" />
        </div>
      )}
      <div className="p-4">
        <div className="flex items-center gap-2 mb-2">
          <Flame className="w-5 h-5 text-[#E22718]" />
          <h3 className="text-lg font-bold text-black">{group.name}</h3>
        </div>
        <p className="text-gray-600 text-sm mb-3">{group.description}</p>
        
        <div className="flex items-center gap-2 text-gray-500 text-xs mb-4">
          <Users className="w-4 h-4" />
          <span>{group.member_count || 0} members</span>
        </div>

        <Button
          onClick={() => onJoin(group.id)}
          disabled={isMember}
          className={isMember ? 'w-full bg-gray-100 text-gray-600 border border-[#D6D6D6]' : 'w-full bg-black text-white hover:bg-[#0066B1]'}
        >
          {isMember ? 'Member' : 'Join Group'}
        </Button>
      </div>
    </motion.div>
  );
}

export default function Groups() {
  const [user, setUser] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    category: '',
    cover_image: ''
  });
  const queryClient = useQueryClient();

  useEffect(() => {
    const loadUser = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    };
    loadUser();
  }, []);

  const { data: groups = [] } = useQuery({
    queryKey: ['groups'],
    queryFn: () => base44.entities.Group.list('-created_date', 100),
  });

  const { data: userGroups = [] } = useQuery({
    queryKey: ['user-groups', user?.email],
    queryFn: () => base44.entities.Group.filter({ 'members': user?.email }),
    enabled: !!user?.email,
  });

  const joinGroupMutation = useMutation({
    mutationFn: async (groupId) => {
      const group = groups.find(g => g.id === groupId);
      const updatedMembers = [...(group.members || []), user.email];
      return base44.entities.Group.update(groupId, {
        members: updatedMembers,
        member_count: updatedMembers.length
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['user-groups'] });
      queryClient.invalidateQueries({ queryKey: ['groups'] });
    },
  });

  const createGroupMutation = useMutation({
    mutationFn: (data) => base44.entities.Group.create({
      ...data,
      admin_email: user.email,
      members: [user.email],
      member_count: 1
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['groups'] });
      setIsCreateDialogOpen(false);
      setFormData({ name: '', description: '', category: '', cover_image: '' });
    },
  });

  const filteredGroups = groups.filter(g =>
    g.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    g.category?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const memberGroupIds = userGroups.map(g => g.id);

  return (
    <div className="min-h-[calc(100vh-56px)] bg-white pb-20 md:pb-0">
      {/* Header */}
      <div className="bg-white border-b border-[#D6D6D6] p-6 sticky top-20 z-30">
        <div className="max-w-7xl mx-auto">
          <div className="mb-4">
            <h1 className="text-3xl font-bold text-black uppercase tracking-wider">Club Groups</h1>
            <p className="text-gray-600 text-sm uppercase tracking-wider">Connect with BMW enthusiasts by model</p>
          </div>

          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
            <Input
              placeholder="Search groups by name or model..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-white border-[#D6D6D6] text-black placeholder-gray-400"
            />
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* My Groups */}
        {userGroups.length > 0 && (
          <div className="mb-12">
            <h2 className="text-2xl font-bold text-black uppercase tracking-wider mb-6">My Groups ({userGroups.length})</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <AnimatePresence>
                {userGroups.map(group => (
                  <GroupCard
                    key={group.id}
                    group={group}
                    isMember={true}
                    onJoin={() => {}}
                  />
                ))}
              </AnimatePresence>
            </div>
          </div>
        )}

        {/* All Groups */}
        <div>
          <h2 className="text-2xl font-bold text-black uppercase tracking-wider mb-6">
            Discover Groups {filteredGroups.length > 0 && `(${filteredGroups.length})`}
          </h2>
          {filteredGroups.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <AnimatePresence>
                {filteredGroups.map(group => (
                  <GroupCard
                    key={group.id}
                    group={group}
                    isMember={memberGroupIds.includes(group.id)}
                    onJoin={(groupId) => joinGroupMutation.mutate(groupId)}
                  />
                ))}
              </AnimatePresence>
            </div>
          ) : (
            <div className="bg-white border border-[#D6D6D6] rounded-none p-12 text-center">
              <Users className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">No groups found</p>
            </div>
          )}
        </div>
      </div>

      {/* Create Group Dialog */}
      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="bg-white border-[#D6D6D6]">
          <DialogHeader>
            <DialogTitle className="text-black uppercase tracking-wider">Create New Group</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2 uppercase tracking-wider">Group Name</label>
              <Input
                placeholder="e.g., E46 M3 Owners"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="bg-white border-[#D6D6D6] text-black"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2 uppercase tracking-wider">Category/Model</label>
              <select
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                className="w-full bg-white border border-[#D6D6D6] rounded-none text-black px-3 py-2"
              >
                <option value="">Select a model...</option>
                {bmwModels.map(model => (
                  <option key={model.name} value={model.name}>
                    {model.name} ({model.category})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2 uppercase tracking-wider">Description</label>
              <Input
                placeholder="What's this group about?"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="bg-white border-[#D6D6D6] text-black"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2 uppercase tracking-wider">Cover Image URL</label>
              <Input
                placeholder="https://..."
                value={formData.cover_image}
                onChange={(e) => setFormData({ ...formData, cover_image: e.target.value })}
                className="bg-white border-[#D6D6D6] text-black"
              />
            </div>

            <div className="flex gap-3 pt-4">
              <Button
                variant="secondary"
                onClick={() => setIsCreateDialogOpen(false)}
                className="flex-1 bg-gray-100 border border-[#D6D6D6] text-black hover:bg-gray-200"
              >
                Cancel
              </Button>
              <Button
                onClick={() => {
                  if (formData.name.trim()) {
                    createGroupMutation.mutate(formData);
                  }
                }}
                className="flex-1 bg-black text-white hover:bg-[#0066B1]"
              >
                Create Group
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}