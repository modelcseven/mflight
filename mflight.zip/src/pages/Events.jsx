import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Calendar as CalendarIcon, MapPin, Ticket, Clock, ChevronLeft, ChevronRight, Navigation } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { format, addDays, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, isSameDay, differenceInMonths, differenceInWeeks, differenceInDays, differenceInHours, differenceInMinutes, differenceInSeconds } from 'date-fns';

const upcomingEvents = [
  {
    id: 1,
    name: 'BMW M Winter Track Day',
    date: new Date(2026, 0, 25, 9, 0),
    location: 'Nürburgring, Germany',
    address: 'Nürburgring Boulevard, 53520 Nürburg, Germany',
    coordinates: { lat: 50.3322, lng: 6.9472 },
    description: 'Experience your BMW M on the legendary Nordschleife',
    image: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800',
    ticketsAvailable: 45,
    totalTickets: 100,
    price: 299
  },
  {
    id: 2,
    name: 'M Performance Meet & Greet',
    date: new Date(2026, 1, 8, 14, 0),
    location: 'BMW Welt München',
    address: 'Am Olympiapark 1, 80809 München, Germany',
    coordinates: { lat: 48.1775, lng: 11.5561 },
    description: 'Connect with fellow enthusiasts and showcase your build',
    image: 'https://images.unsplash.com/photo-1555215695-3004980ad54e?w=800',
    ticketsAvailable: 28,
    totalTickets: 80,
    price: 0
  },
  {
    id: 3,
    name: 'Mountain Road Tour',
    date: new Date(2026, 1, 22, 8, 0),
    location: 'Swiss Alps Route',
    address: 'Grimselpass, 3864 Guttannen, Switzerland',
    coordinates: { lat: 46.5711, lng: 8.3369 },
    description: 'Epic driving experience through Alpine passes',
    image: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800',
    ticketsAvailable: 12,
    totalTickets: 30,
    price: 199
  },
  {
    id: 4,
    name: 'M Tech Workshop',
    date: new Date(2026, 2, 5, 10, 0),
    location: 'Turner Motorsport HQ',
    address: '29 Cobble Hill Rd, Amesbury, MA 01913, USA',
    coordinates: { lat: 42.8584, lng: -70.9300 },
    description: 'Learn advanced tuning techniques from the pros',
    image: 'https://images.unsplash.com/photo-1486262715619-67b85e0b08d3?w=800',
    ticketsAvailable: 8,
    totalTickets: 20,
    price: 499
  }
];

export default function Events() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(null);
  const [countdown, setCountdown] = useState({});

  // Find next event
  const nextEvent = upcomingEvents
    .filter(event => event.date > new Date())
    .sort((a, b) => a.date - b.date)[0];

  // Update countdown every second
  useEffect(() => {
    if (!nextEvent) return;

    const updateCountdown = () => {
      const now = new Date();
      const eventDate = nextEvent.date;

      const months = differenceInMonths(eventDate, now);
      const weeks = differenceInWeeks(eventDate, now) % 4;
      const days = differenceInDays(eventDate, now) % 7;
      const hours = differenceInHours(eventDate, now) % 24;
      const minutes = differenceInMinutes(eventDate, now) % 60;
      const seconds = differenceInSeconds(eventDate, now) % 60;

      setCountdown({ months, weeks, days, hours, minutes, seconds });
    };

    updateCountdown();
    const interval = setInterval(updateCountdown, 1000);

    return () => clearInterval(interval);
  }, [nextEvent]);

  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(currentDate);
  const daysInMonth = eachDayOfInterval({ start: monthStart, end: monthEnd });

  const firstDayOfMonth = monthStart.getDay();
  const previousMonthDays = Array.from({ length: firstDayOfMonth }, (_, i) => null);

  const allDays = [...previousMonthDays, ...daysInMonth];

  const getEventsForDate = (date) => {
    if (!date) return [];
    return upcomingEvents.filter(event => isSameDay(event.date, date));
  };

  const handlePrevMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1));
  };

  const handleNextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1));
  };

  const openInGoogleMaps = (event) => {
    const url = `https://www.google.com/maps/search/?api=1&query=${event.coordinates.lat},${event.coordinates.lng}`;
    window.open(url, '_blank');
  };

  const openInAppleMaps = (event) => {
    const url = `http://maps.apple.com/?q=${event.name}&ll=${event.coordinates.lat},${event.coordinates.lng}`;
    window.open(url, '_blank');
  };

  return (
    <div className="min-h-screen bg-black text-white pb-20">
      <div className="max-w-7xl mx-auto px-6 py-12">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-12"
        >
          <h1 className="text-4xl font-light uppercase tracking-wider mb-4">Exclusive Events</h1>
          <p className="text-gray-500 text-sm uppercase tracking-wider">Join the elite M community</p>
        </motion.div>

        {/* Countdown to Next Event */}
        {nextEvent && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-gradient-to-r from-[#0066B1]/20 to-[#E22718]/20 border border-gray-900 p-8 mb-12"
          >
            <div className="flex items-center gap-3 mb-4">
              <Clock className="w-5 h-5 text-[#E22718]" />
              <h2 className="text-xs uppercase tracking-wider text-gray-400">Next Event</h2>
            </div>
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-light">{nextEvent.name}</h3>
              <div className="flex items-center gap-4">
                <div className="text-right">
                  <div className="text-xs text-gray-400 uppercase tracking-wider mb-1">Tickets Available</div>
                  <div className="text-2xl font-light text-[#0066B1]">{nextEvent.ticketsAvailable}/{nextEvent.totalTickets}</div>
                </div>
                <Button className="bg-[#E22718] hover:bg-[#C01F12] text-white">
                  <Ticket className="w-4 h-4 mr-2" />
                  Buy Ticket
                </Button>
              </div>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
              <div className="bg-black/50 border border-gray-900 p-4 text-center">
                <div className="text-4xl font-light text-[#E22718] mb-1">{countdown.months || 0}</div>
                <p className="text-xs text-gray-500 uppercase tracking-wider">Months</p>
              </div>
              <div className="bg-black/50 border border-gray-900 p-4 text-center">
                <div className="text-4xl font-light text-[#E22718] mb-1">{countdown.weeks || 0}</div>
                <p className="text-xs text-gray-500 uppercase tracking-wider">Weeks</p>
              </div>
              <div className="bg-black/50 border border-gray-900 p-4 text-center">
                <div className="text-4xl font-light text-[#0066B1] mb-1">{countdown.days || 0}</div>
                <p className="text-xs text-gray-500 uppercase tracking-wider">Days</p>
              </div>
              <div className="bg-black/50 border border-gray-900 p-4 text-center">
                <div className="text-4xl font-light text-[#0066B1] mb-1">{countdown.hours || 0}</div>
                <p className="text-xs text-gray-500 uppercase tracking-wider">Hours</p>
              </div>
              <div className="bg-black/50 border border-gray-900 p-4 text-center">
                <div className="text-4xl font-light text-white mb-1">{countdown.minutes || 0}</div>
                <p className="text-xs text-gray-500 uppercase tracking-wider">Minutes</p>
              </div>
              <div className="bg-black/50 border border-gray-900 p-4 text-center">
                <div className="text-4xl font-light text-white mb-1">{countdown.seconds || 0}</div>
                <p className="text-xs text-gray-500 uppercase tracking-wider">Seconds</p>
              </div>
            </div>
          </motion.div>
        )}

        {/* Upcoming Events Tiles */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-12"
        >
          <h2 className="text-xs uppercase tracking-wider text-gray-400 mb-6">Upcoming Events</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {upcomingEvents.map((event, idx) => (
              <motion.div
                key={event.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 * idx }}
                className="bg-gray-950 border border-gray-900 overflow-hidden hover:border-[#0066B1] transition-colors group"
              >
                <div className="relative h-48 overflow-hidden">
                  <img 
                    src={event.image} 
                    alt={event.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute top-4 right-4 bg-black/80 border border-gray-800 px-3 py-1">
                    <p className="text-xs text-white uppercase tracking-wider">
                      {format(event.date, 'MMM d')}
                    </p>
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-lg font-light mb-2">{event.name}</h3>
                  <div className="flex items-center gap-2 text-gray-500 text-xs mb-4">
                    <MapPin className="w-3 h-3" />
                    <span>{event.location}</span>
                  </div>
                  <p className="text-sm text-gray-600 mb-4 line-clamp-2">{event.description}</p>
                  
                  {/* Ticket Availability */}
                  <div className="mb-4">
                    <div className="flex justify-between text-xs text-gray-500 mb-2">
                      <span>Tickets Available</span>
                      <span>{event.ticketsAvailable}/{event.totalTickets}</span>
                    </div>
                    <div className="w-full bg-gray-900 h-2">
                      <div 
                        className="bg-[#0066B1] h-2"
                        style={{ width: `${(event.ticketsAvailable / event.totalTickets) * 100}%` }}
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    {event.price > 0 && (
                      <div className="flex items-center justify-between">
                        <span className="text-2xl font-light text-[#E22718]">${event.price}</span>
                        <Button className="bg-[#E22718] hover:bg-[#C01F12] text-white text-xs">
                          <Ticket className="w-3 h-3 mr-2" />
                          Buy Ticket
                        </Button>
                      </div>
                    )}
                    {event.price === 0 && (
                      <Button className="w-full bg-[#0066B1] hover:bg-[#0055A0] text-white text-xs">
                        <Ticket className="w-3 h-3 mr-2" />
                        Register Free
                      </Button>
                    )}
                    
                    {/* Navigation Buttons */}
                    <div className="flex gap-2">
                      <Button
                        onClick={() => openInGoogleMaps(event)}
                        variant="outline"
                        className="flex-1 border-gray-800 text-gray-400 hover:text-white hover:bg-gray-900 text-xs"
                      >
                        <Navigation className="w-3 h-3 mr-2" />
                        Google
                      </Button>
                      <Button
                        onClick={() => openInAppleMaps(event)}
                        variant="outline"
                        className="flex-1 border-gray-800 text-gray-400 hover:text-white hover:bg-gray-900 text-xs"
                      >
                        <Navigation className="w-3 h-3 mr-2" />
                        Apple
                      </Button>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Calendar */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-gray-950 border border-gray-900 p-8"
        >
          <div className="mb-6">
            <h2 className="text-xs uppercase tracking-wider text-gray-400 mb-2">Event Calendar</h2>
            <div className="flex items-center gap-3">
              <Ticket className="w-5 h-5 text-[#0066B1]" />
              <span className="text-2xl font-light text-white">
                {upcomingEvents.reduce((sum, event) => sum + event.ticketsAvailable, 0)}
              </span>
              <span className="text-gray-500 text-sm uppercase tracking-wider">Tickets Remaining</span>
            </div>
          </div>

          <div className="flex items-center justify-between mb-8">
            <h2 className="text-2xl font-light uppercase tracking-wider">
              {format(currentDate, 'MMMM yyyy')}
            </h2>
            <div className="flex gap-2">
              <Button
                onClick={handlePrevMonth}
                variant="outline"
                size="icon"
                className="border-gray-800 text-gray-400 hover:text-white hover:bg-gray-900"
              >
                <ChevronLeft className="w-4 h-4" />
              </Button>
              <Button
                onClick={handleNextMonth}
                variant="outline"
                size="icon"
                className="border-gray-800 text-gray-400 hover:text-white hover:bg-gray-900"
              >
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Calendar Grid */}
          <div className="grid grid-cols-7 gap-2">
            {/* Day headers */}
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
              <div key={day} className="text-center text-xs text-gray-500 uppercase tracking-wider py-2">
                {day}
              </div>
            ))}

            {/* Calendar days */}
            {allDays.map((day, idx) => {
              const events = day ? getEventsForDate(day) : [];
              const hasEvents = events.length > 0;
              const isToday = day && isSameDay(day, new Date());
              const isCurrentMonth = day && isSameMonth(day, currentDate);

              return (
                <motion.button
                  key={idx}
                  whileHover={day ? { scale: 1.05 } : {}}
                  onClick={() => day && setSelectedDate(day)}
                  className={`
                    p-2 border transition-colors relative flex flex-col min-h-[120px]
                    ${!day ? 'invisible' : ''}
                    ${!isCurrentMonth ? 'opacity-30' : ''}
                    ${isToday ? 'border-[#E22718] bg-[#E22718]/10' : 'border-gray-900'}
                    ${hasEvents ? 'bg-[#0066B1]/10 border-[#0066B1]' : 'hover:border-gray-700'}
                  `}
                  disabled={!day}
                >
                  {day && (
                    <>
                      <div className={`text-sm mb-2 ${isToday ? 'text-[#E22718] font-medium' : 'text-white'}`}>
                        {format(day, 'd')}
                      </div>
                      {hasEvents && (
                        <div className="flex-1 space-y-1">
                          {events.map((event) => (
                            <div key={event.id} className="text-left">
                              <div className="text-[10px] text-white font-medium truncate">{event.name}</div>
                              <div className="flex items-center gap-1 text-xs text-[#0066B1] font-medium">
                                <Ticket className="w-3 h-3" />
                                <span>{event.ticketsAvailable} left</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </>
                  )}
                </motion.button>
              );
            })}
          </div>

          {/* Selected Date Events */}
          {selectedDate && getEventsForDate(selectedDate).length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-8 pt-8 border-t border-gray-900"
            >
              <h3 className="text-sm uppercase tracking-wider text-gray-400 mb-4">
                Events on {format(selectedDate, 'MMMM d, yyyy')}
              </h3>
              <div className="space-y-3">
                {getEventsForDate(selectedDate).map(event => (
                  <div
                    key={event.id}
                    className="bg-black/50 border border-gray-900 p-4 flex items-center justify-between"
                  >
                    <div>
                      <h4 className="font-medium mb-1">{event.name}</h4>
                      <p className="text-sm text-gray-500">{format(event.date, 'h:mm a')} • {event.location}</p>
                    </div>
                    <Button className="bg-[#0066B1] hover:bg-[#0055A0] text-white text-xs">
                      View Details
                    </Button>
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </motion.div>
      </div>
    </div>
  );
}