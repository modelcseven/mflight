import React, { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Search, Send, Phone, Video, Info, Image, Smile, ThumbsUp, MoreHorizontal, ArrowLeft, FileVideo } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { formatDistanceToNow } from 'date-fns';
import { motion, AnimatePresence } from 'framer-motion';

function ConversationItem({ user, lastMessage, isActive, onClick, unreadCount }) {
  const avatar = user.avatar || `https://ui-avatars.com/api/?name=${user.full_name}&background=random`;
  
  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center gap-3 p-2 transition-colors ${
        isActive ? 'bg-gray-900' : 'hover:bg-gray-950'
      }`}
    >
      <div className="relative flex-shrink-0">
        <img
          src={avatar}
          alt={user.full_name}
          className="w-14 h-14 rounded-full object-cover"
        />
        <div className="absolute bottom-0 right-0 w-4 h-4 bg-green-500 rounded-full border-2 border-white" />
      </div>
      <div className="flex-1 min-w-0 text-left">
        <p className={`font-semibold truncate ${unreadCount > 0 ? 'text-white' : 'text-gray-300'}`}>
          {user.full_name}
        </p>
        <p className={`text-sm truncate ${unreadCount > 0 ? 'text-gray-300 font-semibold' : 'text-gray-500'}`}>
          {lastMessage?.content || 'Start a conversation'}
        </p>
      </div>
      {unreadCount > 0 && (
        <div className="w-5 h-5 bg-[#0066B1] rounded-full flex items-center justify-center">
          <span className="text-white text-xs font-bold">{unreadCount}</span>
        </div>
      )}
    </button>
  );
}

function MessageBubble({ message, isOwn, showAvatar, otherUser }) {
  const avatar = otherUser?.avatar || `https://ui-avatars.com/api/?name=${otherUser?.full_name}&background=random`;
  
  return (
    <div className={`flex items-end gap-2 ${isOwn ? 'flex-row-reverse' : ''}`}>
      {!isOwn && showAvatar ? (
        <img
          src={avatar}
          alt=""
          className="w-7 h-7 rounded-full object-cover flex-shrink-0"
        />
      ) : !isOwn ? (
        <div className="w-7 h-7 flex-shrink-0" />
      ) : null}
      <div
        className={`max-w-[70%] px-3 py-2 rounded-2xl ${
          isOwn 
            ? 'bg-[#0066B1] text-white rounded-br-sm' 
            : 'bg-gray-900 text-white rounded-bl-sm'
        }`}
      >
        <p className="text-[15px] leading-snug">{message.content}</p>
      </div>
    </div>
  );
}

export default function Messages() {
  const [user, setUser] = useState(null);
  const [selectedConversation, setSelectedConversation] = useState(null);
  const [messageText, setMessageText] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const messagesEndRef = useRef(null);
  const queryClient = useQueryClient();
  
  const urlParams = new URLSearchParams(window.location.search);
  const toEmail = urlParams.get('to');

  useEffect(() => {
    const loadUser = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    };
    loadUser();
  }, []);

  const { data: allUsers = [] } = useQuery({
    queryKey: ['all-users'],
    queryFn: () => base44.entities.User.list(),
    enabled: !!user?.email,
  });

  const { data: allMessages = [] } = useQuery({
    queryKey: ['all-messages', user?.email],
    queryFn: async () => {
      const sent = await base44.entities.Message.filter({ from_email: user?.email });
      const received = await base44.entities.Message.filter({ to_email: user?.email });
      return [...sent, ...received].sort((a, b) => 
        new Date(a.created_date) - new Date(b.created_date)
      );
    },
    enabled: !!user?.email,
    refetchInterval: 3000,
  });

  // Get unique conversations
  const conversations = React.useMemo(() => {
    if (!user) return [];
    
    const conversationMap = new Map();
    allMessages.forEach(msg => {
      const otherEmail = msg.from_email === user.email ? msg.to_email : msg.from_email;
      const existing = conversationMap.get(otherEmail);
      if (!existing || new Date(msg.created_date) > new Date(existing.created_date)) {
        conversationMap.set(otherEmail, msg);
      }
    });

    return Array.from(conversationMap.entries()).map(([email, lastMsg]) => ({
      email,
      user: allUsers.find(u => u.email === email),
      lastMessage: lastMsg,
      unreadCount: allMessages.filter(m => 
        m.from_email === email && 
        m.to_email === user.email && 
        !m.read
      ).length
    })).filter(c => c.user).sort((a, b) => 
      new Date(b.lastMessage.created_date) - new Date(a.lastMessage.created_date)
    );
  }, [allMessages, allUsers, user]);

  // Handle URL parameter for direct messaging
  useEffect(() => {
    if (toEmail && allUsers.length > 0) {
      const targetUser = allUsers.find(u => u.email === toEmail);
      if (targetUser) {
        setSelectedConversation(toEmail);
      }
    }
  }, [toEmail, allUsers]);

  const currentConversationMessages = allMessages.filter(msg =>
    (msg.from_email === user?.email && msg.to_email === selectedConversation) ||
    (msg.from_email === selectedConversation && msg.to_email === user?.email)
  );

  const selectedUser = allUsers.find(u => u.email === selectedConversation);

  // Mark messages as read
  useEffect(() => {
    if (selectedConversation && user) {
      const unreadMessages = currentConversationMessages.filter(
        m => m.from_email === selectedConversation && !m.read
      );
      unreadMessages.forEach(msg => {
        base44.entities.Message.update(msg.id, { read: true });
      });
    }
  }, [selectedConversation, currentConversationMessages]);

  // Scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [currentConversationMessages]);

  const sendMessageMutation = useMutation({
    mutationFn: (content) => base44.entities.Message.create({
      from_email: user.email,
      to_email: selectedConversation,
      content,
      read: false
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['all-messages'] });
      setMessageText('');
    },
  });

  const handleSend = () => {
    if (!messageText.trim()) return;
    sendMessageMutation.mutate(messageText);
  };

  const handleMediaUpload = async (e, type) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const formData = new FormData();
    formData.append('file', file);

    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      const content = type === 'image' 
        ? `[Image: ${file.name}](${file_url})`
        : `[Video: ${file.name}](${file_url})`;
      sendMessageMutation.mutate(content);
    } catch (error) {
      console.error('Upload failed:', error);
    }
  };

  const handleCall = () => {
    alert(`Calling ${selectedUser?.full_name}...`);
  };

  const filteredConversations = conversations.filter(c =>
    c.user.full_name?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredUsers = searchQuery 
    ? allUsers.filter(u => 
        u.email !== user?.email && 
        u.full_name?.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : [];

  if (!user) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-56px)] bg-black">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#0066B1]" />
      </div>
    );
  }

  const selectedUserAvatar = selectedUser?.avatar || `https://ui-avatars.com/api/?name=${selectedUser?.full_name}&background=random`;

  return (
    <div className="h-[calc(100vh-56px)] flex bg-black">
      {/* Sidebar */}
      <div className={`w-full md:w-[360px] border-r border-gray-900 flex flex-col bg-black ${selectedConversation ? 'hidden md:flex' : 'flex'}`}>
        <div className="p-4 border-b border-gray-900">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-light uppercase tracking-wider text-white">Messages</h1>
            <button className="p-2 hover:bg-gray-900 text-gray-400 hover:text-white transition">
              <MoreHorizontal className="w-5 h-5" />
            </button>
          </div>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
            <Input
              placeholder="Search messages..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-gray-950 border-gray-900 text-white placeholder-gray-500"
            />
          </div>
        </div>

        <ScrollArea className="flex-1">
          <div className="p-2 space-y-1">
            {searchQuery && filteredUsers.length > 0 && (
              <>
                <p className="text-xs font-semibold text-gray-500 px-2 py-1">People</p>
                {filteredUsers.map(u => (
                  <ConversationItem
                    key={u.email}
                    user={u}
                    isActive={selectedConversation === u.email}
                    onClick={() => setSelectedConversation(u.email)}
                    unreadCount={0}
                  />
                ))}
                <div className="border-t border-gray-200 my-2" />
              </>
            )}
            
            {filteredConversations.map(conv => (
              <ConversationItem
                key={conv.email}
                user={conv.user}
                lastMessage={conv.lastMessage}
                isActive={selectedConversation === conv.email}
                onClick={() => setSelectedConversation(conv.email)}
                unreadCount={conv.unreadCount}
              />
            ))}
            
            {filteredConversations.length === 0 && !searchQuery && (
              <div className="text-center py-8">
                <p className="text-gray-500 text-xs uppercase tracking-wider">No conversations yet</p>
              </div>
            )}
          </div>
        </ScrollArea>
      </div>

      {/* Chat Area */}
      {selectedConversation ? (
        <div className="flex-1 flex flex-col bg-black">
          {/* Chat Header */}
          <div className="h-16 px-4 border-b border-gray-900 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <button 
                onClick={() => setSelectedConversation(null)}
                className="md:hidden p-2 hover:bg-gray-900 text-gray-400 hover:text-white transition"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <div className="relative">
                <img
                  src={selectedUserAvatar}
                  alt={selectedUser?.full_name}
                  className="w-10 h-10 rounded-full object-cover border-2 border-gray-900"
                />
                <div className="absolute bottom-0 right-0 w-3 h-3 bg-[#0066B1] rounded-full border-2 border-black" />
              </div>
              <div>
                <p className="font-light uppercase tracking-wider text-white text-sm">{selectedUser?.full_name}</p>
                <p className="text-xs text-gray-500 uppercase tracking-wider">Active now</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button className="p-2 hover:bg-gray-900 text-[#0066B1] hover:text-white transition">
                <Phone className="w-5 h-5" />
              </button>
              <button className="p-2 hover:bg-gray-900 text-[#0066B1] hover:text-white transition">
                <Video className="w-5 h-5" />
              </button>
              <button className="p-2 hover:bg-gray-900 text-gray-500 hover:text-white transition">
                <Info className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Messages */}
          <ScrollArea className="flex-1 p-4">
            <div className="space-y-1">
              {currentConversationMessages.map((msg, idx) => {
                const isOwn = msg.from_email === user.email;
                const prevMsg = currentConversationMessages[idx - 1];
                const showAvatar = !prevMsg || prevMsg.from_email !== msg.from_email;
                
                return (
                  <MessageBubble
                    key={msg.id}
                    message={msg}
                    isOwn={isOwn}
                    showAvatar={showAvatar}
                    otherUser={selectedUser}
                  />
                );
              })}
              <div ref={messagesEndRef} />
            </div>
          </ScrollArea>

          {/* Input */}
          <div className="p-4 border-t border-gray-900">
            <div className="flex items-center gap-2">
              <input
                type="file"
                id="image-upload"
                className="hidden"
                accept="image/*"
                onChange={(e) => handleMediaUpload(e, 'image')}
              />
              <button
                onClick={() => document.getElementById('image-upload').click()}
                className="p-2 hover:bg-gray-900 text-[#0066B1] hover:text-white transition-colors"
              >
                <Image className="w-5 h-5" />
              </button>

              <input
                type="file"
                id="video-upload"
                className="hidden"
                accept="video/*"
                onChange={(e) => handleMediaUpload(e, 'video')}
              />
              <button
                onClick={() => document.getElementById('video-upload').click()}
                className="p-2 hover:bg-gray-900 text-[#0066B1] hover:text-white transition-colors"
              >
                <Video className="w-5 h-5" />
              </button>

              <button
                onClick={handleCall}
                className="p-2 hover:bg-gray-900 text-[#E22718] hover:text-white transition-colors"
              >
                <Phone className="w-5 h-5" />
              </button>

              <Input
                placeholder="Type a message..."
                value={messageText}
                onChange={(e) => setMessageText(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && handleSend()}
                className="flex-1 bg-gray-950 border-gray-900 text-white placeholder-gray-500"
              />
              {messageText.trim() ? (
                <Button
                  size="icon"
                  onClick={handleSend}
                  className="bg-[#0066B1] hover:bg-[#0055A0]"
                >
                  <Send className="w-4 h-4" />
                </Button>
              ) : (
                <button className="p-2 hover:bg-gray-900 text-gray-500 hover:text-[#0066B1] transition">
                  <ThumbsUp className="w-5 h-5" />
                </button>
              )}
            </div>
          </div>
        </div>
      ) : (
        <div className="hidden md:flex flex-1 items-center justify-center bg-black">
          <div className="text-center">
            <div className="w-20 h-20 bg-gray-950 border border-gray-900 flex items-center justify-center mx-auto mb-4">
              <Send className="w-8 h-8 text-gray-600" />
            </div>
            <h2 className="text-xl font-light uppercase tracking-wider text-white">Your Messages</h2>
            <p className="text-gray-500 mt-1 text-xs uppercase tracking-wider">Send private messages to a friend</p>
          </div>
        </div>
      )}
    </div>
  );
}