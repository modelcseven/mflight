import React, { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Plus, Car, Trash2, Edit, AlertCircle, Search, Filter, Copy, CheckCircle2, Upload, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { motion, AnimatePresence } from 'framer-motion';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { toast } from 'sonner';

function GarageCard({ garage, onEdit, onDelete, carCount }) {
  const [copied, setCopied] = useState(false);
  
  const shareUrl = `${window.location.origin}${createPageUrl(`GarageDetail?id=${garage.id}`)}`;
  
  const copyToClipboard = () => {
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <Link to={createPageUrl(`GarageDetail?id=${garage.id}`)}>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gray-950 border border-gray-900 hover:border-[#0066B1] transition-colors group rounded-lg overflow-hidden cursor-pointer"
      >
        {/* Cover Image */}
        <div className="relative h-48 bg-gradient-to-br from-gray-900 to-black overflow-hidden">
          {garage.cover_image ? (
            <img src={garage.cover_image} alt={garage.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-[#0066B1]/20 to-transparent flex items-center justify-center">
              <Car className="w-16 h-16 text-gray-700" />
            </div>
          )}
          <div className="absolute inset-0 bg-black/40 group-hover:bg-black/30 transition-colors" />
        </div>

      {/* Content */}
      <div className="p-5">
        <h3 className="text-lg font-light text-white uppercase tracking-wide mb-1">{garage.name}</h3>
        <p className="text-gray-500 text-sm mb-4 line-clamp-2 h-10">{garage.description || 'No description'}</p>
        
        {/* Actions */}
        <div className="flex gap-2">
          <Button
            onClick={(e) => {
              e.preventDefault();
              copyToClipboard();
            }}
            variant="outline"
            size="icon"
            className="border-gray-800 text-gray-400 hover:text-[#0066B1]"
            title="Copy share link"
          >
            {copied ? <CheckCircle2 className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
          </Button>
          <Button
            onClick={(e) => {
              e.preventDefault();
              onEdit(garage);
            }}
            variant="outline"
            size="icon"
            className="border-gray-800 text-gray-400 hover:text-[#0066B1]"
            title="Edit garage"
          >
            <Edit className="w-4 h-4" />
          </Button>
          <Button
            onClick={(e) => {
              e.preventDefault();
              onDelete(garage.id);
            }}
            variant="outline"
            size="icon"
            className="border-gray-800 text-gray-400 hover:text-[#E22718]"
            title="Delete garage"
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </motion.div>
    </Link>
  );
}

export default function Garages() {
  const [user, setUser] = useState(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState(null);
  const [editingGarage, setEditingGarage] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [formData, setFormData] = useState({ name: '', description: '', cover_image: '' });
  const [isUploading, setIsUploading] = useState(false);
  const queryClient = useQueryClient();
  const imageInputRef = useRef(null);

  useEffect(() => {
    const loadUser = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    };
    loadUser();
  }, []);

  const { data: garages = [] } = useQuery({
    queryKey: ['garages', user?.email],
    queryFn: () => base44.entities.Garage.filter({ owner_email: user?.email }),
    enabled: !!user?.email,
  });

  const { data: cars = [] } = useQuery({
    queryKey: ['cars', user?.email],
    queryFn: () => base44.entities.Car.filter({ owner_email: user?.email }),
    enabled: !!user?.email,
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Garage.create({
      ...data,
      owner_email: user.email,
      owner_name: user.full_name,
      car_ids: []
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['garages'] });
      setIsDialogOpen(false);
      setFormData({ name: '', description: '', cover_image: '' });
    },
  });

  const updateMutation = useMutation({
    mutationFn: (data) => base44.entities.Garage.update(editingGarage.id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['garages'] });
      setIsDialogOpen(false);
      setEditingGarage(null);
      setFormData({ name: '', description: '', cover_image: '' });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Garage.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['garages'] });
      setDeleteConfirm(null);
      toast.success('Garage deleted');
    },
  });

  const handleOpenDialog = (garage = null) => {
    if (garage) {
      setEditingGarage(garage);
      setFormData({ name: garage.name, description: garage.description, cover_image: garage.cover_image });
    } else {
      if (garages.length >= 3) {
        alert('You can have a maximum of 3 garages');
        return;
      }
      setEditingGarage(null);
      setFormData({ name: '', description: '', cover_image: '' });
    }
    setIsDialogOpen(true);
  };

  const handleSubmit = async () => {
    if (!formData.name.trim()) return;
    if (editingGarage) {
      await updateMutation.mutateAsync(formData);
      toast.success('Garage updated');
    } else {
      await createMutation.mutateAsync(formData);
      toast.success('Garage created');
    }
  };

  const handleDelete = (id) => {
    deleteMutation.mutate(id);
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    try {
      const response = await base44.integrations.Core.UploadFile({ file });
      setFormData({ ...formData, cover_image: response.file_url });
      toast.success('Image uploaded');
    } catch (error) {
      console.error('Upload failed:', error);
      toast.error('Upload failed');
    } finally {
      setIsUploading(false);
    }
  };

  const filteredGarages = garages.filter(garage =>
    garage.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (garage.description && garage.description.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="max-w-7xl mx-auto p-6">
      {/* Header */}
      <div className="mb-10">
        <h1 className="text-4xl font-light text-white uppercase tracking-wider mb-2">My Virtual Garages</h1>
        <p className="text-gray-500 text-sm uppercase tracking-widest">Showcase your BMW collection</p>
      </div>

      {/* Search */}
      {garages.length > 0 && (
        <div className="mb-8">
          <div className="relative">
            <Search className="absolute left-3 top-3 w-4 h-4 text-gray-600" />
            <Input
              placeholder="Search garages..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-gray-950 border-gray-900 text-white pl-10 text-sm min-h-[48px]"
            />
          </div>
        </div>
      )}

      {/* Garages Grid */}
      {filteredGarages.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <AnimatePresence>
            {filteredGarages.map((garage) => (
              <GarageCard
                key={garage.id}
                garage={garage}
                onEdit={() => handleOpenDialog(garage)}
                onDelete={(id) => setDeleteConfirm(id)}
                carCount={cars.filter(c => c.garage_id === garage.id).length}
              />
            ))}
          </AnimatePresence>
        </div>
      ) : (
        <div className="bg-gray-950 border border-gray-900 rounded-lg p-12 text-center">
          <Car className="w-16 h-16 text-gray-700 mx-auto mb-4" />
          <h2 className="text-2xl font-light text-white mb-2 uppercase tracking-wide">No Garages Yet</h2>
          <p className="text-gray-500 mb-6 text-sm">Create your first virtual garage to start showcasing</p>
        </div>
      )}

      {/* Floating Add Button */}
      <motion.button
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => handleOpenDialog()}
        className="fixed bottom-24 right-6 z-50 w-16 h-16 bg-gradient-to-br from-[#0066B1] to-[#0055A0] rounded-full flex items-center justify-center shadow-xl hover:shadow-2xl transition-all border border-[#0077D4] lg:hidden"
      >
        <Plus className="w-7 h-7 text-white" />
      </motion.button>

      {/* Create/Edit Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="bg-gray-950 border border-gray-900 rounded-none">
          <DialogHeader>
            <DialogTitle className="text-white uppercase tracking-widest text-lg font-light">
              {editingGarage ? 'Edit Garage' : 'Add New Garage'}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-5 pt-2">
            <div>
              <label className="block text-xs text-gray-400 mb-3 uppercase tracking-widest font-medium">Garage Name *</label>
              <Input
                placeholder="e.g., My 2023 M3 Competition"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="bg-gray-900 border-gray-800 text-white placeholder-gray-500 focus:border-[#0066B1] rounded-none"
              />
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-3 uppercase tracking-widest font-medium">Description</label>
              <Textarea
                placeholder="Highlight key features, mods, specs..."
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="bg-gray-900 border-gray-800 text-white placeholder-gray-500 min-h-28 focus:border-[#0066B1] resize-none rounded-none"
                maxLength={1000}
              />
              <p className="text-xs text-gray-600 mt-2">{formData.description.length}/1000</p>
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-3 uppercase tracking-widest font-medium">Cover Image</label>
              <div className="space-y-3">
                <div className="flex gap-2">
                  <Input
                    placeholder="https://example.com/image.jpg"
                    value={formData.cover_image}
                    onChange={(e) => setFormData({ ...formData, cover_image: e.target.value })}
                    className="bg-gray-900 border-gray-800 text-white placeholder-gray-500 focus:border-[#0066B1] rounded-none flex-1"
                  />
                  <Button
                    type="button"
                    onClick={() => imageInputRef.current?.click()}
                    disabled={isUploading}
                    className="bg-gray-800 hover:bg-gray-700 border border-gray-700"
                  >
                    {isUploading ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Upload className="w-4 h-4" />
                    )}
                  </Button>
                  <input
                    ref={imageInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                </div>
                {formData.cover_image && (
                  <img 
                    src={formData.cover_image} 
                    alt="Preview" 
                    className="w-full h-32 object-cover border border-gray-800 rounded-none"
                  />
                )}
              </div>
            </div>
            <div className="flex gap-3 pt-2">
              <Button
                variant="outline"
                onClick={() => setIsDialogOpen(false)}
                className="flex-1 border-gray-800 text-gray-300 hover:text-white hover:border-gray-700 uppercase tracking-wider text-xs rounded-none"
              >
                Cancel
              </Button>
              <Button
                onClick={handleSubmit}
                disabled={!formData.name.trim()}
                className="flex-1 bg-[#0066B1] hover:bg-[#0055A0] text-white uppercase tracking-wider text-xs font-medium disabled:opacity-50 rounded-none"
              >
                {editingGarage ? 'Update Garage' : 'Create Garage'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={!!deleteConfirm} onOpenChange={() => setDeleteConfirm(null)}>
        <DialogContent className="bg-black border-gray-900">
          <DialogHeader>
            <DialogTitle className="text-white flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-[#E22718]" />
              Confirm Deletion
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-gray-400 text-sm">
              Are you sure you want to delete this garage? This will remove all associated media and cannot be undone.
            </p>
            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => setDeleteConfirm(null)}
                className="flex-1 border-gray-800 text-gray-400 hover:text-white"
              >
                Cancel
              </Button>
              <Button
                onClick={() => handleDelete(deleteConfirm)}
                className="flex-1 bg-[#E22718] hover:bg-[#C01A11]"
              >
                Delete
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}