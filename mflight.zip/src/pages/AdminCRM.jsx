import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { Users, Mail, Phone, Calendar, Search } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';

export default function AdminCRM() {
  const [user, setUser] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const loadUser = async () => {
      const currentUser = await base44.auth.me();
      if (!currentUser || currentUser.role !== 'admin') {
        window.location.href = '/';
        return;
      }
      setUser(currentUser);
    };
    loadUser();
  }, []);

  const { data: users = [] } = useQuery({
    queryKey: ['crm-users'],
    queryFn: () => base44.entities.User.list(),
  });

  const { data: posts = [] } = useQuery({
    queryKey: ['user-posts'],
    queryFn: () => base44.entities.Post.list(),
  });

  const filteredUsers = users.filter(u => 
    u.full_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    u.email?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (!user) return null;

  return (
    <div className="min-h-screen bg-black text-white pb-20">
      <div className="max-w-7xl mx-auto px-6 py-12">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-12">
          <h1 className="text-4xl font-light uppercase tracking-wider mb-2">User Management (CRM)</h1>
          <p className="text-gray-500 text-sm uppercase tracking-wider">Track & manage users</p>
        </motion.div>

        <div className="bg-gray-950 border border-gray-900 p-6 mb-8">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
            <Input value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder="Search users..." className="bg-black border-gray-800 text-white pl-10" />
          </div>
        </div>

        <div className="space-y-4">
          {filteredUsers.map((u, idx) => {
            const userPosts = posts.filter(p => p.author_email === u.email);
            return (
              <motion.div key={u.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: idx * 0.02 }} className="bg-gray-950 border border-gray-900 p-6">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-4">
                    <img src={u.avatar || `https://ui-avatars.com/api/?name=${u.full_name}`} alt={u.full_name} className="w-16 h-16 rounded-full" />
                    <div>
                      <h3 className="text-lg font-light mb-1">{u.full_name}</h3>
                      <div className="flex items-center gap-2 text-sm text-gray-500 mb-2">
                        <Mail className="w-3 h-3" />
                        {u.email}
                      </div>
                      <Badge className={u.role === 'admin' ? 'bg-[#E22718]' : 'bg-[#0066B1]'}>{u.role}</Badge>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-light text-[#0066B1] mb-1">{userPosts.length}</div>
                    <p className="text-xs text-gray-500 uppercase tracking-wider">Posts</p>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}