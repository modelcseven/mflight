import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { Search, Plus, MapPin, DollarSign, Eye, FileText, Download } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import jsPDF from 'jspdf';

export default function Marketplace() {
  const [user, setUser] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [selectedListing, setSelectedListing] = useState(null);

  const queryClient = useQueryClient();

  useEffect(() => {
    const loadUser = async () => {
      const currentUser = await base44.auth.me().catch(() => null);
      setUser(currentUser);
    };
    loadUser();
  }, []);

  const { data: listings = [] } = useQuery({
    queryKey: ['marketplace-listings'],
    queryFn: () => base44.entities.MarketplaceListing.filter({ status: 'active' }),
  });

  const filteredListings = listings.filter(listing => {
    const matchesSearch = listing.title.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || listing.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const generateContract = async (listing, buyerInfo) => {
    const doc = new jsPDF();
    
    doc.setFontSize(20);
    doc.text('MFLIGHT Marketplace Contract', 20, 20);
    
    doc.setFontSize(12);
    doc.text(`Date: ${new Date().toLocaleDateString()}`, 20, 40);
    doc.text(`Seller: ${listing.seller_name}`, 20, 50);
    doc.text(`Buyer: ${buyerInfo.name}`, 20, 60);
    doc.text(`Item: ${listing.title}`, 20, 70);
    doc.text(`Price: $${listing.price}`, 20, 80);
    doc.text(`Condition: ${listing.condition}`, 20, 90);
    
    doc.text('Terms & Conditions:', 20, 110);
    doc.setFontSize(10);
    doc.text('1. The buyer agrees to purchase the item as-is.', 20, 120);
    doc.text('2. Payment must be completed within 48 hours.', 20, 130);
    doc.text('3. Seller responsible for accurate description.', 20, 140);
    
    doc.save(`contract-${listing.id}.pdf`);

    await base44.entities.Contract.create({
      listing_id: listing.id,
      buyer_email: user.email,
      buyer_name: user.full_name,
      seller_email: listing.seller_email,
      seller_name: listing.seller_name,
      item_description: listing.title,
      agreed_price: listing.price,
      payment_method: buyerInfo.paymentMethod,
      shipping_address: buyerInfo.address,
      contract_date: new Date().toISOString(),
      status: 'signed'
    });
  };

  return (
    <div className="min-h-screen bg-black text-white pb-20">
      <div className="max-w-7xl mx-auto px-6 py-12">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-12">
          <h1 className="text-4xl font-light uppercase tracking-wider mb-4">Marketplace</h1>
          <p className="text-gray-500 text-sm uppercase tracking-wider">Buy, Sell & Trade BMW Parts</p>
        </motion.div>

        {/* Search & Filters */}
        <div className="bg-gray-950 border border-gray-900 p-6 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="md:col-span-2 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <Input value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder="Search parts..." className="bg-black border-gray-800 text-white pl-10" />
            </div>
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="bg-black border-gray-800 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-black border-gray-800">
                <SelectItem value="all">All Categories</SelectItem>
                <SelectItem value="Engine">Engine</SelectItem>
                <SelectItem value="Suspension">Suspension</SelectItem>
                <SelectItem value="Exhaust">Exhaust</SelectItem>
                <SelectItem value="Wheels">Wheels</SelectItem>
                <SelectItem value="Brakes">Brakes</SelectItem>
              </SelectContent>
            </Select>
          </div>
          {user && (
            <CreateListingDialog open={createDialogOpen} onOpenChange={setCreateDialogOpen} user={user} />
          )}
        </div>

        {/* Listings Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {filteredListings.map((listing, idx) => (
            <motion.div key={listing.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: idx * 0.05 }} className="bg-gray-950 border border-gray-900 overflow-hidden hover:border-[#0066B1] transition-colors">
              <div className="relative h-48 bg-gray-900">
                {listing.images?.[0] && <img src={listing.images[0]} alt={listing.title} className="w-full h-full object-cover" />}
                <Badge className="absolute top-4 right-4 bg-[#0066B1]">{listing.condition}</Badge>
              </div>
              <div className="p-6">
                <h3 className="text-lg font-light mb-2">{listing.title}</h3>
                <div className="flex items-center gap-2 text-sm text-gray-500 mb-4">
                  <MapPin className="w-4 h-4" />
                  <span>{listing.location}</span>
                </div>
                <div className="flex items-center justify-between mb-4">
                  <span className="text-2xl font-light text-[#E22718]">${listing.price}</span>
                  <div className="flex items-center gap-1 text-xs text-gray-500">
                    <Eye className="w-3 h-3" />
                    {listing.views}
                  </div>
                </div>
                <ListingDialog listing={listing} user={user} onContract={generateContract} />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}

function CreateListingDialog({ open, onOpenChange, user }) {
  const [formData, setFormData] = useState({ title: '', description: '', price: '', category: 'Engine', condition: 'Good', location: '' });
  const queryClient = useQueryClient();

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.MarketplaceListing.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['marketplace-listings'] });
      onOpenChange(false);
    }
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    createMutation.mutate({ ...formData, seller_email: user.email, seller_name: user.full_name, price: parseFloat(formData.price) });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogTrigger asChild>
        <Button className="mt-4 bg-[#E22718] hover:bg-[#C01F12]"><Plus className="w-4 h-4 mr-2" />Create Listing</Button>
      </DialogTrigger>
      <DialogContent className="bg-black border-gray-900 text-white">
        <DialogHeader><DialogTitle>Create New Listing</DialogTitle></DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <Input placeholder="Title" value={formData.title} onChange={(e) => setFormData({...formData, title: e.target.value})} required className="bg-gray-950 border-gray-800" />
          <Textarea placeholder="Description" value={formData.description} onChange={(e) => setFormData({...formData, description: e.target.value})} className="bg-gray-950 border-gray-800" />
          <Input type="number" placeholder="Price" value={formData.price} onChange={(e) => setFormData({...formData, price: e.target.value})} required className="bg-gray-950 border-gray-800" />
          <Input placeholder="Location" value={formData.location} onChange={(e) => setFormData({...formData, location: e.target.value})} className="bg-gray-950 border-gray-800" />
          <Button type="submit" className="w-full bg-[#E22718]">Create Listing</Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function ListingDialog({ listing, user, onContract }) {
  const [open, setOpen] = useState(false);
  const [buyerInfo, setBuyerInfo] = useState({ name: user?.full_name || '', address: '', paymentMethod: 'PayPal' });

  const handleContact = async () => {
    await onContract(listing, buyerInfo);
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="w-full bg-[#0066B1]">View Details</Button>
      </DialogTrigger>
      <DialogContent className="bg-black border-gray-900 text-white max-w-2xl">
        <DialogHeader><DialogTitle>{listing.title}</DialogTitle></DialogHeader>
        <div className="space-y-4">
          <p className="text-gray-400">{listing.description}</p>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div><span className="text-gray-500">Price:</span> ${listing.price}</div>
            <div><span className="text-gray-500">Condition:</span> {listing.condition}</div>
            <div><span className="text-gray-500">Category:</span> {listing.category}</div>
            <div><span className="text-gray-500">Location:</span> {listing.location}</div>
          </div>
          {user && user.email !== listing.seller_email && (
            <div className="space-y-3 pt-4 border-t border-gray-900">
              <h4 className="text-sm uppercase tracking-wider text-gray-400">Generate Contract</h4>
              <Input placeholder="Your Name" value={buyerInfo.name} onChange={(e) => setBuyerInfo({...buyerInfo, name: e.target.value})} className="bg-gray-950 border-gray-800" />
              <Input placeholder="Shipping Address" value={buyerInfo.address} onChange={(e) => setBuyerInfo({...buyerInfo, address: e.target.value})} className="bg-gray-950 border-gray-800" />
              <Button onClick={handleContact} className="w-full bg-[#E22718]"><Download className="w-4 h-4 mr-2" />Generate Contract PDF</Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}