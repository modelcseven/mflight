import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Camera, Edit, MoreHorizontal, UserPlus, MessageCircle, ChevronDown, Briefcase, GraduationCap, MapPin, Heart, Clock, Play, Plus, Upload, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import PostCard from '../components/feed/PostCard';
import CreatePostBox from '../components/feed/CreatePostBox';
import GarageBanner from '../components/profile/GarageBanner';
import FleetStats from '../components/profile/FleetStats';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function Profile() {
  const [user, setUser] = useState(null);
  const [profileUser, setProfileUser] = useState(null);
  const [isEditCoverOpen, setIsEditCoverOpen] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [coverType, setCoverType] = useState('image');
  const queryClient = useQueryClient();
  const fileInputRef = React.useRef(null);
  
  const urlParams = new URLSearchParams(window.location.search);
  const profileEmail = urlParams.get('email');

  useEffect(() => {
    const loadUsers = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    };
    loadUsers();
  }, []);

  const { data: users = [] } = useQuery({
    queryKey: ['users'],
    queryFn: () => base44.entities.User.list(),
    enabled: !!profileEmail,
    retry: 1,
  });

  useEffect(() => {
    if (users.length > 0 && profileEmail) {
      const found = users.find(u => u.email === profileEmail);
      setProfileUser(found);
    }
  }, [users, profileEmail]);

  const { data: posts = [] } = useQuery({
    queryKey: ['user-posts', profileEmail],
    queryFn: () => base44.entities.Post.filter({ author_email: profileEmail }, '-created_date'),
    enabled: !!profileEmail && !!profileUser,
    retry: 1,
  });

  const { data: friendRequest } = useQuery({
    queryKey: ['friend-request', user?.email, profileEmail],
    queryFn: async () => {
      const sent = await base44.entities.FriendRequest.filter({
        from_email: user?.email,
        to_email: profileEmail
      });
      const received = await base44.entities.FriendRequest.filter({
        from_email: profileEmail,
        to_email: user?.email
      });
      return sent[0] || received[0] || null;
    },
    enabled: !!user?.email && !!profileEmail && user?.email !== profileEmail && !!profileUser,
    retry: 1,
  });

  const { data: friendsSent = [] } = useQuery({
    queryKey: ['friends-sent', profileEmail],
    queryFn: () => base44.entities.FriendRequest.filter({ from_email: profileEmail, status: 'accepted' }),
    enabled: !!profileEmail && !!profileUser,
    retry: 1,
  });

  const { data: friendsReceived = [] } = useQuery({
    queryKey: ['friends-received', profileEmail],
    queryFn: () => base44.entities.FriendRequest.filter({ to_email: profileEmail, status: 'accepted' }),
    enabled: !!profileEmail && !!profileUser,
    retry: 1,
  });

  const totalFriends = friendsSent.length + friendsReceived.length;

  const sendFriendRequestMutation = useMutation({
    mutationFn: () => base44.entities.FriendRequest.create({
      from_email: user.email,
      from_name: user.full_name,
      from_avatar: user.avatar,
      to_email: profileEmail,
      status: 'pending'
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['friend-request'] });
      base44.entities.Notification.create({
        user_email: profileEmail,
        type: 'friend_request',
        from_name: user.full_name,
        from_avatar: user.avatar,
        message: `${user.full_name} sent you a friend request`,
        read: false
      });
    },
  });

  const updatePostMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Post.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['user-posts'] }),
  });

  const createPostMutation = useMutation({
    mutationFn: (postData) => base44.entities.Post.create(postData),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['user-posts'] }),
  });

  const handleLike = async (post, isLiking) => {
    if (!user) return;
    // Security: only current user can add/remove their own like
    const newLikes = isLiking
      ? [...new Set([...(post.likes || []), user.email])]
      : (post.likes || []).filter(email => email !== user.email);
    await updatePostMutation.mutateAsync({ id: post.id, data: { likes: newLikes } });
  };

  const handleComment = async (post, comment) => {
    if (!user) return;
    // Security: force comment identity to logged-in user
    const safeComment = { ...comment, author_email: user.email, author_name: user.full_name, author_avatar: user.avatar };
    const newComments = [...(post.comments || []), safeComment];
    await updatePostMutation.mutateAsync({ id: post.id, data: { comments: newComments } });
  };

  const handleShare = async (post) => {
    await updatePostMutation.mutateAsync({
      id: post.id,
      data: { shares_count: (post.shares_count || 0) + 1 }
    });
  };

  const handleCreatePost = async (postData) => {
    if (!user || !isOwnProfile) return; // Security: only own profile can create posts
    await createPostMutation.mutateAsync(postData);
  };

  const updateCoverMutation = useMutation({
    mutationFn: (coverData) => base44.auth.updateMe(coverData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['users'] });
      setIsEditCoverOpen(false);
      window.location.reload();
    },
  });

  const handleCoverUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    try {
      const response = await base44.integrations.Core.UploadFile({ file });
      if (coverType === 'image') {
        await updateCoverMutation.mutateAsync({ cover_photo: response.file_url });
      } else {
        await updateCoverMutation.mutateAsync({ cover_video: response.file_url });
      }
    } catch (error) {
      console.error('Upload failed:', error);
    } finally {
      setIsUploading(false);
    }
  };

  const isOwnProfile = user?.email === profileEmail;
  const isFriend = friendRequest?.status === 'accepted';
  const isPending = friendRequest?.status === 'pending';

  const { data: garages = [] } = useQuery({
    queryKey: ['garages', profileEmail],
    queryFn: () => base44.entities.Garage.filter({ owner_email: profileEmail }),
    enabled: !!profileEmail && !!profileUser,
    retry: 1,
  });

  const { data: allCars = [] } = useQuery({
    queryKey: ['cars', profileEmail],
    queryFn: () => base44.entities.Car.filter({ owner_email: profileEmail }),
    enabled: !!profileEmail && !!profileUser,
    retry: 1,
  });

  const avatar = profileUser?.avatar || `https://ui-avatars.com/api/?name=${profileUser?.full_name || 'User'}&background=random&size=200`;
  const coverPhoto = profileUser?.cover_photo || 'https://images.unsplash.com/photo-1614850523459-c2f4c699c52e?w=1200&h=400&fit=crop';

  if (!profileUser) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#1877F2]" />
      </div>
    );
  }

  return (
    <div className="bg-black min-h-screen">
      {/* Cover & Profile Header */}
      <div className="bg-black">
        <div className="max-w-[1095px] mx-auto">
          {/* Cover Photo */}
          <div className="relative h-[300px] overflow-hidden bg-black group">
            <img
              src={coverPhoto}
              alt="Cover"
              className="w-full h-full object-cover opacity-60"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent" />
            {isOwnProfile && (
              <Button
                variant="secondary"
                onClick={() => setIsEditCoverOpen(true)}
                className="absolute bottom-6 right-6 bg-black/80 backdrop-blur-sm hover:bg-gray-900 border-gray-900 text-white text-xs uppercase tracking-wider opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <Camera className="w-3 h-3 mr-2" />
                Edit cover
              </Button>
            )}
          </div>

          {/* Additional Cover Images */}
          {isOwnProfile && (
            <div className="grid grid-cols-3 gap-2 px-6 mt-2">
              {[1, 2, 3].map((idx) => {
                const imgKey = `cover_image_${idx}`;
                const imgUrl = profileUser?.[imgKey];
                return (
                  <div
                    key={idx}
                    onClick={() => {
                      const input = document.createElement('input');
                      input.type = 'file';
                      input.accept = 'image/*';
                      input.onchange = async (e) => {
                        const file = e.target.files?.[0];
                        if (!file) return;
                        setIsUploading(true);
                        try {
                          const response = await base44.integrations.Core.UploadFile({ file });
                          await base44.auth.updateMe({ [imgKey]: response.file_url });
                          window.location.reload();
                        } catch (error) {
                          console.error('Upload failed:', error);
                        } finally {
                          setIsUploading(false);
                        }
                      };
                      input.click();
                    }}
                    className="relative h-24 bg-gray-900 border border-gray-800 hover:border-[#0066B1] transition cursor-pointer group/img overflow-hidden"
                  >
                    {imgUrl ? (
                      <img src={imgUrl} alt={`Cover ${idx}`} className="w-full h-full object-cover" />
                    ) : (
                      <div className="flex items-center justify-center h-full">
                        <Plus className="w-6 h-6 text-gray-600 group-hover/img:text-[#0066B1] transition" />
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {/* Profile Info */}
          <div className="px-6 pb-6 relative">
            <div className="flex flex-col md:flex-row md:items-end gap-6">
              {/* Avatar */}
              <div className="relative -mt-[60px] md:-mt-[40px]">
                <div className="p-0.5 bg-white rounded-full">
                  <img
                    src={avatar}
                    alt={profileUser.full_name}
                    className="w-[120px] h-[120px] rounded-full border-2 border-black object-cover"
                  />
                </div>
                {isOwnProfile && (
                  <button className="absolute bottom-2 right-2 p-2 bg-black rounded-full hover:bg-gray-900 transition-all border border-gray-800">
                    <Camera className="w-4 h-4 text-white" />
                  </button>
                )}
              </div>

              {/* Name & Stats */}
              <div className="flex-1 pb-6">
                <h1 className="text-2xl font-light text-white tracking-wide mb-1 uppercase">{profileUser.full_name}</h1>
                <p className="text-gray-500 text-xs uppercase tracking-widest mb-4">{totalFriends} MEMBERS</p>
                
                {/* Fleet Stats */}
                <div className="flex gap-3 mt-4">
                  <div className="bg-gray-900/50 border border-gray-900 px-4 py-2">
                    <div className="flex items-center gap-2">
                      <span className="text-white font-light text-lg">{garages.length}</span>
                      <span className="text-gray-500 text-xs uppercase tracking-wider">Garages</span>
                    </div>
                  </div>
                  <div className="bg-gray-900/50 border border-gray-900 px-4 py-2">
                    <div className="flex items-center gap-2">
                      <span className="text-white font-light text-lg">{allCars?.length || 0}</span>
                      <span className="text-gray-500 text-xs uppercase tracking-wider">Vehicles</span>
                    </div>
                  </div>
                  <div className="bg-gray-900/50 border border-gray-900 px-4 py-2">
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-gray-500" />
                      <span className="text-gray-500 text-xs uppercase tracking-wider">{new Date(profileUser.created_date).getFullYear()}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Actions */}
              {!isOwnProfile && (
                <div className="flex gap-2 pb-6">
                  {isFriend ? (
                    <Button variant="secondary" className="bg-gray-900 hover:bg-gray-800 border-gray-900 text-white text-xs uppercase tracking-widest">
                      Connected
                    </Button>
                  ) : isPending ? (
                    <Button variant="secondary" disabled className="bg-gray-900 border-gray-900 text-gray-600 text-xs uppercase tracking-widest">
                      Pending
                    </Button>
                  ) : (
                    <Button 
                      className="bg-white text-black hover:bg-gray-200 text-xs uppercase tracking-widest font-medium"
                      onClick={() => sendFriendRequestMutation.mutate()}
                    >
                      Connect
                    </Button>
                  )}
                  <Link to={createPageUrl(`Messages?to=${profileEmail}`)}>
                    <Button variant="secondary" className="bg-gray-900 hover:bg-gray-800 border-gray-900 text-white text-xs uppercase tracking-widest">
                      Message
                    </Button>
                  </Link>
                </div>
              )}
            </div>

            {/* Navigation Tabs */}
            <div className="border-t border-gray-900 mt-6 -mx-6 px-6">
              <div className="flex gap-6">
                <Link
                  to={createPageUrl(`Profile?email=${profileEmail}`)}
                  className="px-0 py-4 text-xs font-medium text-white border-b-2 border-white uppercase tracking-widest"
                >
                  FEED
                </Link>
                <Link
                  to={createPageUrl(`Garage?email=${profileEmail}`)}
                  className="px-0 py-4 text-xs font-medium text-gray-600 hover:text-gray-400 transition-all uppercase tracking-widest"
                >
                  GARAGE
                </Link>
                <Link
                  to={createPageUrl(`Profile?email=${profileEmail}&tab=vehicles`)}
                  className="px-0 py-4 text-xs font-medium text-gray-600 hover:text-gray-400 transition-all uppercase tracking-widest"
                >
                  VEHICLES
                </Link>
                <Link
                  to={createPageUrl(`Bio?email=${profileEmail}`)}
                  className="px-0 py-4 text-xs font-medium text-gray-600 hover:text-gray-400 transition-all uppercase tracking-widest"
                >
                  ABOUT
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-[1095px] mx-auto py-6 px-6">
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Left Column - Intro */}
          <div className="w-full lg:w-[360px] space-y-4">
            <div className="bg-gray-950 border border-gray-900 p-6">
              <h2 className="text-xs font-medium text-white mb-5 uppercase tracking-widest">About</h2>
              <div className="space-y-4">
                {/* Public fields — visible to everyone */}
                {profileUser.work && (
                  <div className="flex items-center gap-3 text-gray-300">
                    <Briefcase className="w-5 h-5 text-cyan-400" />
                    <span>Works at <span className="font-semibold text-white">{profileUser.work}</span></span>
                  </div>
                )}
                {profileUser.education && (
                  <div className="flex items-center gap-3 text-gray-300">
                    <GraduationCap className="w-5 h-5 text-cyan-400" />
                    <span>Studied at <span className="font-semibold text-white">{profileUser.education}</span></span>
                  </div>
                )}
                {profileUser.location && (
                  <div className="flex items-center gap-3 text-gray-300">
                    <MapPin className="w-5 h-5 text-cyan-400" />
                    <span>Lives in <span className="font-semibold text-white">{profileUser.location}</span></span>
                  </div>
                )}
                {profileUser.relationship && (
                  <div className="flex items-center gap-3 text-gray-300">
                    <Heart className="w-5 h-5 text-cyan-400" />
                    <span className="text-white">{profileUser.relationship}</span>
                  </div>
                )}
                <div className="flex items-center gap-3 text-gray-300">
                  <Clock className="w-5 h-5 text-cyan-400" />
                  <span>Joined {new Date(profileUser.created_date).toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}</span>
                </div>

                {/* Private fields — only visible to the profile owner */}
                {isOwnProfile && (
                  <div className="mt-4 pt-4 border-t border-gray-800 space-y-3">
                    <p className="text-[10px] uppercase tracking-widest text-gray-600">Private (only you see this)</p>
                    {profileUser.region && (
                      <div className="flex items-center gap-3 text-gray-500 text-xs">
                        <span>Region: <span className="text-gray-300">{profileUser.region}</span></span>
                      </div>
                    )}
                    {profileUser.country && (
                      <div className="flex items-center gap-3 text-gray-500 text-xs">
                        <span>Country: <span className="text-gray-300">{profileUser.country}</span></span>
                      </div>
                    )}
                    {profileUser.military_base && (
                      <div className="flex items-center gap-3 text-gray-500 text-xs">
                        <span>Base: <span className="text-gray-300">{profileUser.military_base}</span></span>
                      </div>
                    )}
                  </div>
                )}
              </div>
              {isOwnProfile && (
                <Button variant="secondary" className="w-full mt-5 bg-black hover:bg-gray-900 border-gray-900 text-white text-xs uppercase tracking-wider">
                  Edit
                </Button>
              )}
            </div>

            {/* Media Preview (Photos & Videos) */}
            {posts.some(p => p.image_url || p.video_url) && (
              <div className="bg-gray-950 border border-gray-900 p-6">
                <div className="flex items-center justify-between mb-5">
                  <h2 className="text-xs font-medium text-white uppercase tracking-widest">Media</h2>
                  <button className="text-gray-500 hover:text-white text-xs uppercase tracking-wider transition-colors">
                    View All
                  </button>
                </div>
                <div className="grid grid-cols-3 gap-1">
                  {posts.filter(p => p.image_url || p.video_url).slice(0, 9).map((post, idx) => (
                    <div key={post.id} className="aspect-square relative group cursor-pointer overflow-hidden">
                      {post.video_url ? (
                        <>
                          <img
                            src={post.video_thumbnail || 'https://images.unsplash.com/photo-1516573900242-5433156b28cb?w=150'}
                            alt="Video thumbnail"
                            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                          />
                          <div className="absolute inset-0 flex items-center justify-center bg-black/40 group-hover:bg-black/60 transition-colors">
                            <Play className="w-8 h-8 text-white fill-white drop-shadow-lg" />
                          </div>
                        </>
                      ) : (
                        <img
                          src={post.image_url}
                          alt=""
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                        />
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Right Column - Posts */}
          <div className="flex-1 space-y-4">
            {isOwnProfile && (
              <CreatePostBox user={user} onPost={handleCreatePost} />
            )}

            {/* Garages Section */}
            {garages.length > 0 && (
              <div className="space-y-4">
                <div className="flex items-center justify-between px-4 md:px-0">
                  <h2 className="text-xs font-medium text-white uppercase tracking-widest">Garages</h2>
                  {isOwnProfile && (
                    <Link to={createPageUrl('Garages')}>
                      <Button size="sm" className="bg-gradient-to-r from-cyan-500 to-blue-600">
                        <Plus className="w-4 h-4" />
                      </Button>
                    </Link>
                  )}
                </div>
                {garages.slice(0, 2).map(garage => (
                  <GarageBanner
                    key={garage.id}
                    user={user}
                    garage={garage}
                    carCount={allCars?.filter(c => c.garage_id === garage.id).length || 0}
                    isOwnProfile={isOwnProfile}
                  />
                ))}
              </div>
            )}
            
            {posts.map((post) => (
              <PostCard
                key={post.id}
                post={post}
                currentUser={user}
                onLike={handleLike}
                onComment={handleComment}
                onShare={handleShare}
              />
            ))}
            
            {posts.length === 0 && (
              <div className="bg-gray-950 border border-gray-900 p-10 text-center">
                <p className="text-gray-600 text-xs uppercase tracking-wider">No Activity</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Edit Cover Dialog */}
      <Dialog open={isEditCoverOpen} onOpenChange={setIsEditCoverOpen}>
        <DialogContent className="bg-black border-gray-900">
          <DialogHeader>
            <DialogTitle className="text-white text-xs uppercase tracking-widest">Edit Cover Photo</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="flex gap-2">
              <Button
                variant={coverType === 'image' ? 'default' : 'outline'}
                onClick={() => setCoverType('image')}
                className="flex-1 text-xs uppercase tracking-wider"
              >
                Image
              </Button>
              <Button
                variant={coverType === 'video' ? 'default' : 'outline'}
                onClick={() => setCoverType('video')}
                className="flex-1 text-xs uppercase tracking-wider"
              >
                Video
              </Button>
            </div>

            <div 
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-gray-700 rounded-lg p-8 text-center cursor-pointer hover:border-gray-600 transition-colors"
            >
              {isUploading ? (
                <Loader2 className="w-12 h-12 text-gray-500 mx-auto mb-4 animate-spin" />
              ) : (
                <Upload className="w-12 h-12 text-gray-500 mx-auto mb-4" />
              )}
              <p className="text-gray-400 text-sm">
                {isUploading ? 'Uploading...' : `Click to upload ${coverType}`}
              </p>
              <p className="text-gray-600 text-xs mt-2">
                {coverType === 'image' ? 'Recommended: 1200x400px' : 'Max size: 50MB'}
              </p>
            </div>

            <input
              ref={fileInputRef}
              type="file"
              accept={coverType === 'image' ? 'image/*' : 'video/*'}
              onChange={handleCoverUpload}
              className="hidden"
            />

            <Button
              variant="secondary"
              onClick={() => setIsEditCoverOpen(false)}
              className="w-full bg-gray-900 hover:bg-gray-800 text-white text-xs uppercase tracking-wider"
            >
              Cancel
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}