import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Plus, ArrowLeft, Edit, Trash2, Euro, Zap, Scale } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { motion, AnimatePresence } from 'framer-motion';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import PerformanceChart from '../components/car/PerformanceChart';
import CarComparison from '../components/car/CarComparison';

function ModCard({ mod, onEdit, onDelete }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-gray-800 border border-gray-700 rounded-lg overflow-hidden hover:border-cyan-500 transition-colors"
    >
      {mod.after_image && (
        <div className="h-40 overflow-hidden bg-gray-700">
          <img src={mod.after_image} alt={mod.name} className="w-full h-full object-cover hover:scale-110 transition-transform" />
        </div>
      )}
      <div className="p-4">
        <h3 className="text-lg font-bold text-white mb-1">{mod.name}</h3>
        <p className="text-cyan-400 text-sm mb-2">{mod.category}</p>
        <p className="text-gray-400 text-sm mb-3">{mod.description}</p>

        {mod.specifications && (
          <p className="text-gray-500 text-xs mb-3 italic">{mod.specifications}</p>
        )}

        {mod.cost && (
          <div className="flex items-center gap-2 text-amber-400 font-semibold mb-3">
            <Euro className="w-4 h-4" />
            <span>{parseFloat(mod.cost).toFixed(2)}</span>
          </div>
        )}

        <div className="flex gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onEdit(mod)}
            className="flex-1 text-cyan-400 hover:bg-gray-700"
          >
            <Edit className="w-4 h-4 mr-2" />
            Edit
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onDelete(mod.id)}
            className="flex-1 text-red-500 hover:bg-gray-700"
          >
            <Trash2 className="w-4 h-4 mr-2" />
            Delete
          </Button>
        </div>
      </div>
    </motion.div>
  );
}

export default function CarDetail() {
  const [user, setUser] = useState(null);
  const [car, setCar] = useState(null);
  const [isModDialogOpen, setIsModDialogOpen] = useState(false);
  const [isPerformanceDialogOpen, setIsPerformanceDialogOpen] = useState(false);
  const [isComparisonOpen, setIsComparisonOpen] = useState(false);
  const [comparisonCar, setComparisonCar] = useState(null);
  const [performanceFormData, setPerformanceFormData] = useState({
    date: new Date().toISOString().split('T')[0],
    zero_to_60: '',
    top_speed: '',
    quarter_mile: '',
    notes: ''
  });
  const [modFormData, setModFormData] = useState({
    name: '',
    category: 'Engine',
    description: '',
    before_image: '',
    after_image: '',
    cost: '',
    installation_date: new Date().toISOString().split('T')[0],
    specifications: ''
  });
  const queryClient = useQueryClient();

  const carId = new URLSearchParams(window.location.search).get('id');

  useEffect(() => {
    const loadData = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
      if (carId) {
        const carData = await base44.entities.Car.read(carId);
        setCar(carData);
      }
    };
    loadData();
  }, [carId]);

  const modCategories = ['Engine', 'Suspension', 'Brakes', 'Wheels', 'Exterior', 'Interior', 'Turbo', 'ECU', 'Exhaust', 'Transmission'];

  const updateCarMutation = useMutation({
    mutationFn: (data) => base44.entities.Car.update(carId, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['garage-cars'] });
      setIsModDialogOpen(false);
    },
  });

  const handleAddMod = async () => {
    if (!modFormData.name.trim() || !modFormData.category) return;

    const newMod = {
      id: Math.random().toString(36).substr(2, 9),
      ...modFormData
    };

    const updatedMods = [...(car.mods || []), newMod];
    const totalInvestment = updatedMods.reduce((sum, mod) => sum + (parseFloat(mod.cost) || 0), 0);

    await updateCarMutation.mutateAsync({
      mods: updatedMods,
      total_investment: totalInvestment.toString()
    });

    setModFormData({
      name: '',
      category: 'Engine',
      description: '',
      before_image: '',
      after_image: '',
      cost: '',
      installation_date: new Date().toISOString().split('T')[0],
      specifications: ''
    });
  };

  const handleDeleteMod = async (modId) => {
    const updatedMods = car.mods.filter(m => m.id !== modId);
    const totalInvestment = updatedMods.reduce((sum, mod) => sum + (parseFloat(mod.cost) || 0), 0);

    await updateCarMutation.mutateAsync({
      mods: updatedMods,
      total_investment: totalInvestment.toString()
    });
  };

  const handleAddPerformanceMetric = async () => {
    if (!performanceFormData.date) return;

    const newMetric = {
      id: Math.random().toString(36).substr(2, 9),
      date: performanceFormData.date,
      zero_to_60: performanceFormData.zero_to_60 ? parseFloat(performanceFormData.zero_to_60) : undefined,
      top_speed: performanceFormData.top_speed ? parseFloat(performanceFormData.top_speed) : undefined,
      quarter_mile: performanceFormData.quarter_mile ? parseFloat(performanceFormData.quarter_mile) : undefined,
      notes: performanceFormData.notes
    };

    const updatedMetrics = [...(car.performance_metrics || []), newMetric];

    await updateCarMutation.mutateAsync({
      performance_metrics: updatedMetrics
    });

    setPerformanceFormData({
      date: new Date().toISOString().split('T')[0],
      zero_to_60: '',
      top_speed: '',
      quarter_mile: '',
      notes: ''
    });
    setIsPerformanceDialogOpen(false);
  };

  const { data: allCars = [] } = useQuery({
    queryKey: ['all-cars', car?.garage_id],
    queryFn: () => base44.entities.Car.filter({ garage_id: car?.garage_id }),
    enabled: !!car?.garage_id,
  });

  if (!user || !car) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-56px)]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-cyan-400" />
      </div>
    );
  }

  return (
    <div className="min-h-[calc(100vh-56px)] bg-gray-900">
      {/* Hero */}
      {car.image_url && (
        <div className="h-72 overflow-hidden bg-gray-800 relative">
          <img src={car.image_url} alt={car.name} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-gray-900" />
        </div>
      )}

      {/* Content */}
      <div className="max-w-5xl mx-auto px-4 py-8">
        {/* Back Button */}
        <Link 
          to={createPageUrl(`GarageDetail?id=${car.garage_id}`)} 
          className="inline-flex items-center gap-2 text-cyan-400 hover:text-cyan-300 mb-6"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Garage
        </Link>

        {/* Header */}
        <div className="flex items-start justify-between mb-8">
          <div>
            <h1 className="text-4xl font-bold text-white mb-2">{car.name}</h1>
            <p className="text-2xl text-cyan-400 font-semibold">{car.year} {car.make} {car.model}</p>
            {car.color && <p className="text-gray-400">Color: {car.color}</p>}
          </div>
          <div className="flex gap-2">
            <Button
              onClick={() => setIsModDialogOpen(true)}
              className="bg-gradient-to-r from-cyan-500 to-blue-600"
            >
              <Plus className="w-5 h-5 mr-2" />
              Add Modification
            </Button>
            <Button
              onClick={() => setIsPerformanceDialogOpen(true)}
              variant="secondary"
              className="bg-gray-700 hover:bg-gray-600 text-white"
            >
              <Zap className="w-5 h-5 mr-2" />
              Log Performance
            </Button>
            {allCars.length > 1 && (
              <Button
                onClick={() => setIsComparisonOpen(true)}
                variant="secondary"
                className="bg-gray-700 hover:bg-gray-600 text-white"
              >
                <Scale className="w-5 h-5 mr-2" />
                Compare
              </Button>
            )}
          </div>
        </div>

        {/* Specifications */}
        {car.specifications && Object.keys(car.specifications).length > 0 && (
          <div className="bg-gray-800 border border-gray-700 rounded-lg p-6 mb-8">
            <h2 className="text-xl font-bold text-white mb-4">Specifications</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {car.specifications.engine && (
                <div>
                  <p className="text-gray-400 text-sm">Engine</p>
                  <p className="text-white font-semibold">{car.specifications.engine}</p>
                </div>
              )}
              {car.specifications.horsepower && (
                <div>
                  <p className="text-gray-400 text-sm">Horsepower</p>
                  <p className="text-amber-400 font-semibold">{car.specifications.horsepower}</p>
                </div>
              )}
              {car.specifications.torque && (
                <div>
                  <p className="text-gray-400 text-sm">Torque</p>
                  <p className="text-orange-400 font-semibold">{car.specifications.torque}</p>
                </div>
              )}
              {car.specifications['0_to_60'] && (
                <div>
                  <p className="text-gray-400 text-sm">0-60 mph</p>
                  <p className="text-cyan-400 font-semibold">{car.specifications['0_to_60']}</p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Performance Metrics */}
        {car.performance_metrics && car.performance_metrics.length > 0 && (
          <div className="mb-8">
            <PerformanceChart metrics={car.performance_metrics} />
          </div>
        )}

        {/* Investment Summary */}
        {car.mods && car.mods.length > 0 && (
          <div className="bg-gradient-to-r from-gray-800 to-gray-700 border border-gray-600 rounded-lg p-6 mb-8">
            <div className="grid grid-cols-3 gap-4">
              <div>
                <p className="text-gray-400 text-sm">Total Modifications</p>
                <p className="text-3xl font-bold text-white">{car.mods.length}</p>
              </div>
              <div>
                <p className="text-gray-400 text-sm">Total Investment</p>
                <p className="text-3xl font-bold text-amber-400">€{parseFloat(car.total_investment || 0).toFixed(2)}</p>
              </div>
              <div>
                <p className="text-gray-400 text-sm">Average per Mod</p>
                <p className="text-3xl font-bold text-cyan-400">€{(parseFloat(car.total_investment || 0) / car.mods.length).toFixed(2)}</p>
              </div>
            </div>
          </div>
        )}

        {/* Mods */}
        <div>
          <h2 className="text-2xl font-bold text-white mb-6">Modifications</h2>
          {car.mods && car.mods.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <AnimatePresence>
                {car.mods.map((mod) => (
                  <ModCard
                    key={mod.id}
                    mod={mod}
                    onEdit={(mod) => {
                      setModFormData(mod);
                      setIsModDialogOpen(true);
                    }}
                    onDelete={(modId) => handleDeleteMod(modId)}
                  />
                ))}
              </AnimatePresence>
            </div>
          ) : (
            <div className="bg-gray-800 border border-gray-700 rounded-lg p-12 text-center">
              <p className="text-gray-400 text-lg mb-6">No modifications added yet</p>
              <Button
                onClick={() => setIsModDialogOpen(true)}
                className="bg-gradient-to-r from-cyan-500 to-blue-600"
              >
                <Plus className="w-5 h-5 mr-2" />
                Add First Modification
              </Button>
            </div>
          )}
        </div>
      </div>

      {/* Performance Metrics Dialog */}
      <Dialog open={isPerformanceDialogOpen} onOpenChange={setIsPerformanceDialogOpen}>
        <DialogContent className="bg-gray-800 border-gray-700 max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-white">Log Performance Metrics</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Test Date</label>
              <Input
                type="date"
                value={performanceFormData.date}
                onChange={(e) => setPerformanceFormData({ ...performanceFormData, date: e.target.value })}
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">0-60 Time (s)</label>
                <Input
                  type="number"
                  placeholder="4.3"
                  step="0.1"
                  value={performanceFormData.zero_to_60}
                  onChange={(e) => setPerformanceFormData({ ...performanceFormData, zero_to_60: e.target.value })}
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Quarter Mile (s)</label>
                <Input
                  type="number"
                  placeholder="12.5"
                  step="0.1"
                  value={performanceFormData.quarter_mile}
                  onChange={(e) => setPerformanceFormData({ ...performanceFormData, quarter_mile: e.target.value })}
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Top Speed (km/h)</label>
                <Input
                  type="number"
                  placeholder="280"
                  value={performanceFormData.top_speed}
                  onChange={(e) => setPerformanceFormData({ ...performanceFormData, top_speed: e.target.value })}
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Notes</label>
              <Textarea
                placeholder="Weather conditions, tires, fuel type, etc."
                value={performanceFormData.notes}
                onChange={(e) => setPerformanceFormData({ ...performanceFormData, notes: e.target.value })}
                className="bg-gray-700 border-gray-600 text-white min-h-20"
              />
            </div>

            <div className="flex gap-3 pt-4">
              <Button
                variant="secondary"
                onClick={() => setIsPerformanceDialogOpen(false)}
                className="flex-1 bg-gray-700 hover:bg-gray-600"
              >
                Cancel
              </Button>
              <Button
                onClick={handleAddPerformanceMetric}
                className="flex-1 bg-gradient-to-r from-cyan-500 to-blue-600"
              >
                Log Metrics
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Car Comparison Dialog */}
      {isComparisonOpen && (
        <CarComparison
          isOpen={isComparisonOpen}
          onClose={() => {
            setIsComparisonOpen(false);
            setComparisonCar(null);
          }}
          car1={car}
          car2={comparisonCar || allCars.find(c => c.id !== car.id)}
        />
      )}

      {/* Add Mod Dialog */}
      <Dialog open={isModDialogOpen} onOpenChange={setIsModDialogOpen}>
        <DialogContent className="bg-gray-800 border-gray-700 max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-white">Add Modification</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 max-h-[70vh] overflow-y-auto">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Modification Name</label>
              <Input
                placeholder="e.g., Catted Downpipe"
                value={modFormData.name}
                onChange={(e) => setModFormData({ ...modFormData, name: e.target.value })}
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Category</label>
              <select
                value={modFormData.category}
                onChange={(e) => setModFormData({ ...modFormData, category: e.target.value })}
                className="w-full bg-gray-700 border border-gray-600 rounded text-white px-3 py-2"
              >
                {modCategories.map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Description</label>
              <Textarea
                placeholder="Describe the modification..."
                value={modFormData.description}
                onChange={(e) => setModFormData({ ...modFormData, description: e.target.value })}
                className="bg-gray-700 border-gray-600 text-white min-h-24"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Before Image URL</label>
                <Input
                  placeholder="https://..."
                  value={modFormData.before_image}
                  onChange={(e) => setModFormData({ ...modFormData, before_image: e.target.value })}
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">After Image URL</label>
                <Input
                  placeholder="https://..."
                  value={modFormData.after_image}
                  onChange={(e) => setModFormData({ ...modFormData, after_image: e.target.value })}
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Cost (€)</label>
                <Input
                  type="number"
                  placeholder="500"
                  value={modFormData.cost}
                  onChange={(e) => setModFormData({ ...modFormData, cost: e.target.value })}
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Installation Date</label>
                <Input
                  type="date"
                  value={modFormData.installation_date}
                  onChange={(e) => setModFormData({ ...modFormData, installation_date: e.target.value })}
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Specifications</label>
              <Input
                placeholder="e.g., +30 hp, -2 kg, stainless steel"
                value={modFormData.specifications}
                onChange={(e) => setModFormData({ ...modFormData, specifications: e.target.value })}
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>

            <div className="flex gap-3 pt-4">
              <Button
                variant="secondary"
                onClick={() => setIsModDialogOpen(false)}
                className="flex-1 bg-gray-700 hover:bg-gray-600"
              >
                Cancel
              </Button>
              <Button
                onClick={handleAddMod}
                className="flex-1 bg-gradient-to-r from-cyan-500 to-blue-600"
              >
                Add Modification
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}