import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import LeftSidebar from '../components/sidebar/LeftSidebar';
import RightSidebar from '../components/sidebar/RightSidebar';
import StoriesRow from '../components/feed/StoriesRow';
import CreatePostBox from '../components/feed/CreatePostBox';
import PostCard from '../components/feed/PostCard';
import { Loader2 } from 'lucide-react';
import FeedFilters from '../components/home/FeedFilters';
import AIAssistant from '../components/assistant/AIAssistant';

export default function Home() {
  const [user, setUser] = useState(null);
  const [feedFilter, setFeedFilter] = useState('all');
  const [theme, setTheme] = useState('dark');
  const queryClient = useQueryClient();

  useEffect(() => {
    const loadUser = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    };
    loadUser();

    // Listen for theme changes
    const handleStorage = () => {
      setTheme(localStorage.getItem('theme') || 'dark');
    };
    setTheme(localStorage.getItem('theme') || 'dark');
    window.addEventListener('storage', handleStorage);
    return () => window.removeEventListener('storage', handleStorage);
  }, []);

  const { data: posts = [], isLoading: postsLoading } = useQuery({
    queryKey: ['posts'],
    queryFn: () => base44.entities.Post.list('-created_date', 50),
  });

  const { data: stories = [] } = useQuery({
    queryKey: ['stories'],
    queryFn: () => base44.entities.Story.list('-created_date', 20),
  });

  const { data: friendRequests = [] } = useQuery({
    queryKey: ['friend-requests', user?.email],
    queryFn: () => base44.entities.FriendRequest.filter({ 
      from_email: user?.email, 
      status: 'accepted' 
    }),
    enabled: !!user?.email,
  });

  const { data: friendRequestsReceived = [] } = useQuery({
    queryKey: ['friend-requests-received', user?.email],
    queryFn: () => base44.entities.FriendRequest.filter({ 
      to_email: user?.email, 
      status: 'accepted' 
    }),
    enabled: !!user?.email,
  });

  const { data: allUsers = [] } = useQuery({
    queryKey: ['users'],
    queryFn: () => base44.entities.User.list(),
    enabled: !!user?.email,
  });

  // Get friends list
  const friendEmails = [
    ...friendRequests.map(fr => fr.to_email),
    ...friendRequestsReceived.map(fr => fr.from_email)
  ];
  const friends = allUsers.filter(u => friendEmails.includes(u.email));

  const createPostMutation = useMutation({
    mutationFn: (postData) => base44.entities.Post.create(postData),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['posts'] }),
  });

  const updatePostMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Post.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['posts'] }),
  });

  const handleCreatePost = async (postData) => {
    await createPostMutation.mutateAsync(postData);
    // Refresh the feed
    queryClient.invalidateQueries({ queryKey: ['posts'] });
  };

  const handleLike = async (post, isLiking) => {
    if (!user) return;
    // Security: only add/remove current user's own email — never touch others' likes
    const newLikes = isLiking
      ? [...new Set([...(post.likes || []), user.email])]
      : (post.likes || []).filter(email => email !== user.email);
    
    await updatePostMutation.mutateAsync({
      id: post.id,
      data: { likes: newLikes }
    });

    // Create notification if liking someone else's post
    if (isLiking && post.author_email !== user.email) {
      await base44.entities.Notification.create({
        user_email: post.author_email,
        type: 'like',
        from_name: user.full_name,
        from_avatar: user.avatar,
        post_id: post.id,
        message: `${user.full_name} liked your post`,
        read: false
      });
    }
  };

  const handleComment = async (post, comment) => {
    if (!user) return;
    // Security: force comment author to always be the logged-in user
    const safeComment = { ...comment, author_email: user.email, author_name: user.full_name, author_avatar: user.avatar };
    const newComments = [...(post.comments || []), safeComment];
    await updatePostMutation.mutateAsync({
      id: post.id,
      data: { comments: newComments }
    });

    // Create notification if commenting on someone else's post
    if (post.author_email !== user.email) {
      await base44.entities.Notification.create({
        user_email: post.author_email,
        type: 'comment',
        from_name: user.full_name,
        from_avatar: user.avatar,
        post_id: post.id,
        message: `${user.full_name} commented on your post`,
        read: false
      });
    }
  };

  const handleShare = async (post) => {
    await updatePostMutation.mutateAsync({
      id: post.id,
      data: { shares_count: (post.shares_count || 0) + 1 }
    });
  };

  const handleCreateStory = () => {
    const imageUrl = prompt('Enter image URL for your story:');
    if (imageUrl) {
      base44.entities.Story.create({
        author_name: user.full_name,
        author_avatar: user.avatar,
        author_email: user.email,
        image_url: imageUrl,
        expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString()
      });
    }
  };

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-cyan-400" />
      </div>
    );
  }

  const bgColor = theme === 'dark' ? 'bg-black' : 'bg-gray-50';
  const cardBg = theme === 'dark' ? 'bg-gray-950' : 'bg-white';
  const borderColor = theme === 'dark' ? 'border-gray-900' : 'border-gray-200';

  return (
    <div className={`pb-20 md:pb-0 ${bgColor} min-h-screen overflow-y-auto`}>
      <style>{`
        * {
          scrollbar-width: thin;
          scrollbar-color: ${theme === 'dark' ? '#333 #000' : '#D6D6D6 #fff'};
        }
        ::-webkit-scrollbar {
          width: 10px;
          height: 10px;
        }
        ::-webkit-scrollbar-track {
          background: ${theme === 'dark' ? '#000' : '#fff'};
        }
        ::-webkit-scrollbar-thumb {
          background: ${theme === 'dark' ? '#333' : '#D6D6D6'};
          border-radius: 5px;
        }
        ::-webkit-scrollbar-thumb:hover {
          background: #E22718;
        }
      `}</style>

      <div className="w-full max-w-7xl mx-auto py-8 px-6">
        {/* Stories */}
        <div className="mb-4">
          <StoriesRow stories={stories} onCreateStory={handleCreateStory} />
        </div>

        {/* Create Post */}
        <div className="mb-4">
          <CreatePostBox user={user} onPost={handleCreatePost} />
        </div>

        {/* Feed Filters - Right-aligned for thumb access */}
        <div className="mb-4">
          <FeedFilters activeFilter={feedFilter} onFilterChange={setFeedFilter} />
        </div>

        {/* Posts Feed */}
        {postsLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-cyan-400" />
          </div>
        ) : (
          <div className="space-y-6">
            {posts
              .filter(post => {
                if (feedFilter === 'all') return true;
                if (feedFilter === 'garages') return post.post_type === 'garage_update' || post.video_url || post.image_url;
                if (feedFilter === 'mods') return post.post_type === 'mod_spotlight';
                if (feedFilter === 'local') return post.location;
                return true;
              })
              .map((post) => (
                <PostCard
                  key={post.id}
                  post={post}
                  currentUser={user}
                  onLike={handleLike}
                  onComment={handleComment}
                  onShare={handleShare}
                />
              ))}
            {posts.length === 0 && (
              <div className={`${cardBg} border ${borderColor} p-12 text-center`}>
                <p className="text-gray-600 text-xs uppercase tracking-wider">No Activity</p>
              </div>
            )}
          </div>
        )}
      </div>

      {/* AI Assistant */}
      {user && <AIAssistant user={user} />}
    </div>
  );
}