import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { Plus, Edit, Trash2, X, Upload } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';

export default function AdminTuners() {
  const [user, setUser] = useState(null);
  const [editingTuner, setEditingTuner] = useState(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const queryClient = useQueryClient();

  React.useEffect(() => {
    const loadUser = async () => {
      const currentUser = await base44.auth.me();
      if (currentUser?.role !== 'admin') {
        window.location.href = '/';
        return;
      }
      setUser(currentUser);
    };
    loadUser();
  }, []);

  const { data: tuners = [], isLoading } = useQuery({
    queryKey: ['admin-tuners'],
    queryFn: () => base44.entities.Tuner.list('-created_date', 100),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Tuner.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-tuners'] });
      setDialogOpen(false);
      setEditingTuner(null);
    },
  });

  const updateMutation = useMutation({
    mutationFn: (data) => base44.entities.Tuner.update(editingTuner.id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-tuners'] });
      setDialogOpen(false);
      setEditingTuner(null);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Tuner.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-tuners'] });
    },
  });

  if (!user || user.role !== 'admin') return null;
  if (isLoading) return <div className="p-6">Loading...</div>;

  return (
    <div className="min-h-screen bg-black text-white pb-20">
      <div className="max-w-7xl mx-auto px-6 py-12">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-4xl font-light uppercase tracking-wider">Tuner Directory Management</h1>
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button 
                onClick={() => setEditingTuner(null)}
                className="bg-[#0066B1] hover:bg-[#0055A0]"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Tuner
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-black border-gray-900 text-white max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{editingTuner ? 'Edit Tuner' : 'Add New Tuner'}</DialogTitle>
              </DialogHeader>
              <TunerForm 
                tuner={editingTuner}
                onSubmit={(data) => {
                  if (editingTuner) {
                    updateMutation.mutate(data);
                  } else {
                    createMutation.mutate(data);
                  }
                }}
              />
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {tuners.map((tuner, idx) => (
            <motion.div
              key={tuner.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.05 }}
              className="bg-gray-950 border border-gray-900 p-6"
            >
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="text-lg font-medium mb-1">{tuner.name}</h3>
                  <p className="text-sm text-gray-500">{tuner.city}, {tuner.state_region || tuner.country}</p>
                </div>
                {tuner.certified && (
                  <Badge className="bg-[#0066B1]">Certified</Badge>
                )}
              </div>

              <div className="mb-4 text-sm text-gray-400">
                <p className="mb-2"><span className="text-gray-500">Services:</span> {tuner.services?.length || 0}</p>
                <p className="mb-2"><span className="text-gray-500">Models:</span> {tuner.supported_models?.length || 0}</p>
                <p className="mb-2"><span className="text-gray-500">Builds:</span> {tuner.builds?.length || 0}</p>
                <p><span className="text-gray-500">B&A Gallery:</span> {tuner.before_after?.length || 0}</p>
              </div>

              <div className="flex gap-2">
                <Dialog open={editingTuner?.id === tuner.id && dialogOpen} onOpenChange={(open) => {
                  if (open) {
                    setEditingTuner(tuner);
                    setDialogOpen(true);
                  } else {
                    setDialogOpen(false);
                    setEditingTuner(null);
                  }
                }}>
                  <DialogTrigger asChild>
                    <Button
                      onClick={() => {
                        setEditingTuner(tuner);
                        setDialogOpen(true);
                      }}
                      variant="outline"
                      className="flex-1 border-gray-800"
                    >
                      <Edit className="w-4 h-4 mr-2" />
                      Edit
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="bg-black border-gray-900 text-white max-w-2xl max-h-[90vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle>Edit Tuner</DialogTitle>
                    </DialogHeader>
                    <TunerForm 
                      tuner={tuner}
                      onSubmit={(data) => {
                        updateMutation.mutate(data);
                      }}
                    />
                  </DialogContent>
                </Dialog>

                <Button
                  onClick={() => {
                    if (confirm(`Delete ${tuner.name}?`)) {
                      deleteMutation.mutate(tuner.id);
                    }
                  }}
                  variant="outline"
                  className="flex-1 border-gray-800 text-red-500 hover:text-red-400"
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete
                </Button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}

function TunerForm({ tuner, onSubmit }) {
  const [formData, setFormData] = useState(tuner || {
    name: '',
    location: 'USA',
    country: '',
    state_region: '',
    city: '',
    address: '',
    phone: '',
    email: '',
    website: '',
    image: '',
    description: '',
    services: [],
    supported_models: [],
    builds: [],
    before_after: [],
    certified: false,
    coordinates: { lat: 0, lng: 0 }
  });

  const [newBuild, setNewBuild] = useState({ title: '', description: '', image: '', vehicle_model: '' });
  const [newBeforeAfter, setNewBeforeAfter] = useState({ before_image: '', after_image: '', description: '', performance_gain: '' });
  const [newModel, setNewModel] = useState('');
  const [newService, setNewService] = useState('');

  const SERVICES = [
    'ECU Tuning', 'TCU Tuning', 'Suspension Upgrades', 'Engine Builds',
    'Turbo Upgrades', 'Exhaust Systems', 'Brake Upgrades', 'Dyno Testing',
    'Alignment', 'Maintenance', 'Track Prep', 'Custom Fabrication'
  ];

  const handleAddBuild = () => {
    if (newBuild.title && newBuild.image) {
      setFormData(prev => ({
        ...prev,
        builds: [...(prev.builds || []), { ...newBuild, id: Date.now().toString() }]
      }));
      setNewBuild({ title: '', description: '', image: '', vehicle_model: '' });
    }
  };

  const handleAddBeforeAfter = () => {
    if (newBeforeAfter.before_image && newBeforeAfter.after_image) {
      setFormData(prev => ({
        ...prev,
        before_after: [...(prev.before_after || []), { ...newBeforeAfter, id: Date.now().toString() }]
      }));
      setNewBeforeAfter({ before_image: '', after_image: '', description: '', performance_gain: '' });
    }
  };

  const handleAddModel = () => {
    if (newModel && !formData.supported_models?.includes(newModel)) {
      setFormData(prev => ({
        ...prev,
        supported_models: [...(prev.supported_models || []), newModel]
      }));
      setNewModel('');
    }
  };

  const handleAddService = () => {
    if (newService && !formData.services?.includes(newService)) {
      setFormData(prev => ({
        ...prev,
        services: [...(prev.services || []), newService]
      }));
      setNewService('');
    }
  };

  return (
    <form onSubmit={(e) => {
      e.preventDefault();
      onSubmit(formData);
    }} className="space-y-6">
      {/* Basic Info */}
      <div className="space-y-4">
        <h3 className="text-sm uppercase tracking-wider text-gray-400">Basic Information</h3>
        <Input
          placeholder="Tuner Name"
          value={formData.name}
          onChange={(e) => setFormData({...formData, name: e.target.value})}
          className="bg-gray-950 border-gray-800 text-white"
          required
        />
        <div className="grid grid-cols-2 gap-4">
          <Select value={formData.location} onValueChange={(value) => setFormData({...formData, location: value})}>
            <SelectTrigger className="bg-gray-950 border-gray-800 text-white">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="bg-black border-gray-800">
              <SelectItem value="USA">USA</SelectItem>
              <SelectItem value="Europe">Europe</SelectItem>
            </SelectContent>
          </Select>
          <Input
            placeholder="Country"
            value={formData.country}
            onChange={(e) => setFormData({...formData, country: e.target.value})}
            className="bg-gray-950 border-gray-800 text-white"
          />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <Input
            placeholder="State/Region"
            value={formData.state_region}
            onChange={(e) => setFormData({...formData, state_region: e.target.value})}
            className="bg-gray-950 border-gray-800 text-white"
          />
          <Input
            placeholder="City"
            value={formData.city}
            onChange={(e) => setFormData({...formData, city: e.target.value})}
            className="bg-gray-950 border-gray-800 text-white"
            required
          />
        </div>
        <Input
          placeholder="Address"
          value={formData.address}
          onChange={(e) => setFormData({...formData, address: e.target.value})}
          className="bg-gray-950 border-gray-800 text-white"
        />
      </div>

      {/* Contact & Links */}
      <div className="space-y-4">
        <h3 className="text-sm uppercase tracking-wider text-gray-400">Contact & Links</h3>
        <Input
          placeholder="Phone"
          value={formData.phone}
          onChange={(e) => setFormData({...formData, phone: e.target.value})}
          className="bg-gray-950 border-gray-800 text-white"
        />
        <Input
          placeholder="Email"
          type="email"
          value={formData.email}
          onChange={(e) => setFormData({...formData, email: e.target.value})}
          className="bg-gray-950 border-gray-800 text-white"
        />
        <Input
          placeholder="Website URL"
          value={formData.website}
          onChange={(e) => setFormData({...formData, website: e.target.value})}
          className="bg-gray-950 border-gray-800 text-white"
        />
        <Input
          placeholder="Shop Image URL"
          value={formData.image}
          onChange={(e) => setFormData({...formData, image: e.target.value})}
          className="bg-gray-950 border-gray-800 text-white"
        />
      </div>

      {/* Description */}
      <div className="space-y-4">
        <h3 className="text-sm uppercase tracking-wider text-gray-400">Description</h3>
        <Textarea
          placeholder="Shop description..."
          value={formData.description}
          onChange={(e) => setFormData({...formData, description: e.target.value})}
          className="bg-gray-950 border-gray-800 text-white"
          rows={4}
        />
      </div>

      {/* Services */}
      <div className="space-y-4">
        <h3 className="text-sm uppercase tracking-wider text-gray-400">Services Offered</h3>
        <div className="flex gap-2">
          <Select value={newService} onValueChange={setNewService}>
            <SelectTrigger className="bg-gray-950 border-gray-800 text-white flex-1">
              <SelectValue placeholder="Select service" />
            </SelectTrigger>
            <SelectContent className="bg-black border-gray-800">
              {SERVICES.map(service => (
                <SelectItem key={service} value={service}>{service}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button type="button" onClick={handleAddService} className="bg-[#0066B1]">Add</Button>
        </div>
        <div className="flex flex-wrap gap-2">
          {(formData.services || []).map(service => (
            <Badge key={service} className="bg-[#0066B1]/20 border border-[#0066B1]">
              {service}
              <button
                type="button"
                onClick={() => setFormData(prev => ({...prev, services: prev.services.filter(s => s !== service)}))}
                className="ml-2 text-xs"
              >
                ×
              </button>
            </Badge>
          ))}
        </div>
      </div>

      {/* Supported Models */}
      <div className="space-y-4">
        <h3 className="text-sm uppercase tracking-wider text-gray-400">Supported Vehicle Models</h3>
        <div className="flex gap-2">
          <Input
            placeholder="e.g., M3 Competition, M440i"
            value={newModel}
            onChange={(e) => setNewModel(e.target.value)}
            className="bg-gray-950 border-gray-800 text-white flex-1"
          />
          <Button type="button" onClick={handleAddModel} className="bg-[#0066B1]">Add</Button>
        </div>
        <div className="flex flex-wrap gap-2">
          {(formData.supported_models || []).map(model => (
            <Badge key={model} variant="outline" className="border-gray-800">
              {model}
              <button
                type="button"
                onClick={() => setFormData(prev => ({...prev, supported_models: prev.supported_models.filter(m => m !== model)}))}
                className="ml-2 text-xs"
              >
                ×
              </button>
            </Badge>
          ))}
        </div>
      </div>

      {/* Featured Builds */}
      <div className="space-y-4">
        <h3 className="text-sm uppercase tracking-wider text-gray-400">Featured Builds</h3>
        <div className="space-y-3 bg-gray-950 border border-gray-900 p-4">
          <Input
            placeholder="Build Title"
            value={newBuild.title}
            onChange={(e) => setNewBuild({...newBuild, title: e.target.value})}
            className="bg-black border-gray-800 text-white"
          />
          <Input
            placeholder="Vehicle Model (e.g., M3 G80)"
            value={newBuild.vehicle_model}
            onChange={(e) => setNewBuild({...newBuild, vehicle_model: e.target.value})}
            className="bg-black border-gray-800 text-white"
          />
          <Input
            placeholder="Image URL"
            value={newBuild.image}
            onChange={(e) => setNewBuild({...newBuild, image: e.target.value})}
            className="bg-black border-gray-800 text-white"
          />
          <Textarea
            placeholder="Build Description"
            value={newBuild.description}
            onChange={(e) => setNewBuild({...newBuild, description: e.target.value})}
            className="bg-black border-gray-800 text-white"
            rows={2}
          />
          <Button type="button" onClick={handleAddBuild} className="w-full bg-[#0066B1]">Add Build</Button>
        </div>
        <div className="space-y-3">
          {(formData.builds || []).map((build, idx) => (
            <div key={build.id} className="bg-gray-950 border border-gray-800 p-3 text-sm">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <p className="font-medium">{build.title}</p>
                  <p className="text-gray-500 text-xs">{build.vehicle_model}</p>
                </div>
                <button
                  type="button"
                  onClick={() => setFormData(prev => ({...prev, builds: prev.builds.filter((_, i) => i !== idx)}))}
                  className="text-red-500"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Before & After Gallery */}
      <div className="space-y-4">
        <h3 className="text-sm uppercase tracking-wider text-gray-400">Before & After Results</h3>
        <div className="space-y-3 bg-gray-950 border border-gray-900 p-4">
          <Input
            placeholder="Before Image URL"
            value={newBeforeAfter.before_image}
            onChange={(e) => setNewBeforeAfter({...newBeforeAfter, before_image: e.target.value})}
            className="bg-black border-gray-800 text-white"
          />
          <Input
            placeholder="After Image URL"
            value={newBeforeAfter.after_image}
            onChange={(e) => setNewBeforeAfter({...newBeforeAfter, after_image: e.target.value})}
            className="bg-black border-gray-800 text-white"
          />
          <Textarea
            placeholder="Description of the work done"
            value={newBeforeAfter.description}
            onChange={(e) => setNewBeforeAfter({...newBeforeAfter, description: e.target.value})}
            className="bg-black border-gray-800 text-white"
            rows={2}
          />
          <Input
            placeholder="Performance Gain (e.g., +85 hp, +120 Nm)"
            value={newBeforeAfter.performance_gain}
            onChange={(e) => setNewBeforeAfter({...newBeforeAfter, performance_gain: e.target.value})}
            className="bg-black border-gray-800 text-white"
          />
          <Button type="button" onClick={handleAddBeforeAfter} className="w-full bg-[#0066B1]">Add Result</Button>
        </div>
        <div className="space-y-3">
          {(formData.before_after || []).map((result, idx) => (
            <div key={result.id} className="bg-gray-950 border border-gray-800 p-3 text-sm">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <p className="text-gray-400">{result.description}</p>
                  <p className="text-[#0066B1] font-medium">{result.performance_gain}</p>
                </div>
                <button
                  type="button"
                  onClick={() => setFormData(prev => ({...prev, before_after: prev.before_after.filter((_, i) => i !== idx)}))}
                  className="text-red-500"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Coordinates */}
      <div className="space-y-4">
        <h3 className="text-sm uppercase tracking-wider text-gray-400">Location Coordinates</h3>
        <div className="grid grid-cols-2 gap-4">
          <Input
            placeholder="Latitude"
            type="number"
            step="0.0001"
            value={formData.coordinates?.lat || ''}
            onChange={(e) => setFormData({...formData, coordinates: {...(formData.coordinates || {}), lat: parseFloat(e.target.value) || 0}})}
            className="bg-gray-950 border-gray-800 text-white"
          />
          <Input
            placeholder="Longitude"
            type="number"
            step="0.0001"
            value={formData.coordinates?.lng || ''}
            onChange={(e) => setFormData({...formData, coordinates: {...(formData.coordinates || {}), lng: parseFloat(e.target.value) || 0}})}
            className="bg-gray-950 border-gray-800 text-white"
          />
        </div>
      </div>

      {/* Certified */}
      <div className="flex items-center gap-3 bg-gray-950 border border-gray-900 p-4">
        <input
          type="checkbox"
          checked={formData.certified}
          onChange={(e) => setFormData({...formData, certified: e.target.checked})}
          className="w-4 h-4"
        />
        <label className="text-sm">Mark as MFlight Certified</label>
      </div>

      <Button type="submit" className="w-full bg-[#E22718] hover:bg-[#C01F12]">
        {tuner ? 'Update Tuner' : 'Create Tuner'}
      </Button>
    </form>
  );
}