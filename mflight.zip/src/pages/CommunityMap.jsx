import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { MapContainer, TileLayer, CircleMarker, Popup, useMap } from 'react-leaflet';
import { Loader2, Users, MapPin } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import 'leaflet/dist/leaflet.css';

// Heat intensity calculation
function getHeatIntensity(locations, point, radius = 500) {
  let intensity = 0;
  locations.forEach(loc => {
    const distance = Math.sqrt(
      Math.pow(loc.lat - point.lat, 2) + Math.pow(loc.lng - point.lng, 2)
    );
    if (distance < radius) {
      intensity += (1 - distance / radius);
    }
  });
  return intensity;
}

export default function CommunityMap() {
  const [memberCount, setMemberCount] = useState(0);

  const { data: users = [], isLoading } = useQuery({
    queryKey: ['all-users-with-location'],
    queryFn: () => base44.entities.User.list(),
  });

  // Generate sample locations for demo (in real app, these would come from user data)
  const generateMemberLocations = () => {
    const locations = [];
    // Major cities with BMW enthusiast communities
    const hotspots = [
      { lat: 40.7128, lng: -74.0060, count: 15 }, // NYC
      { lat: 34.0522, lng: -118.2437, count: 20 }, // LA
      { lat: 41.8781, lng: -87.6298, count: 12 }, // Chicago
      { lat: 29.7604, lng: -95.3698, count: 10 }, // Houston
      { lat: 33.4484, lng: -112.0740, count: 8 }, // Phoenix
      { lat: 51.5074, lng: -0.1278, count: 18 }, // London
      { lat: 48.8566, lng: 2.3522, count: 15 }, // Paris
      { lat: 52.5200, lng: 13.4050, count: 22 }, // Berlin
      { lat: 48.1351, lng: 11.5820, count: 25 }, // Munich (BMW HQ)
      { lat: 35.6762, lng: 139.6503, count: 14 }, // Tokyo
      { lat: 37.7749, lng: -122.4194, count: 16 }, // SF
      { lat: 47.6062, lng: -122.3321, count: 9 }, // Seattle
      { lat: 25.7617, lng: -80.1918, count: 11 }, // Miami
    ];

    hotspots.forEach(spot => {
      for (let i = 0; i < spot.count; i++) {
        locations.push({
          lat: spot.lat + (Math.random() - 0.5) * 2,
          lng: spot.lng + (Math.random() - 0.5) * 2,
        });
      }
    });
    return locations;
  };

  const memberLocations = generateMemberLocations();

  useEffect(() => {
    setMemberCount(memberLocations.length);
  }, []);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-black">
        <Loader2 className="w-8 h-8 animate-spin text-[#0066B1]" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white pb-20">
      {/* Header */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-7xl mx-auto px-6 py-12"
      >
        <div className="flex items-center gap-3 mb-4">
          <MapPin className="w-8 h-8 text-[#0066B1]" />
          <h1 className="text-4xl font-light uppercase tracking-wider">Global Community</h1>
        </div>
        <p className="text-gray-500 text-sm uppercase tracking-wider mb-8">
          {memberCount} members worldwide
        </p>

        {/* Stats Bar - Optimized touch targets */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-gray-950 border border-gray-900 p-5 min-h-[80px] flex flex-col justify-center">
            <div className="text-2xl font-light text-[#0066B1] mb-1">{memberCount}</div>
            <p className="text-xs text-gray-500 uppercase tracking-wider">Total Members</p>
          </div>
          <div className="bg-gray-950 border border-gray-900 p-5 min-h-[80px] flex flex-col justify-center">
            <div className="text-2xl font-light text-[#E22718] mb-1">13</div>
            <p className="text-xs text-gray-500 uppercase tracking-wider">Active Cities</p>
          </div>
          <div className="bg-gray-950 border border-gray-900 p-5 min-h-[80px] flex flex-col justify-center">
            <div className="text-2xl font-light text-[#00C853] mb-1">2</div>
            <p className="text-xs text-gray-500 uppercase tracking-wider">Continents</p>
          </div>
          <div className="bg-gray-950 border border-gray-900 p-5 min-h-[80px] flex flex-col justify-center">
            <div className="text-2xl font-light text-[#FFB300] mb-1">25</div>
            <p className="text-xs text-gray-500 uppercase tracking-wider">In Munich</p>
          </div>
        </div>
      </motion.div>

      {/* Map */}
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-gray-950 border border-gray-900 overflow-hidden"
          style={{ height: '600px' }}
        >
          <MapContainer
            center={[30, 0]}
            zoom={2}
            style={{ height: '100%', width: '100%', background: '#000' }}
            className="z-0"
            minZoom={2}
            maxBounds={[[-90, -180], [90, 180]]}
          >
            <TileLayer
              url="https://{s}.basemaps.cartocdn.com/dark_nolabels/{z}/{x}/{y}{r}.png"
              attribution='&copy; OpenStreetMap contributors &copy; CARTO'
            />
            
            {/* Heat markers */}
            {memberLocations.map((loc, idx) => {
              const intensity = getHeatIntensity(memberLocations, loc, 5);
              const size = Math.max(4, Math.min(15, 4 + intensity * 3));
              const opacity = Math.max(0.3, Math.min(0.9, 0.3 + intensity * 0.2));
              
              return (
                <CircleMarker
                  key={idx}
                  center={[loc.lat, loc.lng]}
                  radius={size}
                  fillColor={intensity > 2 ? "#E22718" : intensity > 1 ? "#FFB300" : "#0066B1"}
                  color="transparent"
                  weight={0}
                  fillOpacity={opacity}
                />
              );
            })}
          </MapContainer>
        </motion.div>

        {/* Legend */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mt-6 bg-gray-950 border border-gray-900 p-6"
        >
          <h3 className="text-sm uppercase tracking-wider text-gray-400 mb-4">Heat Map Legend</h3>
          <div className="flex flex-wrap gap-6">
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded-full bg-[#0066B1]" />
              <span className="text-xs text-gray-500 uppercase tracking-wider">Low Density</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded-full bg-[#FFB300]" />
              <span className="text-xs text-gray-500 uppercase tracking-wider">Medium Density</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded-full bg-[#E22718]" />
              <span className="text-xs text-gray-500 uppercase tracking-wider">High Density</span>
            </div>
          </div>
        </motion.div>
      </div>

      <style>{`
        .leaflet-container {
          background: #000 !important;
          font-family: inherit;
        }
        .leaflet-control-zoom {
          border: 1px solid #1f2937 !important;
          background: #000 !important;
        }
        .leaflet-control-zoom a {
          background: #0f0f0f !important;
          color: #fff !important;
          border-bottom: 1px solid #1f2937 !important;
        }
        .leaflet-control-zoom a:hover {
          background: #1f2937 !important;
        }
        .leaflet-bar {
          box-shadow: none !important;
        }
      `}</style>
    </div>
  );
}