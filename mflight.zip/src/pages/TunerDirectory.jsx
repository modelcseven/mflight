import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { Search, MapPin, Star, Phone, Mail, Globe, Filter, Navigation, Award, Wrench } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';

export default function TunerDirectory() {
  const [user, setUser] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRegion, setSelectedRegion] = useState('all');
  const [selectedService, setSelectedService] = useState('all');
  const [selectedTuner, setSelectedTuner] = useState(null);
  const [reviewDialogOpen, setReviewDialogOpen] = useState(false);

  const queryClient = useQueryClient();

  useEffect(() => {
    const loadUser = async () => {
      const currentUser = await base44.auth.me().catch(() => null);
      setUser(currentUser);
    };
    loadUser();
  }, []);

  const { data: tuners = [], isLoading } = useQuery({
    queryKey: ['tuners'],
    queryFn: () => base44.entities.Tuner.list('-average_rating', 100),
  });

  const { data: reviews = [] } = useQuery({
    queryKey: ['tuner-reviews', selectedTuner?.id],
    queryFn: () => base44.entities.TunerReview.filter({ tuner_id: selectedTuner?.id }),
    enabled: !!selectedTuner?.id,
  });

  const filteredTuners = tuners.filter(tuner => {
    const matchesSearch = tuner.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          tuner.city.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          tuner.state_region?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesRegion = selectedRegion === 'all' || tuner.location === selectedRegion;
    const matchesService = selectedService === 'all' || tuner.services.includes(selectedService);
    return matchesSearch && matchesRegion && matchesService;
  });

  const openInGoogleMaps = (tuner) => {
    if (tuner.coordinates) {
      window.open(`https://www.google.com/maps/search/?api=1&query=${tuner.coordinates.lat},${tuner.coordinates.lng}`, '_blank');
    }
  };

  const openInAppleMaps = (tuner) => {
    if (tuner.coordinates) {
      window.open(`http://maps.apple.com/?q=${tuner.name}&ll=${tuner.coordinates.lat},${tuner.coordinates.lng}`, '_blank');
    }
  };

  return (
    <div className="min-h-screen bg-black text-white pb-20">
      <div className="max-w-7xl mx-auto px-6 py-12">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-12"
        >
          <div className="flex items-center gap-3 mb-4">
            <Wrench className="w-8 h-8 text-[#0066B1]" />
            <h1 className="text-4xl font-light uppercase tracking-wider">Tuner Directory</h1>
          </div>
          <p className="text-gray-500 text-sm uppercase tracking-wider">
            Find certified BMW performance specialists
          </p>
        </motion.div>

        {/* Search & Filters */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-gray-950 border border-gray-900 p-6 mb-8"
        >
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="md:col-span-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                <Input
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search by name, city, or region..."
                  className="bg-black border-gray-800 text-white pl-10"
                />
              </div>
            </div>
            <Select value={selectedRegion} onValueChange={setSelectedRegion}>
              <SelectTrigger className="bg-black border-gray-800 text-white">
                <SelectValue placeholder="Region" />
              </SelectTrigger>
              <SelectContent className="bg-black border-gray-800">
                <SelectItem value="all">All Regions</SelectItem>
                <SelectItem value="USA" className="text-white">USA</SelectItem>
                <SelectItem value="Europe" className="text-white">Europe</SelectItem>
              </SelectContent>
            </Select>
            <Select value={selectedService} onValueChange={setSelectedService}>
              <SelectTrigger className="bg-black border-gray-800 text-white">
                <SelectValue placeholder="Service" />
              </SelectTrigger>
              <SelectContent className="bg-black border-gray-800">
                <SelectItem value="all">All Services</SelectItem>
                <SelectItem value="ECU Tuning">ECU Tuning</SelectItem>
                <SelectItem value="TCU Tuning">TCU Tuning</SelectItem>
                <SelectItem value="Suspension Upgrades">Suspension</SelectItem>
                <SelectItem value="Engine Builds">Engine Builds</SelectItem>
                <SelectItem value="Turbo Upgrades">Turbo Upgrades</SelectItem>
                <SelectItem value="Exhaust Systems">Exhaust</SelectItem>
                <SelectItem value="Brake Upgrades">Brakes</SelectItem>
                <SelectItem value="Dyno Testing">Dyno Testing</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </motion.div>

        {/* Results */}
        <div className="mb-6">
          <p className="text-sm text-gray-500 uppercase tracking-wider">
            {filteredTuners.length} tuners found
          </p>
        </div>

        {/* Tuner Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTuners.map((tuner, idx) => (
            <motion.div
              key={tuner.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.05 }}
              className="bg-gray-950 border border-gray-900 overflow-hidden hover:border-[#0066B1] transition-colors group"
            >
              {/* Image */}
              <div className="relative h-48 overflow-hidden bg-gray-900">
                {tuner.image && (
                  <img
                    src={tuner.image}
                    alt={tuner.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                )}
                {tuner.certified && (
                  <div className="absolute top-4 right-4 bg-[#0066B1] px-3 py-1 flex items-center gap-2">
                    <Award className="w-3 h-3" />
                    <span className="text-xs uppercase tracking-wider">Certified</span>
                  </div>
                )}
              </div>

              <div className="p-6">
                {/* Name & Rating */}
                <div className="mb-4">
                  <h3 className="text-lg font-light mb-2">{tuner.name}</h3>
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-1">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-4 h-4 ${
                            i < Math.floor(tuner.average_rating)
                              ? 'fill-[#E22718] text-[#E22718]'
                              : 'text-gray-700'
                          }`}
                        />
                      ))}
                    </div>
                    <span className="text-sm text-gray-500">
                      {tuner.average_rating.toFixed(1)} ({tuner.total_reviews})
                    </span>
                  </div>
                </div>

                {/* Location */}
                <div className="flex items-center gap-2 text-sm text-gray-500 mb-4">
                  <MapPin className="w-4 h-4" />
                  <span>{tuner.city}, {tuner.state_region || tuner.country}</span>
                </div>

                {/* Services */}
                <div className="mb-4">
                  <div className="flex flex-wrap gap-2">
                    {tuner.services.slice(0, 3).map(service => (
                      <Badge key={service} variant="outline" className="border-gray-800 text-gray-400 text-xs">
                        {service}
                      </Badge>
                    ))}
                    {tuner.services.length > 3 && (
                      <Badge variant="outline" className="border-gray-800 text-gray-400 text-xs">
                        +{tuner.services.length - 3} more
                      </Badge>
                    )}
                  </div>
                </div>

                {/* Contact Actions */}
                <div className="space-y-2">
                  <Dialog open={selectedTuner?.id === tuner.id && !reviewDialogOpen} onOpenChange={(open) => !open && setSelectedTuner(null)}>
                    <DialogTrigger asChild>
                      <Button
                        onClick={() => setSelectedTuner(tuner)}
                        className="w-full bg-[#0066B1] hover:bg-[#0055A0] text-white"
                      >
                        View Details
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="bg-black border-gray-900 text-white max-w-2xl max-h-[90vh] overflow-y-auto">
                      <DialogHeader>
                        <DialogTitle className="text-2xl font-light">{tuner.name}</DialogTitle>
                      </DialogHeader>
                      
                      <div className="space-y-6">
                        {/* Rating */}
                        <div className="flex items-center gap-4">
                          <div className="flex items-center gap-1">
                            {[...Array(5)].map((_, i) => (
                              <Star
                                key={i}
                                className={`w-5 h-5 ${
                                  i < Math.floor(tuner.average_rating)
                                    ? 'fill-[#E22718] text-[#E22718]'
                                    : 'text-gray-700'
                                }`}
                              />
                            ))}
                          </div>
                          <span className="text-lg">{tuner.average_rating.toFixed(1)}</span>
                          <span className="text-gray-500">({tuner.total_reviews} reviews)</span>
                        </div>

                        {/* Description */}
                        {tuner.description && (
                          <div>
                            <h4 className="text-sm uppercase tracking-wider text-gray-400 mb-2">About</h4>
                            <p className="text-sm text-gray-300">{tuner.description}</p>
                          </div>
                        )}

                        {/* Services */}
                         <div>
                           <h4 className="text-sm uppercase tracking-wider text-gray-400 mb-3">Services Offered</h4>
                           <div className="flex flex-wrap gap-2">
                             {tuner.services.map(service => (
                               <Badge key={service} className="bg-[#0066B1]/20 border-[#0066B1] text-white">
                                 {service}
                               </Badge>
                             ))}
                           </div>
                         </div>

                         {/* Supported Models */}
                         {(tuner.supported_models?.length > 0 || tuner.specialization?.length > 0) && (
                           <div>
                             <h4 className="text-sm uppercase tracking-wider text-gray-400 mb-3">Supported Vehicle Models</h4>
                             <div className="flex flex-wrap gap-2">
                               {(tuner.supported_models || tuner.specialization || []).map(model => (
                                 <Badge key={model} variant="outline" className="border-gray-800 text-gray-300">
                                   {model}
                                 </Badge>
                               ))}
                             </div>
                           </div>
                         )}

                         {/* Tuner's Builds */}
                         {tuner.builds?.length > 0 && (
                           <div>
                             <h4 className="text-sm uppercase tracking-wider text-gray-400 mb-3">Featured Builds</h4>
                             <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                               {tuner.builds.map(build => (
                                 <div key={build.id} className="bg-gray-900 border border-gray-800 overflow-hidden">
                                   {build.image && (
                                     <img 
                                       src={build.image} 
                                       alt={build.title} 
                                       className="w-full h-40 object-cover"
                                     />
                                   )}
                                   <div className="p-3">
                                     <h5 className="font-medium text-sm mb-1">{build.title}</h5>
                                     {build.vehicle_model && (
                                       <p className="text-xs text-gray-500 mb-2">{build.vehicle_model}</p>
                                     )}
                                     {build.description && (
                                       <p className="text-xs text-gray-400 line-clamp-2">{build.description}</p>
                                     )}
                                   </div>
                                 </div>
                               ))}
                             </div>
                           </div>
                         )}

                         {/* Before & After Gallery */}
                         {tuner.before_after?.length > 0 && (
                           <div>
                             <h4 className="text-sm uppercase tracking-wider text-gray-400 mb-3">Performance Results</h4>
                             <div className="space-y-4">
                               {tuner.before_after.map(result => (
                                 <div key={result.id} className="bg-gray-900 border border-gray-800 p-4">
                                   <div className="grid grid-cols-2 gap-3 mb-3">
                                     {result.before_image && (
                                       <div>
                                         <p className="text-xs text-gray-500 mb-1 font-medium">Before</p>
                                         <img 
                                           src={result.before_image} 
                                           alt="Before" 
                                           className="w-full h-32 object-cover border border-gray-800"
                                         />
                                       </div>
                                     )}
                                     {result.after_image && (
                                       <div>
                                         <p className="text-xs text-gray-500 mb-1 font-medium">After</p>
                                         <img 
                                           src={result.after_image} 
                                           alt="After" 
                                           className="w-full h-32 object-cover border border-gray-800"
                                         />
                                       </div>
                                     )}
                                   </div>
                                   {result.description && (
                                     <p className="text-sm text-gray-300 mb-2">{result.description}</p>
                                   )}
                                   {result.performance_gain && (
                                     <div className="bg-[#0066B1]/10 border border-[#0066B1]/20 px-3 py-2 text-sm text-[#0066B1]">
                                       {result.performance_gain}
                                     </div>
                                   )}
                                 </div>
                               ))}
                             </div>
                           </div>
                         )}

                        {/* Contact Info */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {tuner.phone && (
                            <a href={`tel:${tuner.phone}`} className="flex items-center gap-2 text-sm text-gray-400 hover:text-white">
                              <Phone className="w-4 h-4" />
                              {tuner.phone}
                            </a>
                          )}
                          {tuner.email && (
                            <a href={`mailto:${tuner.email}`} className="flex items-center gap-2 text-sm text-gray-400 hover:text-white">
                              <Mail className="w-4 h-4" />
                              {tuner.email}
                            </a>
                          )}
                          {tuner.website && (
                            <a href={tuner.website} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-sm text-gray-400 hover:text-white">
                              <Globe className="w-4 h-4" />
                              Visit Website
                            </a>
                          )}
                        </div>

                        {/* Navigation */}
                        {tuner.coordinates && (
                          <div className="flex gap-2">
                            <Button
                              onClick={() => openInGoogleMaps(tuner)}
                              className="flex-1 bg-gray-900 hover:bg-gray-800"
                            >
                              <Navigation className="w-4 h-4 mr-2" />
                              Google Maps
                            </Button>
                            <Button
                              onClick={() => openInAppleMaps(tuner)}
                              className="flex-1 bg-gray-900 hover:bg-gray-800"
                            >
                              <Navigation className="w-4 h-4 mr-2" />
                              Apple Maps
                            </Button>
                          </div>
                        )}

                        {/* Reviews */}
                        <div>
                          <div className="flex items-center justify-between mb-4">
                            <h4 className="text-sm uppercase tracking-wider text-gray-400">Reviews</h4>
                            {user && (
                              <Button
                                onClick={() => {
                                  setReviewDialogOpen(true);
                                }}
                                size="sm"
                                className="bg-[#E22718] hover:bg-[#C01F12]"
                              >
                                Write Review
                              </Button>
                            )}
                          </div>
                          
                          <div className="space-y-4">
                            {reviews.length === 0 && (
                              <p className="text-sm text-gray-500 text-center py-8">No reviews yet</p>
                            )}
                            {reviews.map(review => (
                              <div key={review.id} className="bg-gray-950 border border-gray-900 p-4">
                                <div className="flex items-start gap-3 mb-3">
                                  <img
                                    src={review.user_avatar || `https://ui-avatars.com/api/?name=${review.user_name}`}
                                    alt={review.user_name}
                                    className="w-10 h-10 rounded-full"
                                  />
                                  <div className="flex-1">
                                    <div className="flex items-center justify-between mb-1">
                                      <h5 className="font-medium">{review.user_name}</h5>
                                      <div className="flex items-center gap-1">
                                        {[...Array(5)].map((_, i) => (
                                          <Star
                                            key={i}
                                            className={`w-3 h-3 ${
                                              i < review.rating
                                                ? 'fill-[#E22718] text-[#E22718]'
                                                : 'text-gray-700'
                                            }`}
                                          />
                                        ))}
                                      </div>
                                    </div>
                                    <p className="text-xs text-gray-500 mb-2">{review.service_type} • {review.vehicle}</p>
                                    <p className="text-sm text-gray-300">{review.review_text}</p>
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    </DialogContent>
                  </Dialog>

                  <div className="flex gap-2">
                    {tuner.phone && (
                      <Button
                        onClick={() => window.location.href = `tel:${tuner.phone}`}
                        variant="outline"
                        className="flex-1 border-gray-800 text-gray-400 hover:text-white hover:bg-gray-900"
                      >
                        <Phone className="w-4 h-4" />
                      </Button>
                    )}
                    {tuner.coordinates && (
                      <Button
                        onClick={() => openInGoogleMaps(tuner)}
                        variant="outline"
                        className="flex-1 border-gray-800 text-gray-400 hover:text-white hover:bg-gray-900"
                      >
                        <Navigation className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {filteredTuners.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500 text-sm uppercase tracking-wider">No tuners found</p>
          </div>
        )}

        {/* Review Dialog */}
        <ReviewDialog
          open={reviewDialogOpen}
          onOpenChange={setReviewDialogOpen}
          tuner={selectedTuner}
          user={user}
          onSuccess={() => {
            setReviewDialogOpen(false);
            queryClient.invalidateQueries({ queryKey: ['tuner-reviews'] });
          }}
        />
      </div>
    </div>
  );
}

function ReviewDialog({ open, onOpenChange, tuner, user, onSuccess }) {
  const [rating, setRating] = useState(5);
  const [serviceType, setServiceType] = useState('');
  const [vehicle, setVehicle] = useState('');
  const [reviewText, setReviewText] = useState('');

  const createReviewMutation = useMutation({
    mutationFn: (reviewData) => base44.entities.TunerReview.create(reviewData),
    onSuccess: async () => {
      // Update tuner rating
      const reviews = await base44.entities.TunerReview.filter({ tuner_id: tuner.id });
      const avgRating = reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length;
      await base44.entities.Tuner.update(tuner.id, {
        average_rating: avgRating,
        total_reviews: reviews.length
      });
      onSuccess();
    }
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!tuner || !user) return;

    await createReviewMutation.mutateAsync({
      tuner_id: tuner.id,
      user_email: user.email,
      user_name: user.full_name,
      user_avatar: user.avatar,
      rating,
      service_type: serviceType,
      vehicle,
      review_text: reviewText
    });

    setRating(5);
    setServiceType('');
    setVehicle('');
    setReviewText('');
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-black border-gray-900 text-white">
        <DialogHeader>
          <DialogTitle>Write a Review</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-sm text-gray-400 mb-2 block">Rating</label>
            <div className="flex gap-2">
              {[1, 2, 3, 4, 5].map(star => (
                <button
                  key={star}
                  type="button"
                  onClick={() => setRating(star)}
                >
                  <Star
                    className={`w-8 h-8 cursor-pointer ${
                      star <= rating ? 'fill-[#E22718] text-[#E22718]' : 'text-gray-700'
                    }`}
                  />
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-sm text-gray-400 mb-2 block">Service Received</label>
            <Input
              value={serviceType}
              onChange={(e) => setServiceType(e.target.value)}
              placeholder="e.g., ECU Tuning"
              className="bg-gray-950 border-gray-800 text-white"
              required
            />
          </div>

          <div>
            <label className="text-sm text-gray-400 mb-2 block">Your Vehicle</label>
            <Input
              value={vehicle}
              onChange={(e) => setVehicle(e.target.value)}
              placeholder="e.g., 2023 M3 Competition"
              className="bg-gray-950 border-gray-800 text-white"
              required
            />
          </div>

          <div>
            <label className="text-sm text-gray-400 mb-2 block">Review</label>
            <Textarea
              value={reviewText}
              onChange={(e) => setReviewText(e.target.value)}
              placeholder="Share your experience..."
              className="bg-gray-950 border-gray-800 text-white h-32"
              required
            />
          </div>

          <Button type="submit" className="w-full bg-[#E22718] hover:bg-[#C01F12]">
            Submit Review
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}