import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Search, UserPlus, UserCheck, UserX, MoreHorizontal } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Card } from '@/components/ui/card';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion, AnimatePresence } from 'framer-motion';

function FriendCard({ user, type, onAccept, onReject, onAddFriend, isPending }) {
  const avatar = user.avatar || `https://ui-avatars.com/api/?name=${user.full_name}&background=random`;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
    >
      <Card className="overflow-hidden">
        <Link to={createPageUrl(`Profile?email=${user.email}`)}>
          <img
            src={avatar}
            alt={user.full_name}
            className="w-full aspect-square object-cover hover:opacity-95 transition-opacity"
          />
        </Link>
        <div className="p-3">
          <Link 
            to={createPageUrl(`Profile?email=${user.email}`)}
            className="font-semibold text-gray-900 hover:underline block truncate"
          >
            {user.full_name}
          </Link>
          
          {type === 'request' && (
            <div className="mt-3 space-y-2">
              <Button 
                onClick={onAccept}
                className="w-full bg-[#1877F2] hover:bg-[#166FE5]"
              >
                Confirm
              </Button>
              <Button 
                onClick={onReject}
                variant="secondary" 
                className="w-full"
              >
                Delete
              </Button>
            </div>
          )}
          
          {type === 'suggestion' && (
            <div className="mt-3">
              {isPending ? (
                <Button variant="secondary" className="w-full" disabled>
                  Request Sent
                </Button>
              ) : (
                <Button 
                  onClick={onAddFriend}
                  className="w-full bg-[#E7F3FF] text-[#1877F2] hover:bg-[#D8E8F8]"
                >
                  <UserPlus className="w-4 h-4 mr-2" />
                  Add Friend
                </Button>
              )}
            </div>
          )}
          
          {type === 'friend' && (
            <div className="mt-3">
              <Link to={createPageUrl(`Messages?to=${user.email}`)}>
                <Button variant="secondary" className="w-full">
                  Message
                </Button>
              </Link>
            </div>
          )}
        </div>
      </Card>
    </motion.div>
  );
}

export default function Friends() {
  const [user, setUser] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [sentRequests, setSentRequests] = useState([]);
  const queryClient = useQueryClient();

  useEffect(() => {
    const loadUser = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    };
    loadUser();
  }, []);

  const { data: incomingRequests = [] } = useQuery({
    queryKey: ['incoming-requests', user?.email],
    queryFn: () => base44.entities.FriendRequest.filter({ 
      to_email: user?.email, 
      status: 'pending' 
    }),
    enabled: !!user?.email,
  });

  const { data: acceptedSent = [] } = useQuery({
    queryKey: ['accepted-sent', user?.email],
    queryFn: () => base44.entities.FriendRequest.filter({ 
      from_email: user?.email, 
      status: 'accepted' 
    }),
    enabled: !!user?.email,
  });

  const { data: acceptedReceived = [] } = useQuery({
    queryKey: ['accepted-received', user?.email],
    queryFn: () => base44.entities.FriendRequest.filter({ 
      to_email: user?.email, 
      status: 'accepted' 
    }),
    enabled: !!user?.email,
  });

  const { data: allUsers = [] } = useQuery({
    queryKey: ['all-users'],
    queryFn: () => base44.entities.User.list(),
    enabled: !!user?.email,
  });

  const { data: myPendingRequests = [] } = useQuery({
    queryKey: ['my-pending-requests', user?.email],
    queryFn: () => base44.entities.FriendRequest.filter({ 
      from_email: user?.email, 
      status: 'pending' 
    }),
    enabled: !!user?.email,
  });

  // Process friend lists
  const friendEmails = [
    ...acceptedSent.map(fr => fr.to_email),
    ...acceptedReceived.map(fr => fr.from_email)
  ];

  const requestUsers = incomingRequests.map(req => ({
    ...allUsers.find(u => u.email === req.from_email),
    requestId: req.id
  })).filter(u => u.email);

  const friends = allUsers.filter(u => friendEmails.includes(u.email));

  const pendingRequestEmails = myPendingRequests.map(r => r.to_email);

  const suggestions = allUsers.filter(u => 
    u.email !== user?.email && 
    !friendEmails.includes(u.email) &&
    !incomingRequests.some(r => r.from_email === u.email)
  );

  const acceptMutation = useMutation({
    mutationFn: async ({ requestId, fromEmail }) => {
      await base44.entities.FriendRequest.update(requestId, { status: 'accepted' });
      await base44.entities.Notification.create({
        user_email: fromEmail,
        type: 'friend_accepted',
        from_name: user.full_name,
        from_avatar: user.avatar,
        message: `${user.full_name} accepted your friend request`,
        read: false
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['incoming-requests'] });
      queryClient.invalidateQueries({ queryKey: ['accepted-sent'] });
      queryClient.invalidateQueries({ queryKey: ['accepted-received'] });
    },
  });

  const rejectMutation = useMutation({
    mutationFn: (requestId) => base44.entities.FriendRequest.update(requestId, { status: 'rejected' }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['incoming-requests'] }),
  });

  const addFriendMutation = useMutation({
    mutationFn: async (toEmail) => {
      await base44.entities.FriendRequest.create({
        from_email: user.email,
        from_name: user.full_name,
        from_avatar: user.avatar,
        to_email: toEmail,
        status: 'pending'
      });
      await base44.entities.Notification.create({
        user_email: toEmail,
        type: 'friend_request',
        from_name: user.full_name,
        from_avatar: user.avatar,
        message: `${user.full_name} sent you a friend request`,
        read: false
      });
      setSentRequests(prev => [...prev, toEmail]);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['my-pending-requests'] });
    },
  });

  const filteredFriends = friends.filter(f => 
    f.full_name?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#1877F2]" />
      </div>
    );
  }

  return (
    <div className="max-w-[1095px] mx-auto p-4">
      <div className="bg-white rounded-xl shadow-sm">
        <div className="p-4 border-b border-gray-100">
          <h1 className="text-2xl font-bold text-gray-900">Friends</h1>
        </div>

        <Tabs defaultValue="requests" className="p-4">
          <TabsList className="bg-gray-100 mb-4">
            <TabsTrigger value="requests" className="data-[state=active]:bg-white">
              Friend Requests
              {requestUsers.length > 0 && (
                <span className="ml-2 bg-red-500 text-white text-xs px-2 py-0.5 rounded-full">
                  {requestUsers.length}
                </span>
              )}
            </TabsTrigger>
            <TabsTrigger value="suggestions" className="data-[state=active]:bg-white">
              Suggestions
            </TabsTrigger>
            <TabsTrigger value="all" className="data-[state=active]:bg-white">
              All Friends
            </TabsTrigger>
          </TabsList>

          <TabsContent value="requests">
            {requestUsers.length > 0 ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
                <AnimatePresence>
                  {requestUsers.map((reqUser) => (
                    <FriendCard
                      key={reqUser.email}
                      user={reqUser}
                      type="request"
                      onAccept={() => acceptMutation.mutate({ requestId: reqUser.requestId, fromEmail: reqUser.email })}
                      onReject={() => rejectMutation.mutate(reqUser.requestId)}
                    />
                  ))}
                </AnimatePresence>
              </div>
            ) : (
              <div className="text-center py-12">
                <UserCheck className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-500">No pending friend requests</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="suggestions">
            {suggestions.length > 0 ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
                {suggestions.map((sugUser) => (
                  <FriendCard
                    key={sugUser.email}
                    user={sugUser}
                    type="suggestion"
                    isPending={pendingRequestEmails.includes(sugUser.email) || sentRequests.includes(sugUser.email)}
                    onAddFriend={() => addFriendMutation.mutate(sugUser.email)}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <UserPlus className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-500">No suggestions at the moment</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="all">
            <div className="mb-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Search friends"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            {filteredFriends.length > 0 ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
                {filteredFriends.map((friend) => (
                  <FriendCard
                    key={friend.email}
                    user={friend}
                    type="friend"
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <UserX className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-500">
                  {searchQuery ? 'No friends found' : 'No friends yet'}
                </p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}