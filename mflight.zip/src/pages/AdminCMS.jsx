import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { FileText, Save, Plus } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export default function AdminCMS() {
  const [user, setUser] = useState(null);
  const [selectedPage, setSelectedPage] = useState('Landing');
  const queryClient = useQueryClient();

  useEffect(() => {
    const loadUser = async () => {
      const currentUser = await base44.auth.me();
      if (!currentUser || currentUser.role !== 'admin') {
        window.location.href = '/';
        return;
      }
      setUser(currentUser);
    };
    loadUser();
  }, []);

  const { data: content = [] } = useQuery({
    queryKey: ['cms-content', selectedPage],
    queryFn: () => base44.entities.CMSContent.filter({ page: selectedPage }),
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.CMSContent.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['cms-content'] }),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.CMSContent.create(data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['cms-content'] }),
  });

  if (!user) return null;

  return (
    <div className="min-h-screen bg-black text-white pb-20">
      <div className="max-w-7xl mx-auto px-6 py-12">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-12">
          <h1 className="text-4xl font-light uppercase tracking-wider mb-2">Content Management</h1>
          <p className="text-gray-500 text-sm uppercase tracking-wider">Edit site content</p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="bg-gray-950 border border-gray-900 p-6">
            <h3 className="text-sm uppercase tracking-wider text-gray-400 mb-4">Pages</h3>
            <div className="space-y-2">
              {['Landing', 'Home', 'Events', 'Marketplace'].map(page => (
                <button
                  key={page}
                  onClick={() => setSelectedPage(page)}
                  className={`w-full text-left px-4 py-2 text-sm ${selectedPage === page ? 'bg-[#0066B1] text-white' : 'text-gray-400 hover:bg-gray-900'}`}
                >
                  {page}
                </button>
              ))}
            </div>
          </div>

          <div className="md:col-span-3 space-y-6">
            {content.map(item => (
              <ContentEditor key={item.id} item={item} onSave={(data) => updateMutation.mutate({ id: item.id, data })} />
            ))}
            <Button onClick={() => createMutation.mutate({ page: selectedPage, section: 'new-section', content: '', last_edited_by: user.email })} className="bg-[#0066B1]">
              <Plus className="w-4 h-4 mr-2" />Add Section
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

function ContentEditor({ item, onSave }) {
  const [content, setContent] = useState(item.content);

  return (
    <div className="bg-gray-950 border border-gray-900 p-6">
      <div className="flex items-center justify-between mb-4">
        <h4 className="text-sm uppercase tracking-wider text-gray-400">{item.section}</h4>
        <Button onClick={() => onSave({ content })} size="sm" className="bg-[#E22718]">
          <Save className="w-4 h-4 mr-2" />Save
        </Button>
      </div>
      <Textarea value={content} onChange={(e) => setContent(e.target.value)} className="bg-black border-gray-800 text-white h-32" />
    </div>
  );
}