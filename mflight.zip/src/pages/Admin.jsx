import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { Users, Activity, ShoppingCart, TrendingUp, Eye, MessageCircle, FileText, Key, Webhook, Search, Save, Plus, Trash2, Copy, Target, Mail, Phone, Badge as BadgeIcon, GripVertical } from 'lucide-react';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';

const COLORS = ['#0066B1', '#E22718', '#00C853', '#FFB300', '#9C27B0'];

export default function Admin() {
  const [user, setUser] = useState(null);
  const [activeTab, setActiveTab] = useState('overview');
  const [theme, setTheme] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('theme') || 'dark';
    }
    return 'dark';
  });

  useEffect(() => {
    const loadUser = async () => {
      const currentUser = await base44.auth.me();
      if (!currentUser || currentUser.role !== 'admin') {
        window.location.href = '/';
        return;
      }
      setUser(currentUser);
    };
    loadUser();
  }, []);

  useEffect(() => {
    const handleStorageChange = () => {
      const newTheme = localStorage.getItem('theme') || 'dark';
      setTheme(newTheme);
    };
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  if (!user) return null;

  const bgColor = theme === 'dark' ? 'bg-black' : 'bg-white';
  const textColor = theme === 'dark' ? 'text-white' : 'text-black';
  const borderColor = theme === 'dark' ? 'border-gray-900' : 'border-gray-200';
  const cardBg = theme === 'dark' ? 'bg-gray-950' : 'bg-gray-50';

  return (
    <div className={`min-h-screen ${bgColor} ${textColor} pb-20`}>
      <div className="max-w-7xl mx-auto px-6 py-12">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
          <h1 className="text-4xl font-light uppercase tracking-wider mb-2">Admin Control Panel</h1>
          <p className="text-gray-500 text-sm uppercase tracking-wider">Manage platform, content & integrations</p>
        </motion.div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className={`bg-transparent border-b ${borderColor} rounded-none flex flex-wrap gap-2 justify-end lg:justify-start`}>
            <TabsTrigger value="overview" className={`${theme === 'dark' ? 'data-[state=active]:bg-white data-[state=active]:text-black' : 'data-[state=active]:bg-black data-[state=active]:text-white'} rounded-none text-xs uppercase tracking-wider px-4 py-3 min-h-[44px]`}>Overview</TabsTrigger>
            <TabsTrigger value="tuners" className={`${theme === 'dark' ? 'data-[state=active]:bg-white data-[state=active]:text-black' : 'data-[state=active]:bg-black data-[state=active]:text-white'} rounded-none text-xs uppercase tracking-wider px-4 py-3 min-h-[44px]`}>Tuners</TabsTrigger>
            <TabsTrigger value="content" className={`${theme === 'dark' ? 'data-[state=active]:bg-white data-[state=active]:text-black' : 'data-[state=active]:bg-black data-[state=active]:text-white'} rounded-none text-xs uppercase tracking-wider px-4 py-3 min-h-[44px]`}>Content</TabsTrigger>
            <TabsTrigger value="analytics" className={`${theme === 'dark' ? 'data-[state=active]:bg-white data-[state=active]:text-black' : 'data-[state=active]:bg-black data-[state=active]:text-white'} rounded-none text-xs uppercase tracking-wider px-4 py-3 min-h-[44px]`}>Analytics</TabsTrigger>
            <TabsTrigger value="users" className={`${theme === 'dark' ? 'data-[state=active]:bg-white data-[state=active]:text-black' : 'data-[state=active]:bg-black data-[state=active]:text-white'} rounded-none text-xs uppercase tracking-wider px-4 py-3 min-h-[44px]`}>Users</TabsTrigger>
            <TabsTrigger value="integrations" className={`${theme === 'dark' ? 'data-[state=active]:bg-white data-[state=active]:text-black' : 'data-[state=active]:bg-black data-[state=active]:text-white'} rounded-none text-xs uppercase tracking-wider px-4 py-3 min-h-[44px]`}>Integrations</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="mt-8"><OverviewTab theme={theme} /></TabsContent>
           <TabsContent value="tuners" className="mt-8"><TunersTab theme={theme} /></TabsContent>
           <TabsContent value="content" className="mt-8"><ContentTab theme={theme} /></TabsContent>
           <TabsContent value="analytics" className="mt-8"><AnalyticsTab theme={theme} /></TabsContent>
           <TabsContent value="users" className="mt-8"><UsersTab theme={theme} /></TabsContent>
           <TabsContent value="integrations" className="mt-8"><IntegrationsTab theme={theme} /></TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

function TunersTab() {
  return <iframe src={`/pages/AdminTuners`} className="w-full h-[80vh] border-none" />;
}

function OverviewTab({ theme }) {
  const [orderedStats, setOrderedStats] = useState([]);
  const [chartOrder, setChartOrder] = useState(['growth', 'activity']);
  const cardBg = theme === 'dark' ? 'bg-gray-950' : 'bg-gray-50';
  const borderColor = theme === 'dark' ? 'border-gray-900' : 'border-gray-200';
  const textSecondary = theme === 'dark' ? 'text-gray-500' : 'text-gray-600';
  const { data: users = [] } = useQuery({ queryKey: ['all-users'], queryFn: () => base44.entities.User.list() });
  const { data: posts = [] } = useQuery({ queryKey: ['all-posts'], queryFn: () => base44.entities.Post.list('-created_date', 100) });
  const { data: listings = [] } = useQuery({ queryKey: ['all-listings'], queryFn: () => base44.entities.MarketplaceListing.list() });
  const { data: analytics = [] } = useQuery({ queryKey: ['analytics'], queryFn: () => base44.entities.SiteAnalytics.list('-date', 30) });

  const stats = [
    { label: 'Total Users', value: users.length, icon: Users, color: '#0066B1' },
    { label: 'Total Posts', value: posts.length, icon: FileText, color: '#E22718' },
    { label: 'Active Listings', value: listings.filter(l => l.status === 'active').length, icon: ShoppingCart, color: '#00C853' },
    { label: 'Total Views', value: analytics.reduce((sum, a) => sum + (a.page_views || 0), 0), icon: Eye, color: '#FFB300' }
  ];

  useEffect(() => {
    setOrderedStats(stats);
  }, [stats]);

  const userGrowth = analytics.slice(0, 14).reverse().map(a => ({
    date: new Date(a.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
    users: a.new_users || 0
  }));

  const activityData = [
    { name: 'Posts', value: posts.length },
    { name: 'Listings', value: listings.length },
    { name: 'Users', value: users.length }
  ];

  const handleStatsDragEnd = (result) => {
    const { source, destination } = result;
    if (!destination || source.index === destination.index) return;
    const items = Array.from(orderedStats);
    const [reorderedItem] = items.splice(source.index, 1);
    items.splice(destination.index, 0, reorderedItem);
    setOrderedStats(items);
  };

  const handleChartsDragEnd = (result) => {
    const { source, destination } = result;
    if (!destination || source.index === destination.index) return;
    const items = Array.from(chartOrder);
    const [reorderedItem] = items.splice(source.index, 1);
    items.splice(destination.index, 0, reorderedItem);
    setChartOrder(items);
  };

  const renderChart = (type) => {
    if (type === 'growth') {
      return (
        <div className="h-full">
          <h3 className="text-sm uppercase tracking-wider text-gray-400 mb-6">User Growth (14 Days)</h3>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={userGrowth}>
              <CartesianGrid strokeDasharray="3 3" stroke="#333" />
              <XAxis dataKey="date" tick={{ fill: '#999' }} />
              <YAxis tick={{ fill: '#999' }} />
              <Tooltip contentStyle={{ backgroundColor: '#000', border: '1px solid #333' }} />
              <Line type="monotone" dataKey="users" stroke="#0066B1" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      );
    }
    return (
      <div className="h-full">
        <h3 className="text-sm uppercase tracking-wider text-gray-400 mb-6">Platform Activity</h3>
        <ResponsiveContainer width="100%" height={250}>
          <PieChart>
            <Pie data={activityData} cx="50%" cy="50%" labelLine={false} outerRadius={80} fill="#8884d8" dataKey="value" label>
              {activityData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip contentStyle={{ backgroundColor: '#000', border: '1px solid #333' }} />
            <Legend />
          </PieChart>
        </ResponsiveContainer>
      </div>
    );
  };

  return (
    <>
      <DragDropContext onDragEnd={handleStatsDragEnd}>
        <Droppable droppableId="stats-list" direction="horizontal">
          {(provided, snapshot) => (
            <div {...provided.droppableProps} ref={provided.innerRef} className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
              {orderedStats.map((stat, idx) => (
                <Draggable key={stat.label} draggableId={stat.label} index={idx}>
                  {(provided, snapshot) => (
                    <motion.div
                      ref={provided.innerRef}
                      {...provided.draggableProps}
                      {...provided.dragHandleProps}
                      initial={{ opacity: 0, y: 20 }} 
                      animate={{ opacity: 1, y: 0 }} 
                      transition={{ delay: idx * 0.1 }}
                      className={`${cardBg} border transition-all ${snapshot.isDragging ? 'border-[#0066B1] shadow-lg shadow-[#0066B1]/20' : borderColor} p-6 cursor-move`}
                    >
                      <div className="flex items-center justify-between mb-4">
                        <stat.icon className="w-8 h-8" style={{ color: stat.color }} />
                        <GripVertical className="w-4 h-4 text-gray-600" />
                      </div>
                      <div className="text-4xl font-light mb-2">{stat.value.toLocaleString()}</div>
                      <div className={`text-xs ${textSecondary} uppercase tracking-wider`}>{stat.label}</div>
                    </motion.div>
                  )}
                </Draggable>
              ))}
              {provided.placeholder}
            </div>
          )}
        </Droppable>
      </DragDropContext>

      <DragDropContext onDragEnd={handleChartsDragEnd}>
        <Droppable droppableId="charts-list" direction="horizontal">
          {(provided, snapshot) => (
            <div {...provided.droppableProps} ref={provided.innerRef} className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {chartOrder.map((chartType, idx) => (
                <Draggable key={chartType} draggableId={chartType} index={idx}>
                  {(provided, snapshot) => (
                    <div
                      ref={provided.innerRef}
                      {...provided.draggableProps}
                      className={`${cardBg} border transition-all ${snapshot.isDragging ? 'border-[#0066B1] shadow-lg shadow-[#0066B1]/20' : borderColor} p-6 cursor-move`}
                    >
                      <div className="flex justify-end mb-2" {...provided.dragHandleProps}>
                        <GripVertical className={`w-4 h-4 ${textSecondary}`} />
                      </div>
                      {renderChart(chartType)}
                    </div>
                  )}
                </Draggable>
              ))}
              {provided.placeholder}
            </div>
          )}
        </Droppable>
      </DragDropContext>
    </>
  );
}

function ContentTab({ theme }) {
  const cardBg = theme === 'dark' ? 'bg-gray-950' : 'bg-gray-50';
  const borderColor = theme === 'dark' ? 'border-gray-900' : 'border-gray-200';
  const inputBg = theme === 'dark' ? 'bg-black' : 'bg-white';
  const inputBorder = theme === 'dark' ? 'border-gray-800' : 'border-gray-300';
  const [selectedPage, setSelectedPage] = useState('Landing');
  const [editingId, setEditingId] = useState(null);
  const [editContent, setEditContent] = useState('');
  const [orderedContent, setOrderedContent] = useState([]);
  const queryClient = useQueryClient();

  const { data: content = [] } = useQuery({
    queryKey: ['cms-content', selectedPage],
    queryFn: () => base44.entities.CMSContent.filter({ page: selectedPage }),
  });

  useEffect(() => {
    setOrderedContent(content);
  }, [content]);

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.CMSContent.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['cms-content'] });
      setEditingId(null);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.CMSContent.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['cms-content'] }),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.CMSContent.create(data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['cms-content'] }),
  });

  const handleSave = (id) => {
    updateMutation.mutate({ id, data: { content: editContent } });
  };

  const handleDragEnd = (result) => {
    const { source, destination } = result;
    if (!destination) return;
    if (source.index === destination.index) return;

    const items = Array.from(orderedContent);
    const [reorderedItem] = items.splice(source.index, 1);
    items.splice(destination.index, 0, reorderedItem);
    setOrderedContent(items);
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
      <div className="bg-gray-950 border border-gray-900 p-6 h-fit">
        <h3 className="text-sm uppercase tracking-wider text-gray-400 mb-4">Pages</h3>
        <div className="space-y-2 mb-6">
          {['Landing', 'Home', 'Events', 'Marketplace'].map(page => (
            <button key={page} onClick={() => setSelectedPage(page)} className={`w-full text-left px-4 py-2 text-sm cursor-pointer transition-colors ${selectedPage === page ? 'bg-[#0066B1] text-white' : 'text-gray-400 hover:bg-gray-900'}`}>
              {page}
            </button>
          ))}
        </div>
        <Button onClick={() => createMutation.mutate({ page: selectedPage, section: `section-${Date.now()}`, content: '', content_type: 'text', published: true })} className="bg-[#0066B1] w-full cursor-pointer">
          <Plus className="w-4 h-4 mr-2" />Add Section
        </Button>
      </div>

      <div className="md:col-span-3">
        {orderedContent.length === 0 ? (
          <div className="bg-gray-950 border border-gray-900 p-12 text-center">
            <p className="text-gray-500 text-sm uppercase tracking-wider">No content for this page yet</p>
          </div>
        ) : (
          <DragDropContext onDragEnd={handleDragEnd}>
            <Droppable droppableId="content-list">
              {(provided, snapshot) => (
                <div {...provided.droppableProps} ref={provided.innerRef} className="space-y-6">
                  {orderedContent.map((item, index) => (
                    <Draggable key={item.id} draggableId={item.id} index={index}>
                      {(provided, snapshot) => (
                        <div
                          ref={provided.innerRef}
                          {...provided.draggableProps}
                          className={`${cardBg} border transition-all ${snapshot.isDragging ? 'border-[#0066B1] shadow-lg shadow-[#0066B1]/20' : borderColor} p-6`}
                        >
                          <div className="flex items-center justify-between mb-4">
                            <div className="flex-1 flex items-center gap-3">
                              <div {...provided.dragHandleProps} className="cursor-grab active:cursor-grabbing">
                                <GripVertical className="w-4 h-4 text-gray-600" />
                              </div>
                              <div>
                                <h4 className="text-sm uppercase tracking-wider text-gray-400 mb-1">{item.section}</h4>
                                <p className="text-xs text-gray-600">Type: {item.content_type} • Last edited: {item.last_edited_by}</p>
                              </div>
                            </div>
                            <div className="flex gap-2">
                              {editingId !== item.id && (
                                <Button onClick={() => { setEditingId(item.id); setEditContent(item.content); }} size="sm" className="bg-[#0066B1] cursor-pointer">
                                  Edit
                                </Button>
                              )}
                              <Button onClick={() => deleteMutation.mutate(item.id)} size="sm" variant="outline" className="border-gray-800 text-red-500 cursor-pointer hover:bg-red-950">
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </div>

                          {editingId === item.id ? (
                            <div className="space-y-4">
                              {item.content_type === 'image' ? (
                                <>
                                  {item.content && <img src={item.content} alt={item.section} className="w-full max-h-64 object-cover rounded mb-4" />}
                                  <Input placeholder="Image URL" value={editContent} onChange={(e) => setEditContent(e.target.value)} className="bg-black border-gray-800 text-white" />
                                </>
                              ) : (
                                <Textarea value={editContent} onChange={(e) => setEditContent(e.target.value)} className="bg-black border-gray-800 text-white h-40" />
                              )}
                              <div className="flex gap-2">
                                <Button onClick={() => handleSave(item.id)} size="sm" className="bg-[#E22718] flex-1 cursor-pointer">
                                  <Save className="w-4 h-4 mr-2" />Save
                                </Button>
                                <Button onClick={() => setEditingId(null)} size="sm" variant="outline" className="border-gray-800 flex-1 cursor-pointer">
                                  Cancel
                                </Button>
                              </div>
                            </div>
                          ) : (
                            <div>
                              {item.content_type === 'image' && item.content ? (
                                <img src={item.content} alt={item.section} className="w-full max-h-64 object-cover rounded" />
                              ) : (
                                <p className="text-gray-300 text-sm whitespace-pre-wrap">{item.content}</p>
                              )}
                            </div>
                          )}
                        </div>
                      )}
                    </Draggable>
                  ))}
                  {provided.placeholder}
                </div>
              )}
            </Droppable>
          </DragDropContext>
        )}
      </div>
    </div>
  );
}

function AnalyticsTab({ theme }) {
  const cardBg = theme === 'dark' ? 'bg-gray-950' : 'bg-gray-50';
  const borderColor = theme === 'dark' ? 'border-gray-900' : 'border-gray-200';
  const textSecondary = theme === 'dark' ? 'text-gray-500' : 'text-gray-600';
  const { data: analytics = [] } = useQuery({
    queryKey: ['marketing-analytics'],
    queryFn: () => base44.entities.SiteAnalytics.list('-date', 30),
  });

  const trafficData = analytics.slice(0, 14).reverse().map(a => ({
    date: new Date(a.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
    views: a.page_views || 0,
    users: a.unique_visitors || 0
  }));

  const conversionData = analytics.slice(0, 7).reverse().map(a => ({
    date: new Date(a.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
    registrations: a.event_registrations || 0,
    listings: a.marketplace_listings || 0
  }));

  const totalViews = analytics.reduce((sum, a) => sum + (a.page_views || 0), 0);
  const totalNewUsers = analytics.reduce((sum, a) => sum + (a.new_users || 0), 0);
  const totalVisitors = analytics.reduce((sum, a) => sum + (a.unique_visitors || 0), 0);
  const conversionRate = ((totalNewUsers / Math.max(totalVisitors, 1)) * 100).toFixed(1);

  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className={`${cardBg} border ${borderColor} p-6`}>
          <TrendingUp className="w-8 h-8 text-[#0066B1] mb-3" />
          <div className="text-3xl font-light mb-2">{totalViews.toLocaleString()}</div>
          <p className={`text-xs ${textSecondary} uppercase tracking-wider`}>Total Views</p>
        </div>
        <div className={`${cardBg} border ${borderColor} p-6`}>
          <Users className="w-8 h-8 text-[#E22718] mb-3" />
          <div className="text-3xl font-light mb-2">{totalNewUsers}</div>
          <p className={`text-xs ${textSecondary} uppercase tracking-wider`}>New Users</p>
        </div>
        <div className={`${cardBg} border ${borderColor} p-6`}>
          <Eye className="w-8 h-8 text-[#00C853] mb-3" />
          <div className="text-3xl font-light mb-2">{totalVisitors}</div>
          <p className={`text-xs ${textSecondary} uppercase tracking-wider`}>Unique Visitors</p>
        </div>
        <div className={`${cardBg} border ${borderColor} p-6`}>
          <Target className="w-8 h-8 text-[#FFB300] mb-3" />
          <div className="text-3xl font-light mb-2">{conversionRate}%</div>
          <p className={`text-xs ${textSecondary} uppercase tracking-wider`}>Conversion Rate</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className={`${cardBg} border ${borderColor} p-6`}>
          <h3 className="text-sm uppercase tracking-wider text-gray-400 mb-6">Traffic Overview</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={trafficData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#333" />
              <XAxis dataKey="date" tick={{ fill: '#999' }} />
              <YAxis tick={{ fill: '#999' }} />
              <Tooltip contentStyle={{ backgroundColor: '#000', border: '1px solid #333' }} />
              <Legend />
              <Line type="monotone" dataKey="views" stroke="#0066B1" strokeWidth={2} name="Page Views" />
              <Line type="monotone" dataKey="users" stroke="#E22718" strokeWidth={2} name="Unique Users" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className={`${cardBg} border ${borderColor} p-6`}>
          <h3 className={`text-sm uppercase tracking-wider ${textSecondary} mb-6`}>Conversions</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={conversionData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#333" />
              <XAxis dataKey="date" tick={{ fill: '#999' }} />
              <YAxis tick={{ fill: '#999' }} />
              <Tooltip contentStyle={{ backgroundColor: '#000', border: '1px solid #333' }} />
              <Legend />
              <Bar dataKey="registrations" fill="#00C853" name="Event Registrations" />
              <Bar dataKey="listings" fill="#FFB300" name="Marketplace Listings" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </>
  );
}

function UsersTab({ theme }) {
  const cardBg = theme === 'dark' ? 'bg-gray-950' : 'bg-gray-50';
  const borderColor = theme === 'dark' ? 'border-gray-900' : 'border-gray-200';
  const inputBg = theme === 'dark' ? 'bg-black' : 'bg-white';
  const inputBorder = theme === 'dark' ? 'border-gray-800' : 'border-gray-300';
  const textSecondary = theme === 'dark' ? 'text-gray-500' : 'text-gray-600';
  const [searchQuery, setSearchQuery] = useState('');
  const [orderedUsers, setOrderedUsers] = useState([]);
  const { data: users = [] } = useQuery({ queryKey: ['crm-users'], queryFn: () => base44.entities.User.list() });
  const { data: posts = [] } = useQuery({ queryKey: ['user-posts'], queryFn: () => base44.entities.Post.list() });

  const filteredUsers = users.filter(u => u.full_name?.toLowerCase().includes(searchQuery.toLowerCase()) || u.email?.toLowerCase().includes(searchQuery.toLowerCase()));

  useEffect(() => {
    setOrderedUsers(filteredUsers);
  }, [filteredUsers]);

  const handleDragEnd = (result) => {
    const { source, destination } = result;
    if (!destination || source.index === destination.index) return;
    const items = Array.from(orderedUsers);
    const [reorderedItem] = items.splice(source.index, 1);
    items.splice(destination.index, 0, reorderedItem);
    setOrderedUsers(items);
  };

  return (
    <>
      <div className={`${cardBg} border ${borderColor} p-6 mb-8`}>
        <div className="relative">
          <Search className={`absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 ${textSecondary}`} />
          <Input value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder="Search users by name or email..." className={`${inputBg} border ${inputBorder} pl-10 cursor-pointer`} />
        </div>
      </div>

      <DragDropContext onDragEnd={handleDragEnd}>
        <Droppable droppableId="users-list">
          {(provided, snapshot) => (
            <div {...provided.droppableProps} ref={provided.innerRef} className="space-y-4">
              {orderedUsers.map((u, idx) => {
                const userPosts = posts.filter(p => p.author_email === u.email);
                return (
                  <Draggable key={u.id} draggableId={u.id} index={idx}>
                    {(provided, snapshot) => (
                      <motion.div
                        ref={provided.innerRef}
                        {...provided.draggableProps}
                        initial={{ opacity: 0, y: 20 }} 
                        animate={{ opacity: 1, y: 0 }} 
                        transition={{ delay: idx * 0.02 }} 
                        className={`${cardBg} border transition-all ${snapshot.isDragging ? 'border-[#0066B1] shadow-lg shadow-[#0066B1]/20' : borderColor} p-6 cursor-move`}
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex items-center gap-4 flex-1">
                            <div {...provided.dragHandleProps}>
                              <GripVertical className="w-4 h-4 text-gray-600" />
                            </div>
                            <img src={u.avatar || `https://ui-avatars.com/api/?name=${u.full_name}`} alt={u.full_name} className="w-16 h-16 rounded-full cursor-pointer" />
                            <div>
                              <h3 className="text-lg font-light mb-1 cursor-pointer hover:text-[#0066B1]">{u.full_name}</h3>
                              <div className="flex items-center gap-2 text-sm text-gray-500 mb-2 cursor-pointer hover:text-gray-400">
                                <Mail className="w-3 h-3" />{u.email}
                              </div>
                              <Badge className={u.role === 'admin' ? 'bg-[#E22718] cursor-pointer' : 'bg-[#0066B1] cursor-pointer'}>{u.role}</Badge>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="text-2xl font-light text-[#0066B1] mb-1">{userPosts.length}</div>
                            <p className="text-xs text-gray-500 uppercase tracking-wider">Posts</p>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </Draggable>
                );
              })}
              {provided.placeholder}
            </div>
          )}
        </Droppable>
      </DragDropContext>
    </>
  );
}

function IntegrationsTab({ theme }) {
  const cardBg = theme === 'dark' ? 'bg-gray-950' : 'bg-gray-50';
  const borderColor = theme === 'dark' ? 'border-gray-900' : 'border-gray-200';
  const textSecondary = theme === 'dark' ? 'text-gray-500' : 'text-gray-600';
  const [orderedKeys, setOrderedKeys] = useState([]);
  const [orderedWebhooks, setOrderedWebhooks] = useState([]);
  const queryClient = useQueryClient();
  const { data: apiKeys = [] } = useQuery({ queryKey: ['api-keys'], queryFn: () => base44.entities.APIKey.list() });
  const { data: webhooks = [] } = useQuery({ queryKey: ['webhooks'], queryFn: () => base44.entities.WebhookConfig.list() });

  useEffect(() => {
    setOrderedKeys(apiKeys);
    setOrderedWebhooks(webhooks);
  }, [apiKeys, webhooks]);

  const deleteKeyMutation = useMutation({
    mutationFn: (id) => base44.entities.APIKey.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['api-keys'] }),
  });

  const deleteWebhookMutation = useMutation({
    mutationFn: (id) => base44.entities.WebhookConfig.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['webhooks'] }),
  });

  const handleKeysDragEnd = (result) => {
    const { source, destination } = result;
    if (!destination || source.index === destination.index) return;
    const items = Array.from(orderedKeys);
    const [reorderedItem] = items.splice(source.index, 1);
    items.splice(destination.index, 0, reorderedItem);
    setOrderedKeys(items);
  };

  const handleWebhooksDragEnd = (result) => {
    const { source, destination } = result;
    if (!destination || source.index === destination.index) return;
    const items = Array.from(orderedWebhooks);
    const [reorderedItem] = items.splice(source.index, 1);
    items.splice(destination.index, 0, reorderedItem);
    setOrderedWebhooks(items);
  };

  return (
    <>
      <div className="mb-12">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-light uppercase tracking-wider">API Keys</h2>
          <CreateAPIKeyDialog />
        </div>
        <DragDropContext onDragEnd={handleKeysDragEnd}>
          <Droppable droppableId="api-keys-list">
            {(provided, snapshot) => (
              <div {...provided.droppableProps} ref={provided.innerRef} className="space-y-4">
                {orderedKeys.map((key, index) => (
                  <Draggable key={key.id} draggableId={key.id} index={index}>
                    {(provided, snapshot) => (
                      <div
                        ref={provided.innerRef}
                        {...provided.draggableProps}
                        className={`${cardBg} border transition-all ${snapshot.isDragging ? 'border-[#0066B1] shadow-lg shadow-[#0066B1]/20' : borderColor} p-6 flex items-center justify-between cursor-move`}
                      >
                        <div className="flex-1 flex items-center gap-4">
                          <div {...provided.dragHandleProps}>
                            <GripVertical className="w-4 h-4 text-gray-600" />
                          </div>
                          <div className="flex-1">
                            <h3 className="text-lg font-light mb-2">{key.name}</h3>
                            <div className="flex items-center gap-4 text-sm text-gray-500">
                              <span>Used: {key.usage_count} times</span>
                              <Badge className={key.active ? 'bg-[#00C853]' : 'bg-gray-700'}>{key.active ? 'Active' : 'Inactive'}</Badge>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button variant="outline" size="sm" className="border-gray-800 cursor-pointer" onClick={() => navigator.clipboard.writeText(key.key)}>
                            <Copy className="w-4 h-4" />
                          </Button>
                          <Button variant="outline" size="sm" className="border-gray-800 text-red-500 cursor-pointer hover:bg-red-950" onClick={() => deleteKeyMutation.mutate(key.id)}>
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    )}
                  </Draggable>
                ))}
                {provided.placeholder}
              </div>
            )}
          </Droppable>
        </DragDropContext>
      </div>

      <div>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-light uppercase tracking-wider">Webhooks</h2>
          <CreateWebhookDialog />
        </div>
        <DragDropContext onDragEnd={handleWebhooksDragEnd}>
          <Droppable droppableId="webhooks-list">
            {(provided, snapshot) => (
              <div {...provided.droppableProps} ref={provided.innerRef} className="space-y-4">
                {orderedWebhooks.map((webhook, index) => (
                  <Draggable key={webhook.id} draggableId={webhook.id} index={index}>
                    {(provided, snapshot) => (
                      <div
                        ref={provided.innerRef}
                        {...provided.draggableProps}
                        className={`${cardBg} border transition-all ${snapshot.isDragging ? 'border-[#0066B1] shadow-lg shadow-[#0066B1]/20' : borderColor} p-6 cursor-move`}
                      >
                        <div className="flex items-start justify-between mb-4">
                          <div className="flex-1 flex items-start gap-4">
                            <div {...provided.dragHandleProps}>
                              <GripVertical className="w-4 h-4 text-gray-600 mt-1" />
                            </div>
                            <div className="flex-1">
                              <h3 className="text-lg font-light mb-2">{webhook.name}</h3>
                              <p className="text-sm text-gray-500 mb-2">{webhook.url}</p>
                              <div className="flex gap-2">
                                {webhook.events.map(event => (
                                  <Badge key={event} variant="outline" className="border-gray-800 text-gray-400 cursor-pointer">{event}</Badge>
                                ))}
                              </div>
                            </div>
                          </div>
                          <Button variant="outline" size="sm" className="border-gray-800 text-red-500 cursor-pointer hover:bg-red-950" onClick={() => deleteWebhookMutation.mutate(webhook.id)}>
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                        <div className="grid grid-cols-3 gap-4 text-sm ml-8">
                          <div><span className="text-gray-500">Success:</span> {webhook.success_count}</div>
                          <div><span className="text-gray-500">Failures:</span> {webhook.failure_count}</div>
                          <div><Badge className={webhook.active ? 'bg-[#00C853]' : 'bg-gray-700'} className="cursor-pointer">{webhook.active ? 'Active' : 'Inactive'}</Badge></div>
                        </div>
                      </div>
                    )}
                  </Draggable>
                ))}
                {provided.placeholder}
              </div>
            )}
          </Droppable>
        </DragDropContext>
      </div>
    </>
  );
}

function CreateAPIKeyDialog() {
  const [name, setName] = useState('');
  const [open, setOpen] = useState(false);
  const queryClient = useQueryClient();

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.APIKey.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['api-keys'] });
      setOpen(false);
      setName('');
    }
  });

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="bg-[#0066B1]"><Plus className="w-4 h-4 mr-2" />Create API Key</Button>
      </DialogTrigger>
      <DialogContent className="bg-black border-gray-900 text-white">
        <DialogHeader><DialogTitle>Create API Key</DialogTitle></DialogHeader>
        <div className="space-y-4">
          <Input placeholder="API Key Name" value={name} onChange={(e) => setName(e.target.value)} className="bg-gray-950 border-gray-800" />
          <Button onClick={() => {
            const key = 'sk_' + Math.random().toString(36).substring(2, 15);
            createMutation.mutate({ name, key, permissions: ['read', 'write'] });
          }} className="w-full bg-[#E22718]">Create</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function CreateWebhookDialog() {
  const [formData, setFormData] = useState({ name: '', url: '', events: [] });
  const [open, setOpen] = useState(false);
  const queryClient = useQueryClient();

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.WebhookConfig.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['webhooks'] });
      setOpen(false);
      setFormData({ name: '', url: '', events: [] });
    }
  });

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="bg-[#0066B1]"><Plus className="w-4 h-4 mr-2" />Create Webhook</Button>
      </DialogTrigger>
      <DialogContent className="bg-black border-gray-900 text-white">
        <DialogHeader><DialogTitle>Create Webhook</DialogTitle></DialogHeader>
        <div className="space-y-4">
          <Input placeholder="Webhook Name" value={formData.name} onChange={(e) => setFormData({...formData, name: e.target.value})} className="bg-gray-950 border-gray-800" />
          <Input placeholder="URL" value={formData.url} onChange={(e) => setFormData({...formData, url: e.target.value})} className="bg-gray-950 border-gray-800" />
          <Button onClick={() => createMutation.mutate({ ...formData, secret: Math.random().toString(36) })} className="w-full bg-[#E22718]">Create</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}