import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Search, Zap, TrendingUp, Star, Users, ChevronRight } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const seriesCategories = [
  { name: 'All', icon: Star },
  { name: 'M Series', icon: Zap },
  { name: '3 Series', icon: TrendingUp },
  { name: '4 Series', icon: TrendingUp },
  { name: '5 Series', icon: TrendingUp },
  { name: '7 Series', icon: TrendingUp },
  { name: '8 Series', icon: TrendingUp },
  { name: 'X Series', icon: Users },
  { name: 'Z Series', icon: Star },
];

function ModelCard({ model, onClick }) {
  const { data: carsWithModel = [] } = useQuery({
    queryKey: ['cars-by-model', model.model_name],
    queryFn: () => base44.entities.Car.filter({ model: model.model_name }),
  });

  const { data: postsWithModel = [] } = useQuery({
    queryKey: ['posts-by-model', model.model_name],
    queryFn: async () => {
      const allPosts = await base44.entities.Post.list('-created_date', 100);
      return allPosts.filter(p => p.content?.includes(model.model_name));
    },
  });

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      onClick={onClick}
      className="bg-gray-950 border border-gray-900 overflow-hidden cursor-pointer hover:border-white transition-all group"
    >
      {model.image_url && (
        <div className="h-56 overflow-hidden bg-black">
          <img 
            src={model.image_url} 
            alt={model.model_name}
            className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity duration-300"
          />
        </div>
      )}
      <div className="p-6">
        <div className="flex items-start justify-between mb-3">
          <div>
            <h3 className="text-lg font-light text-white uppercase tracking-wide">{model.model_name}</h3>
            <p className="text-gray-600 text-xs uppercase tracking-widest mt-1">{model.generation} • {model.year_range}</p>
          </div>
          <ChevronRight className="w-4 h-4 text-gray-700 group-hover:text-white transition-colors" />
        </div>

        <div className="flex gap-4 mb-4 text-xs">
          <div className="text-gray-600">
            <span className="text-white font-light">{model.horsepower}</span>
          </div>
          <div className="text-gray-600">
            <span className="text-white font-light">{model.zero_to_sixty}</span>
          </div>
        </div>

        <div className="flex items-center gap-3 pt-3 border-t border-gray-900 text-xs text-gray-700 uppercase tracking-wider">
          <span>{carsWithModel.length} MEMBERS</span>
          <span>•</span>
          <span>{postsWithModel.length} POSTS</span>
        </div>
      </div>
    </motion.div>
  );
}

function ModelDetailModal({ model, onClose }) {
  const { data: carsWithModel = [] } = useQuery({
    queryKey: ['cars-by-model', model.model_name],
    queryFn: () => base44.entities.Car.filter({ model: model.model_name }),
  });

  const { data: postsWithModel = [] } = useQuery({
    queryKey: ['posts-by-model', model.model_name],
    queryFn: async () => {
      const allPosts = await base44.entities.Post.list('-created_date', 100);
      return allPosts.filter(p => p.content?.includes(model.model_name));
    },
  });

  return (
    <div className="fixed inset-0 bg-black/95 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={onClose}>
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-black border border-gray-900 max-w-4xl w-full max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {model.image_url && (
          <div className="h-72 overflow-hidden bg-black">
            <img src={model.image_url} alt={model.model_name} className="w-full h-full object-cover opacity-70" />
          </div>
        )}

        <div className="p-8">
          <div className="flex items-start justify-between mb-8">
            <div>
              <h2 className="text-2xl font-light text-white uppercase tracking-wide mb-2">{model.model_name}</h2>
              <p className="text-gray-600 text-xs uppercase tracking-widest">{model.generation} • {model.year_range}</p>
            </div>
            <button onClick={onClose} className="text-gray-600 hover:text-white text-2xl">×</button>
          </div>

          <Tabs defaultValue="specs" className="w-full">
            <TabsList className="bg-transparent border-b border-gray-900 rounded-none">
              <TabsTrigger value="specs" className="data-[state=active]:bg-transparent data-[state=active]:border-b-2 data-[state=active]:border-white rounded-none text-xs uppercase tracking-widest">Specs</TabsTrigger>
              <TabsTrigger value="history" className="data-[state=active]:bg-transparent data-[state=active]:border-b-2 data-[state=active]:border-white rounded-none text-xs uppercase tracking-widest">History</TabsTrigger>
              <TabsTrigger value="mods" className="data-[state=active]:bg-transparent data-[state=active]:border-b-2 data-[state=active]:border-white rounded-none text-xs uppercase tracking-widest">Mods</TabsTrigger>
              <TabsTrigger value="community" className="data-[state=active]:bg-transparent data-[state=active]:border-b-2 data-[state=active]:border-white rounded-none text-xs uppercase tracking-widest">Members ({carsWithModel.length})</TabsTrigger>
            </TabsList>

            <TabsContent value="specs" className="mt-8">
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-gray-950 border border-gray-900 p-5">
                  <p className="text-gray-700 text-xs mb-2 uppercase tracking-widest">Engine</p>
                  <p className="text-white font-light">{model.engine}</p>
                </div>
                <div className="bg-gray-950 border border-gray-900 p-5">
                  <p className="text-gray-700 text-xs mb-2 uppercase tracking-widest">Horsepower</p>
                  <p className="text-white font-light">{model.horsepower}</p>
                </div>
                <div className="bg-gray-950 border border-gray-900 p-5">
                  <p className="text-gray-700 text-xs mb-2 uppercase tracking-widest">Torque</p>
                  <p className="text-white font-light">{model.torque}</p>
                </div>
                <div className="bg-gray-950 border border-gray-900 p-5">
                  <p className="text-gray-700 text-xs mb-2 uppercase tracking-widest">0-60 mph</p>
                  <p className="text-white font-light">{model.zero_to_sixty}</p>
                </div>
                <div className="bg-gray-950 border border-gray-900 p-5">
                  <p className="text-gray-700 text-xs mb-2 uppercase tracking-widest">Top Speed</p>
                  <p className="text-white font-light">{model.top_speed}</p>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="history" className="mt-8">
              <div className="bg-gray-950 border border-gray-900 p-6">
                <p className="text-gray-400 leading-relaxed text-sm">{model.historical_info || 'No historical information available.'}</p>
              </div>
            </TabsContent>

            <TabsContent value="mods" className="mt-8">
              <div className="space-y-2">
                {model.popular_mods?.map((mod, idx) => (
                  <div key={idx} className="bg-gray-950 border border-gray-900 p-4 flex items-center gap-3">
                    <Zap className="w-4 h-4 text-gray-600" />
                    <span className="text-white text-sm">{mod}</span>
                  </div>
                ))}
                {!model.popular_mods?.length && (
                  <p className="text-gray-700 text-center py-8 text-xs uppercase tracking-wider">No modifications listed</p>
                )}
              </div>
            </TabsContent>

            <TabsContent value="community" className="mt-8">
              <div className="space-y-3">
                {carsWithModel.slice(0, 5).map((car) => (
                  <Link key={car.id} to={createPageUrl(`CarDetail?id=${car.id}`)}>
                    <div className="bg-gray-950 border border-gray-900 p-4 hover:border-white transition-colors flex items-center gap-4">
                      {car.image_url && (
                        <img src={car.image_url} alt={car.name} className="w-16 h-16 object-cover" />
                      )}
                      <div>
                        <h4 className="text-white font-light text-sm">{car.name}</h4>
                        <p className="text-gray-600 text-xs uppercase tracking-wider">{car.year} {car.make} {car.model}</p>
                        <p className="text-gray-700 text-xs uppercase tracking-wider mt-1">{car.owner_name}</p>
                      </div>
                    </div>
                  </Link>
                ))}
                {carsWithModel.length === 0 && (
                  <p className="text-gray-700 text-center py-8 text-xs uppercase tracking-wider">No members yet</p>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </motion.div>
    </div>
  );
}

export default function BMWModels() {
  const [user, setUser] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSeries, setSelectedSeries] = useState('All');
  const [selectedModel, setSelectedModel] = useState(null);
  const [aiSuggestions, setAiSuggestions] = useState([]);
  const [loadingAI, setLoadingAI] = useState(false);

  useEffect(() => {
    const loadUser = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    };
    loadUser();
  }, []);

  const { data: models = [] } = useQuery({
    queryKey: ['bmw-models'],
    queryFn: () => base44.entities.BMWModel.list(),
  });

  const { data: userCars = [] } = useQuery({
    queryKey: ['user-cars', user?.email],
    queryFn: () => base44.entities.Car.filter({ owner_email: user?.email }),
    enabled: !!user?.email,
  });

  useEffect(() => {
    const getAISuggestions = async () => {
      if (!user || userCars.length === 0) return;
      
      setLoadingAI(true);
      try {
        const userModels = userCars.map(c => c.model).join(', ');
        const result = await base44.integrations.Core.InvokeLLM({
          prompt: `Based on a BMW enthusiast who owns: ${userModels}, suggest 3 similar or complementary BMW models they might be interested in. Return only model names as a comma-separated list (e.g., "M340i, X5 M50i, M2").`,
        });
        
        const suggestions = result.split(',').map(m => m.trim()).filter(m => m);
        setAiSuggestions(suggestions);
      } catch (error) {
        console.error('AI suggestions failed:', error);
      } finally {
        setLoadingAI(false);
      }
    };

    getAISuggestions();
  }, [user, userCars]);

  const filteredModels = models.filter(model => {
    const matchesSeries = selectedSeries === 'All' || model.series === selectedSeries;
    const matchesSearch = !searchQuery || 
      model.model_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      model.generation.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesSeries && matchesSearch;
  });

  const suggestedModels = models.filter(m => aiSuggestions.includes(m.model_name));

  return (
    <div className="min-h-screen bg-black pb-20 md:pb-0">
      <style>{`
        html {
          scrollbar-width: thin;
          scrollbar-color: #333 #000;
        }
        ::-webkit-scrollbar {
          width: 12px;
        }
        ::-webkit-scrollbar-track {
          background: #000;
        }
        ::-webkit-scrollbar-thumb {
          background: #444;
          border-radius: 6px;
        }
        ::-webkit-scrollbar-thumb:hover {
          background: #0066B1;
        }
      `}</style>
      {/* Header */}
      <div className="bg-black border-b border-gray-900">
        <div className="max-w-7xl mx-auto px-6 py-16">
          <h1 className="text-3xl font-light text-white mb-2 uppercase tracking-wide">BMW Models</h1>
          <p className="text-gray-600 mb-8 text-xs uppercase tracking-widest">Explore Performance Lineup</p>

          <div className="relative max-w-2xl">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-700" />
            <Input
              placeholder="SEARCH MODELS OR GENERATION"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-12 bg-gray-950 border-gray-900 text-white h-12 text-xs uppercase tracking-wider placeholder-gray-700"
            />
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* AI Suggestions */}
        {suggestedModels.length > 0 && (
          <div className="mb-12">
            <div className="flex items-center gap-2 mb-6">
              <Zap className="w-4 h-4 text-gray-600" />
              <h2 className="text-xs font-medium text-white uppercase tracking-widest">Recommended</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {suggestedModels.map(model => (
                <ModelCard key={model.id} model={model} onClick={() => setSelectedModel(model)} />
              ))}
            </div>
          </div>
        )}

        {/* Series Filter - Optimized for right thumb */}
        <div className="flex gap-2 overflow-x-auto pb-4 mb-8 scrollbar-hide justify-end lg:justify-start">
          {seriesCategories.map((series) => {
            const Icon = series.icon;
            return (
              <button
                key={series.name}
                onClick={() => setSelectedSeries(series.name)}
                className={`flex items-center gap-2 px-6 py-3 font-medium whitespace-nowrap transition-all text-xs uppercase tracking-widest min-h-[48px] ${
                  selectedSeries === series.name
                    ? 'bg-white text-black'
                    : 'bg-gray-950 text-gray-600 hover:bg-gray-900 border border-gray-900'
                }`}
              >
                <Icon className="w-4 h-4" />
                {series.name}
              </button>
            );
          })}
        </div>

        {/* Models Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredModels.map((model) => (
            <ModelCard key={model.id} model={model} onClick={() => setSelectedModel(model)} />
          ))}
        </div>

        {filteredModels.length === 0 && (
          <div className="text-center py-16">
            <p className="text-gray-700 text-xs uppercase tracking-wider">No models found</p>
          </div>
        )}
      </div>

      {/* Model Detail Modal */}
      {selectedModel && (
        <ModelDetailModal model={selectedModel} onClose={() => setSelectedModel(null)} />
      )}
    </div>
  );
}