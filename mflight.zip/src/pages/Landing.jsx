import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { ChevronRight, Zap, Users, Camera, Award, Mail, Lock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { createPageUrl } from '@/utils';
import { Link, useNavigate } from 'react-router-dom';

export default function Landing() {
  const [user, setUser] = useState(null);
  const [showLoginForm, setShowLoginForm] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const checkAuth = async () => {
      const currentUser = await base44.auth.me().catch(() => null);
      setUser(currentUser);
    };
    checkAuth();
  }, []);

  const handleSignIn = () => {
    navigate(createPageUrl('SignIn'));
  };

  const handleJoinClub = () => {
    navigate(createPageUrl('JoinTheClub'));
  };

  const handleCommunityClick = () => {
    if (user) {
      navigate(createPageUrl('Home'));
    } else {
      base44.auth.redirectToLogin(createPageUrl('Home'));
    }
  };

  const handleEmailLogin = async (e) => {
    e.preventDefault();
    try {
      await base44.auth.signInWithPassword({ email, password });
      navigate(createPageUrl('Home'));
    } catch (error) {
      console.error('Login failed:', error);
    }
  };

  const features = [
    { icon: Zap, title: 'Performance', desc: 'Track your builds & mods', page: 'PerformanceDashboard' },
    { icon: Users, title: 'Community', desc: 'Connect with enthusiasts', page: 'Home' },
    { icon: Camera, title: 'Showcase', desc: 'Share your garage', page: 'Performance' },
    { icon: Award, title: 'Events', desc: 'Join exclusive meets', page: 'Events' },
  ];

  return (
    <div className="min-h-screen bg-black text-white overflow-y-auto">
      <style>{`
        * {
          scrollbar-width: thin;
          scrollbar-color: #333 #000;
        }
        ::-webkit-scrollbar {
          width: 10px;
          height: 10px;
        }
        ::-webkit-scrollbar-track {
          background: #000;
        }
        ::-webkit-scrollbar-thumb {
          background: #333;
          border-radius: 5px;
        }
        ::-webkit-scrollbar-thumb:hover {
          background: #E22718;
        }
      `}</style>
      {/* Video Hero Section */}
      <div className="relative h-screen flex items-center justify-center">
        {/* Image Background */}
          <div className="absolute inset-0 overflow-hidden">
            <img
              src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6962d0e518a709010619f321/25dcf5610_image01.jpg"
              alt="Hero"
              className="w-full h-full object-cover opacity-50"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-black" />
          </div>

        {/* Hero Content */}
        <div className="relative z-10 text-center px-6 max-w-4xl">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="mb-8">
              <div className="inline-block px-6 py-3 border-2 border-white mb-6">
                <h1 className="text-4xl md:text-6xl font-bold tracking-widest">MFLIGHT</h1>
              </div>
            </div>

            {/* Social Sign In */}
            <div className="space-y-4 mb-8">
              {!showLoginForm ? (
                <>
                  <p className="text-gray-600 text-xs uppercase tracking-widest">Continue with</p>
                  <div className="flex gap-4 justify-center">
                    <button
                      onClick={handleSignIn}
                      className="w-12 h-12 border border-gray-800 hover:border-[#0066B1] transition-colors flex items-center justify-center"
                      title="Sign in with Google"
                    >
                      <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                        <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                        <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                        <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                      </svg>
                    </button>

                    <button
                      onClick={handleSignIn}
                      className="w-12 h-12 border border-gray-800 hover:border-[#0066B1] transition-colors flex items-center justify-center"
                      title="Sign in with Facebook"
                    >
                      <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                      </svg>
                    </button>

                    <button
                      onClick={handleSignIn}
                      className="w-12 h-12 border border-gray-800 hover:border-[#0066B1] transition-colors flex items-center justify-center"
                      title="Sign in with Instagram"
                    >
                      <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                      </svg>
                    </button>
                  </div>
                  
                  <div className="flex items-center gap-4 my-6">
                    <div className="flex-1 h-px bg-gray-800"></div>
                    <span className="text-gray-600 text-xs uppercase tracking-widest">Or</span>
                    <div className="flex-1 h-px bg-gray-800"></div>
                  </div>

                  <button
                    onClick={() => setShowLoginForm(true)}
                    className="w-full border border-gray-800 hover:border-[#0066B1] transition-colors py-3 text-sm uppercase tracking-widest text-white flex items-center justify-center gap-2"
                  >
                    <Mail className="w-4 h-4" />
                    Sign in with Email
                  </button>
                </>
              ) : (
                <motion.form
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  onSubmit={handleEmailLogin}
                  className="space-y-4 max-w-md mx-auto"
                >
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-600" />
                    <Input
                      type="email"
                      placeholder="Email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="bg-black border-gray-800 text-white pl-10 py-6"
                      required
                    />
                  </div>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-600" />
                    <Input
                      type="password"
                      placeholder="Password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="bg-black border-gray-800 text-white pl-10 py-6"
                      required
                    />
                  </div>
                  <Button
                    type="submit"
                    className="w-full bg-white text-black hover:bg-gray-200 py-6 text-sm uppercase tracking-widest"
                  >
                    Sign In
                  </Button>
                  <button
                    type="button"
                    onClick={() => setShowLoginForm(false)}
                    className="w-full text-gray-600 hover:text-white text-xs uppercase tracking-widest transition-colors"
                  >
                    Back to Social Login
                  </button>
                </motion.form>
              )}
            </div>
            
            <h2 className="text-xl md:text-2xl font-light uppercase tracking-widest mb-4 text-gray-300">
              Premium BMW Car Club
            </h2>
            
            <p className="text-gray-400 text-sm md:text-base mb-12 max-w-2xl mx-auto uppercase tracking-wider">
              Join the elite community of BMW enthusiasts. Share your builds, connect with members, and elevate your passion.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-16">
              <Button
                onClick={handleJoinClub}
                className="bg-white text-black hover:bg-gray-200 px-8 py-6 text-sm uppercase tracking-widest font-medium"
              >
                Join the Club
                <ChevronRight className="w-4 h-4 ml-2" />
              </Button>
              
              <Button
                onClick={handleSignIn}
                className="bg-white text-black hover:bg-gray-200 px-8 py-6 text-sm uppercase tracking-widest"
              >
                Sign In
              </Button>
            </div>
          </motion.div>
        </div>

        {/* Scroll Indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5 }}
          className="absolute bottom-10 left-1/2 -translate-x-1/2 cursor-pointer"
          onClick={() => window.scrollTo({ top: window.innerHeight, behavior: 'smooth' })}
        >
          <div className="w-6 h-10 border-2 border-gray-600 rounded-full flex justify-center hover:border-[#0066B1] transition-colors">
            <motion.div
              animate={{ y: [0, 12, 0] }}
              transition={{ duration: 1.5, repeat: Infinity }}
              className="w-1 h-2 bg-gray-600 rounded-full mt-2"
            />
          </div>
        </motion.div>
      </div>

      {/* Features Section */}
      <div className="relative z-10 py-24 px-6">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h3 className="text-xs uppercase tracking-widest text-gray-600 mb-4">Why Join</h3>
            <h2 className="text-3xl font-light uppercase tracking-wide text-white">Elite Membership Benefits</h2>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, idx) => {
              const Icon = feature.icon;
              const isClickable = feature.page;
              const handleClick = () => {
                if (!feature.page) return;
                if (user) {
                  navigate(createPageUrl(feature.page));
                } else {
                  base44.auth.redirectToLogin(createPageUrl(feature.page));
                }
              };
              return (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.1 }}
                  className={`bg-gray-950 border border-gray-900 p-8 hover:border-[#0066B1] transition-colors ${isClickable ? 'cursor-pointer' : ''}`}
                  onClick={handleClick}
                >
                  <Icon className="w-8 h-8 mb-4 text-white" />
                  <h3 className="text-lg font-light uppercase tracking-wide text-white mb-2">{feature.title}</h3>
                  <p className="text-gray-600 text-xs uppercase tracking-wider">{feature.desc}</p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Final CTA */}
      <div className="relative z-10 py-24 px-6 border-t border-gray-900">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl font-light uppercase tracking-wide text-white mb-6">
              Ready to join?
            </h2>
            <p className="text-gray-600 text-xs uppercase tracking-widest mb-8">
              Free membership • Exclusive access • Premium community
            </p>
            <Button
              onClick={handleJoinClub}
              className="bg-white text-black hover:bg-gray-200 px-10 py-6 text-sm uppercase tracking-widest font-medium"
            >
              Get Started
              <ChevronRight className="w-4 h-4 ml-2" />
            </Button>
          </motion.div>
        </div>
      </div>
    </div>
  );
}