import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Search, User, Bell, MessageCircle, Sun, Moon, LogOut, UserCircle, Sparkles, ChevronLeft, ChevronRight, MoreHorizontal } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { ChevronDown } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import AIAssistant from '@/components/assistant/AIAssistant';
import BMWHud from '@/components/bmw/BMWHud';

export default function Layout({ children, currentPageName }) {
  const [user, setUser] = useState(null);
  const [searchOpen, setSearchOpen] = useState(false);
  const [theme, setTheme] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('theme') || 'dark';
    }
    return 'dark';
  });
  const navigate = useNavigate();
  const [showHudOverlay, setShowHudOverlay] = useState(false);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      localStorage.setItem('theme', theme);
      window.dispatchEvent(new Event('storage'));
    }
  }, [theme]);
  const [aiAssistantOpen, setAiAssistantOpen] = useState(false);

  useEffect(() => {
    const loadUser = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    };
    loadUser();
  }, []);

  const { data: notifications = [] } = useQuery({
    queryKey: ['notifications', user?.email],
    queryFn: () => base44.entities.Notification.filter({ user_email: user?.email, read: false }),
    enabled: !!user?.email,
  });

  const { data: messages = [] } = useQuery({
    queryKey: ['unread-messages', user?.email],
    queryFn: () => base44.entities.Message.filter({ to_email: user?.email, read: false }),
    enabled: !!user?.email,
  });

  const isAuthPage = currentPageName === 'Login';
  const isLandingPage = currentPageName === 'Landing';

  if (isAuthPage) {
    return <>{children}</>;
  }

  const navItems = [
      { 
        label: 'MODELS', 
        page: 'BMWModels',
        subItems: [
          { label: 'M Series', page: 'BMWModels?series=M Series' },
          { label: '3 Series', page: 'BMWModels?series=3 Series' },
          { label: '4 Series', page: 'BMWModels?series=4 Series' },
          { label: 'X Series', page: 'BMWModels?series=X Series' }
        ]
      },
      { 
        label: 'COMMUNITY', 
        page: 'Home',
        subItems: [
          { label: 'Feed', page: 'Home' },
          { label: 'Members', page: 'Friends' },
          { label: 'Groups', page: 'Groups' }
        ]
      },
      { 
        label: 'EVENTS', 
        page: 'Events'
      },
      { 
        label: 'GARAGE', 
        page: 'Garages',
        subItems: [
          { label: 'My Garages', page: 'Garages' },
          { label: 'Performance Dashboard', page: 'PerformanceDashboard' },
          { label: 'Performance HUD', page: 'BMWHUD' }
        ]
      },
      { 
        label: 'MAP', 
        page: 'CommunityMap'
      },
    ];

  if (user?.role === 'admin') {
    navItems.push({ 
      label: 'ADMIN', 
      page: 'Admin',
      subItems: [
        { label: 'Dashboard', page: 'Admin' },
        { label: 'Tuners', page: 'AdminTuners' },
        { label: 'CMS', page: 'AdminCMS' },
        { label: 'CRM', page: 'AdminCRM' },
        { label: 'APIs', page: 'AdminAPIs' }
      ]
    });
  }

  const bgColor = theme === 'dark' ? 'bg-black' : 'bg-white';
  const textColor = theme === 'dark' ? 'text-white' : 'text-gray-900';
  const borderColor = theme === 'dark' ? 'border-gray-900' : 'border-gray-200';
  const hoverAccent = theme === 'dark' ? 'hover:text-[#1CA4FF]' : 'hover:text-[#E2221E]';
  const primaryColor = theme === 'dark' ? '#1CA4FF' : '#1458DE';
  const accentColor = theme === 'dark' ? '#E2221E' : '#E2221E';

  return (
    <div className={`min-h-screen ${bgColor} ${textColor}`}>
      <style>{`
        * {
          scrollbar-width: thin;
          scrollbar-color: ${theme === 'dark' ? '#374151 #000' : '#E5E7EB #fff'};
        }
        ::-webkit-scrollbar {
          width: 10px;
          height: 10px;
        }
        ::-webkit-scrollbar-track {
          background: ${theme === 'dark' ? '#000' : '#fff'};
        }
        ::-webkit-scrollbar-thumb {
          background: ${theme === 'dark' ? '#374151' : '#E5E7EB'};
          border-radius: 5px;
        }
        ::-webkit-scrollbar-thumb:hover {
          background: ${theme === 'dark' ? '#1CA4FF' : '#1458DE'};
        }
      `}</style>

      {/* Top Navigation */}
      <nav className={`fixed top-0 left-0 right-0 z-50 ${bgColor} border-b ${borderColor}`}>
        {/* Main Top Bar */}
        <div className="max-w-7xl mx-auto px-6 relative">
          <div className="flex items-center justify-between h-16">
            {/* Left - Theme Toggle */}
            <div className="flex items-center gap-3">
              <button
                onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                className={`p-2 border ${borderColor} ${hoverAccent} transition-colors ${theme === 'dark' ? 'hover:border-[#1CA4FF]' : 'hover:border-[#1458DE]'}`}
              >
                {theme === 'dark' ? (
                  <Sun className="w-4 h-4" />
                ) : (
                  <Moon className="w-4 h-4" />
                )}
              </button>
            </div>

            {/* Center - Logo & Nav */}
            <div className="absolute left-1/2 -translate-x-1/2 flex items-center gap-12">
              {/* MFlight Logo */}
              <Link to={createPageUrl('Landing')} className="text-2xl font-bold tracking-wider">
                <div className="flex items-center gap-3">
                  <div className={`px-4 py-2 border-2 ${theme === 'dark' ? 'border-white hover:border-[#1CA4FF]' : 'border-[#1458DE] hover:border-[#E2221E]'} flex items-center justify-center transition-colors`}>
                    <span className={`text-xs font-bold tracking-widest ${theme === 'dark' ? 'text-white' : 'text-[#1458DE]'}`}>MFLIGHT</span>
                  </div>
                  <button onClick={() => setShowHudOverlay(!showHudOverlay)} className={`flex flex-col items-center gap-0.5 ${hoverAccent} transition-colors`}>
                    <div className={`w-1 h-1 rounded-full ${theme === 'dark' ? 'bg-white' : 'bg-[#1458DE]'}`} />
                    <div className="flex gap-1">
                      <div className={`w-1 h-1 rounded-full ${theme === 'dark' ? 'bg-white' : 'bg-[#1458DE]'}`} />
                      <div className={`w-1 h-1 rounded-full ${theme === 'dark' ? 'bg-white' : 'bg-[#1458DE]'}`} />
                    </div>
                    <div className="flex gap-1">
                      <div className={`w-1 h-1 rounded-full ${theme === 'dark' ? 'bg-white' : 'bg-[#1458DE]'}`} />
                      <div className={`w-1 h-1 rounded-full ${theme === 'dark' ? 'bg-white' : 'bg-[#1458DE]'}`} />
                      <div className={`w-1 h-1 rounded-full ${theme === 'dark' ? 'bg-white' : 'bg-[#1458DE]'}`} />
                    </div>
                  </button>
                </div>
              </Link>

              {/* Navigation Items */}
              <div className="hidden lg:flex items-center gap-8">
                {navItems.map((item) => (
                  item.subItems ? (
                    <DropdownMenu key={item.page}>
                      <DropdownMenuTrigger className={`flex items-center gap-1 text-xs font-medium tracking-widest ${textColor} ${hoverAccent} transition-colors uppercase outline-none`}>
                        {item.label}
                        <ChevronDown className="w-3 h-3" />
                      </DropdownMenuTrigger>
                      <DropdownMenuContent className={`${theme === 'dark' ? 'bg-black border-gray-800' : 'bg-white border-gray-200 shadow-lg'} rounded-none min-w-[160px]`}>
                        <DropdownMenuItem asChild>
                          <Link to={createPageUrl(item.page)} className={`${textColor} ${theme === 'dark' ? 'hover:bg-gray-900' : 'hover:bg-gray-50'} ${hoverAccent} cursor-pointer text-xs uppercase tracking-wider`}>
                            All {item.label}
                          </Link>
                        </DropdownMenuItem>
                        {item.subItems.map((subItem) => (
                          <DropdownMenuItem key={subItem.page} asChild>
                            <Link to={createPageUrl(subItem.page)} className={`${textColor} ${theme === 'dark' ? 'hover:bg-gray-900' : 'hover:bg-gray-50'} ${hoverAccent} cursor-pointer text-xs uppercase tracking-wider`}>
                              {subItem.label}
                            </Link>
                          </DropdownMenuItem>
                        ))}
                      </DropdownMenuContent>
                    </DropdownMenu>
                  ) : (
                    <Link
                      key={item.page}
                      to={createPageUrl(item.page)}
                      className={`text-xs font-medium tracking-widest ${textColor} ${hoverAccent} transition-colors uppercase`}
                    >
                      {item.label}
                    </Link>
                  )
                ))}
              </div>
            </div>

            {/* Right - Search */}
            <div className="flex items-center gap-3">
              <button 
                onClick={() => setSearchOpen(!searchOpen)}
                className={`p-2 ${textColor} ${hoverAccent} transition-colors`}
              >
                <Search className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Search Bar */}
          {searchOpen && (
            <div className="pb-4">
              <input
                type="text"
                placeholder="Search models, members, garages..."
                className={`w-full ${theme === 'dark' ? 'bg-gray-900 border-gray-800' : 'bg-gray-50 border-gray-200'} border rounded-none px-4 py-3 ${textColor} ${theme === 'dark' ? 'placeholder-gray-500 focus:border-[#1CA4FF]' : 'placeholder-gray-400 focus:border-[#1458DE]'} focus:outline-none transition-colors`}
                autoFocus
              />
            </div>
          )}
        </div>

        {/* Secondary Icon Bar */}
        <div className={`border-t ${borderColor}`}>
          <div className="max-w-7xl mx-auto px-6">
            <div className="flex items-center justify-between h-12">
              {/* Left - Navigation Arrows */}
              <div className="flex items-center gap-2">
                {!isLandingPage && (
                  <>
                    <button
                      onClick={() => navigate(-1)}
                      className={`p-2 ${textColor} ${hoverAccent} transition-colors`}
                      title="Go back"
                    >
                      <ChevronLeft className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => navigate(1)}
                      className={`p-2 ${textColor} ${hoverAccent} transition-colors`}
                      title="Go forward"
                    >
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </>
                )}
              </div>

              {/* Right - User Actions */}
              <div className="flex items-center gap-3">
                {user && (
                  <>
                    <Link to={createPageUrl('Notifications')} className="relative p-2">
                      <Bell className={`w-4 h-4 ${textColor} ${hoverAccent} transition-colors`} />
                      {notifications.length > 0 && (
                        <span className="absolute top-0 right-0 w-4 h-4 bg-[#E2221E] rounded-full text-[10px] flex items-center justify-center text-white font-bold shadow-lg">
                          {notifications.length}
                        </span>
                      )}
                    </Link>

                    <Link to={createPageUrl('Messages')} className="relative p-2">
                      <MessageCircle className={`w-4 h-4 ${textColor} ${hoverAccent} transition-colors`} />
                      {messages.length > 0 && (
                        <span className="absolute top-0 right-0 w-4 h-4 bg-[#E2221E] rounded-full text-[10px] flex items-center justify-center text-white font-bold shadow-lg">
                          {messages.length}
                        </span>
                      )}
                    </Link>

                    <button onClick={() => setShowHudOverlay(!showHudOverlay)} className="p-2">
                      <MoreHorizontal className={`w-4 h-4 ${textColor} ${hoverAccent} transition-colors`} />
                    </button>

                    <button
                      onClick={() => setAiAssistantOpen(!aiAssistantOpen)}
                      className={`p-2 ${textColor} ${hoverAccent} transition-colors`}
                      title="AI Assistant"
                    >
                      <Sparkles className="w-4 h-4" />
                    </button>

                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <button className="p-2">
                          <img
                            src={user.avatar || `https://ui-avatars.com/api/?name=${user.full_name}&background=0066B1&color=fff`}
                            alt={user.full_name}
                            className="w-6 h-6 rounded-full object-cover hover:opacity-80 transition border-2 border-transparent hover:border-[#0066B1]"
                          />
                        </button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className={`${theme === 'dark' ? 'bg-black border-gray-800' : 'bg-white border-gray-200 shadow-lg'}`}>
                        <DropdownMenuItem asChild>
                          <Link to={createPageUrl(`Profile?email=${user.email}`)} className={`flex items-center gap-2 ${textColor} ${theme === 'dark' ? 'hover:bg-gray-900' : 'hover:bg-gray-50'} ${hoverAccent} cursor-pointer`}>
                            <UserCircle className="w-4 h-4" />
                            <span className="text-xs uppercase tracking-wider">Profile</span>
                          </Link>
                        </DropdownMenuItem>
                        <DropdownMenuItem asChild>
                          <Link to={createPageUrl('PerformanceDashboard')} className={`flex items-center gap-2 ${textColor} ${theme === 'dark' ? 'hover:bg-gray-900' : 'hover:bg-gray-50'} ${hoverAccent} cursor-pointer`}>
                            <span className="text-xs">📊</span>
                            <span className="text-xs uppercase tracking-wider">Performance Dashboard</span>
                          </Link>
                        </DropdownMenuItem>
                        <DropdownMenuItem asChild>
                          <Link to={createPageUrl('BMWHUD')} className={`flex items-center gap-2 ${textColor} ${theme === 'dark' ? 'hover:bg-gray-900' : 'hover:bg-gray-50'} ${hoverAccent} cursor-pointer`}>
                            <span className="text-xs">🏁</span>
                            <span className="text-xs uppercase tracking-wider">Performance HUD</span>
                          </Link>
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                          onClick={() => base44.auth.logout(createPageUrl('Landing'))}
                          className={`flex items-center gap-2 ${textColor} ${theme === 'dark' ? 'hover:bg-gray-900' : 'hover:bg-gray-50'} hover:text-[#E2221E] cursor-pointer`}
                        >
                          <LogOut className="w-4 h-4" />
                          <span className="text-xs uppercase tracking-wider">Logout</span>
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </>
                )}

                {!user && (
                  <Button
                    onClick={() => base44.auth.redirectToLogin()}
                    variant="ghost"
                    className={`${textColor} ${hoverAccent}`}
                  >
                    Login
                  </Button>
                )}
              </div>
            </div>
          </div>
        </div>
      </nav>

      <main className="pt-20">
        {children}
        {user && <AIAssistant user={user} isOpen={aiAssistantOpen} onClose={() => setAiAssistantOpen(false)} />}

        {/* Performance HUD Overlay */}
        <AnimatePresence>
          {showHudOverlay && user && (
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 30, stiffness: 300 }}
              className="fixed top-20 left-0 right-0 bottom-0 z-[100]"
              style={{
                background: 'rgba(0, 0, 0, 0.3)',
                backdropFilter: 'blur(12px) saturate(120%)',
                WebkitBackdropFilter: 'blur(12px) saturate(120%)'
              }}
            >
              <div className="relative w-full h-full">
                <BMWHud />
              </div>
              <button
                onClick={() => setShowHudOverlay(false)}
                className="absolute top-6 right-6 z-[110] text-white/60 hover:text-white text-2xl font-light"
              >
                ✕
              </button>
            </motion.div>
          )}
        </AnimatePresence>


      </main>

      {/* Mobile Bottom Nav */}
      <div className={`lg:hidden fixed bottom-0 left-0 right-0 ${bgColor} border-t ${borderColor} z-40 ${theme === 'dark' ? 'bg-black/95 backdrop-blur-lg' : 'bg-white/95 backdrop-blur-lg'}`}>
        <div className="flex items-center justify-around h-16 px-4">
          {navItems.filter(item => !['GARAGES', 'GROUPS'].includes(item.label)).slice(0, 4).map((item) => (
            <Link
              key={item.page}
              to={createPageUrl(item.page)}
              className={`text-xs ${theme === 'dark' ? 'text-gray-400 hover:text-[#1CA4FF]' : 'text-gray-600 hover:text-[#1458DE]'} transition uppercase tracking-wider`}
            >
              {item.label}
            </Link>
          ))}
          {user && (
            <Link to={createPageUrl(`Profile?email=${user.email}`)}>
              <User className={`w-5 h-5 ${theme === 'dark' ? 'text-gray-400 hover:text-[#1CA4FF]' : 'text-gray-600 hover:text-[#E2221E]'} transition`} />
            </Link>
          )}
        </div>
      </div>
    </div>
  );
}