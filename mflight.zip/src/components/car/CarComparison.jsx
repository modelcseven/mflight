import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ArrowUpRight, ArrowDownLeft } from 'lucide-react';
import { motion } from 'framer-motion';

export default function CarComparison({ isOpen, onClose, car1, car2 }) {
  if (!car1 || !car2) return null;

  const specs = ['engine', 'horsepower', 'torque', '0_to_60', 'top_speed', 'transmission'];

  const compareValue = (spec) => {
    const val1 = car1.specifications?.[spec];
    const val2 = car2.specifications?.[spec];

    if (!val1 || !val2) return null;

    // Extract numeric values for comparison
    const num1 = parseFloat(val1);
    const num2 = parseFloat(val2);

    if (isNaN(num1) || isNaN(num2)) return null;

    const diff = num2 - num1;
    const isPositive = diff > 0;
    const percentage = ((diff / num1) * 100).toFixed(1);

    return { diff, isPositive, percentage };
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-gray-800 border-gray-700 max-w-4xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-white text-xl">Compare Cars</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Car Headers */}
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center" />
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-gray-700 border border-gray-600 rounded-lg p-4"
            >
              <h3 className="text-lg font-bold text-cyan-400">{car1.name}</h3>
              <p className="text-gray-400 text-sm">{car1.year} {car1.make} {car1.model}</p>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-gray-700 border border-gray-600 rounded-lg p-4"
            >
              <h3 className="text-lg font-bold text-orange-400">{car2.name}</h3>
              <p className="text-gray-400 text-sm">{car2.year} {car2.make} {car2.model}</p>
            </motion.div>
          </div>

          {/* Specifications Comparison */}
          <div>
            <h3 className="text-white font-semibold mb-4">Specifications</h3>
            <div className="space-y-3">
              {specs.map((spec) => {
                const val1 = car1.specifications?.[spec];
                const val2 = car2.specifications?.[spec];
                const comparison = compareValue(spec);

                return (
                  <div key={spec} className="grid grid-cols-3 gap-4">
                    <div className="bg-gray-700 rounded px-3 py-2 text-gray-300 text-sm font-medium capitalize">
                      {spec.replace('_', '-')}
                    </div>
                    <div className="bg-gray-700 rounded px-3 py-2 text-cyan-300 text-sm">
                      {val1 || 'N/A'}
                    </div>
                    <div className="bg-gray-700 rounded px-3 py-2 flex items-center justify-between">
                      <span className="text-orange-300 text-sm">{val2 || 'N/A'}</span>
                      {comparison && (
                        <span className={`text-xs font-bold flex items-center gap-1 ${comparison.isPositive ? 'text-green-400' : 'text-red-400'}`}>
                          {comparison.isPositive ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownLeft className="w-3 h-3" />}
                          {Math.abs(comparison.percentage)}%
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Modifications Count */}
          <div className="grid grid-cols-3 gap-4 pt-4 border-t border-gray-700">
            <div className="bg-gray-700 rounded px-3 py-2 text-gray-300 text-sm font-medium">
              Total Modifications
            </div>
            <div className="bg-gray-700 rounded px-3 py-2 text-cyan-300 text-sm font-bold">
              {car1.mods?.length || 0}
            </div>
            <div className="bg-gray-700 rounded px-3 py-2 text-orange-300 text-sm font-bold">
              {car2.mods?.length || 0}
            </div>
          </div>

          {/* Investment Comparison */}
          <div className="grid grid-cols-3 gap-4">
            <div className="bg-gray-700 rounded px-3 py-2 text-gray-300 text-sm font-medium">
              Total Investment
            </div>
            <div className="bg-gray-700 rounded px-3 py-2 text-cyan-300 text-sm font-bold">
              €{parseFloat(car1.total_investment || 0).toFixed(2)}
            </div>
            <div className="bg-gray-700 rounded px-3 py-2 text-orange-300 text-sm font-bold">
              €{parseFloat(car2.total_investment || 0).toFixed(2)}
            </div>
          </div>

          {/* Mod Categories Breakdown */}
          {(car1.mods?.length > 0 || car2.mods?.length > 0) && (
            <div className="pt-4 border-t border-gray-700">
              <h3 className="text-white font-semibold mb-4">Mod Categories</h3>
              <div className="grid grid-cols-3 gap-4">
                <div />
                <div className="space-y-2">
                  {[...new Set(car1.mods?.map(m => m.category) || [])].map(cat => (
                    <div key={`car1-${cat}`} className="flex justify-between text-sm text-gray-300">
                      <span>{cat}:</span>
                      <span className="text-cyan-400 font-semibold">
                        {car1.mods?.filter(m => m.category === cat).length}
                      </span>
                    </div>
                  ))}
                </div>
                <div className="space-y-2">
                  {[...new Set(car2.mods?.map(m => m.category) || [])].map(cat => (
                    <div key={`car2-${cat}`} className="flex justify-between text-sm text-gray-300">
                      <span>{cat}:</span>
                      <span className="text-orange-400 font-semibold">
                        {car2.mods?.filter(m => m.category === cat).length}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}