import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { motion } from 'framer-motion';

export default function PerformanceChart({ metrics }) {
  if (!metrics || metrics.length === 0) {
    return null;
  }

  const chartData = metrics.map(m => ({
    date: new Date(m.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
    '0-60 (s)': m.zero_to_60,
    'Quarter Mile (s)': m.quarter_mile,
    'Top Speed (km/h)': m.top_speed ? m.top_speed / 10 : 0 // Scale down for visualization
  })).sort((a, b) => new Date(a.date) - new Date(b.date));

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      {/* Time-based metrics */}
      <div className="bg-gray-800 border border-gray-700 rounded-lg p-6">
        <h3 className="text-lg font-bold text-white mb-4">Performance Over Time</h3>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
            <XAxis dataKey="date" stroke="#9ca3af" />
            <YAxis stroke="#9ca3af" />
            <Tooltip 
              contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #4b5563' }}
              labelStyle={{ color: '#fff' }}
            />
            <Legend />
            <Line type="monotone" dataKey="0-60 (s)" stroke="#00d4ff" strokeWidth={2} dot={{ fill: '#00d4ff' }} />
            <Line type="monotone" dataKey="Quarter Mile (s)" stroke="#fbbf24" strokeWidth={2} dot={{ fill: '#fbbf24' }} />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Latest metrics */}
      <div className="grid grid-cols-3 gap-4">
        {metrics[metrics.length - 1].zero_to_60 !== undefined && (
          <div className="bg-gray-800 border border-gray-700 rounded-lg p-4">
            <p className="text-gray-400 text-sm mb-1">0-60 Time</p>
            <p className="text-3xl font-bold text-cyan-400">{metrics[metrics.length - 1].zero_to_60}s</p>
          </div>
        )}
        {metrics[metrics.length - 1].quarter_mile !== undefined && (
          <div className="bg-gray-800 border border-gray-700 rounded-lg p-4">
            <p className="text-gray-400 text-sm mb-1">Quarter Mile</p>
            <p className="text-3xl font-bold text-amber-400">{metrics[metrics.length - 1].quarter_mile}s</p>
          </div>
        )}
        {metrics[metrics.length - 1].top_speed !== undefined && (
          <div className="bg-gray-800 border border-gray-700 rounded-lg p-4">
            <p className="text-gray-400 text-sm mb-1">Top Speed</p>
            <p className="text-3xl font-bold text-orange-400">{metrics[metrics.length - 1].top_speed} km/h</p>
          </div>
        )}
      </div>
    </motion.div>
  );
}