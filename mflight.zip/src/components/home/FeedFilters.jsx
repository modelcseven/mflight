import React from 'react';
import { Button } from '@/components/ui/button';
import { Gauge, Wrench, MapPin, Filter } from 'lucide-react';
import { motion } from 'framer-motion';

export default function FeedFilters({ activeFilter, onFilterChange }) {
  const filters = [
    { id: 'all', label: 'All Posts', icon: Filter },
    { id: 'garages', label: 'Garages Only', icon: Gauge },
    { id: 'mods', label: 'Mod Spotlights', icon: Wrench },
    { id: 'local', label: 'Local Club', icon: MapPin }
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide justify-end lg:justify-start"
    >
      {filters.map(filter => {
        const Icon = filter.icon;
        const isActive = activeFilter === filter.id;
        
        return (
          <button
            key={filter.id}
            onClick={() => onFilterChange(filter.id)}
            className={`flex items-center gap-2 px-5 py-3 whitespace-nowrap transition-colors text-xs uppercase tracking-wider min-h-[48px] ${
              isActive 
                ? 'bg-white text-black'
                : 'bg-gray-950 border border-gray-900 text-white hover:border-white'
            }`}
          >
            <Icon className="w-4 h-4" />
            {filter.label}
          </button>
        );
      })}
    </motion.div>
  );
}