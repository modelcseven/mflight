import React from 'react';
import { motion } from 'framer-motion';
import { Gauge, Trophy, Calendar } from 'lucide-react';

export default function FleetStats({ garageCount, carCount, memberSinceDate }) {
  const stats = [
    {
      icon: Gauge,
      label: 'Garages',
      value: garageCount,
      color: 'text-cyan-400',
      bgColor: 'bg-cyan-500/20'
    },
    {
      icon: Trophy,
      label: 'Cars Owned',
      value: carCount,
      color: 'text-amber-400',
      bgColor: 'bg-amber-500/20'
    },
    {
      icon: Calendar,
      label: 'Member Since',
      value: new Date(memberSinceDate).toLocaleDateString('en-US', { month: 'short', year: 'numeric' }),
      color: 'text-orange-400',
      bgColor: 'bg-orange-500/20',
      isDate: true
    }
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="grid grid-cols-3 gap-4 mb-6"
    >
      {stats.map((stat, idx) => {
        const Icon = stat.icon;
        return (
          <div
            key={idx}
            className={`${stat.bgColor} border border-gray-700 rounded-lg p-4 text-center`}
          >
            <Icon className={`w-6 h-6 ${stat.color} mx-auto mb-2`} />
            <p className={`text-2xl font-bold ${stat.color}`}>
              {stat.isDate ? stat.value : stat.value}
            </p>
            <p className="text-xs text-gray-400 mt-1">{stat.label}</p>
          </div>
        );
      })}
    </motion.div>
  );
}