import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function CoverSlideshow({ coverMedia = [] }) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  // Auto-advance slideshow every 5 seconds
  useEffect(() => {
    if (!isAutoPlaying || coverMedia.length <= 1) return;
    
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % coverMedia.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [isAutoPlaying, coverMedia.length]);

  const goToPrevious = () => {
    setIsAutoPlaying(false);
    setCurrentIndex((prev) => (prev - 1 + coverMedia.length) % coverMedia.length);
  };

  const goToNext = () => {
    setIsAutoPlaying(false);
    setCurrentIndex((prev) => (prev + 1) % coverMedia.length);
  };

  if (!coverMedia || coverMedia.length === 0) {
    return (
      <img
        src="https://images.unsplash.com/photo-1614850523459-c2f4c699c52e?w=1200&h=400&fit=crop"
        alt="Cover"
        className="w-full h-full object-cover opacity-60"
      />
    );
  }

  const currentMedia = coverMedia[currentIndex];

  return (
    <div className="relative w-full h-full">
      <AnimatePresence mode="wait">
        <motion.div
          key={currentIndex}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5 }}
          className="w-full h-full"
        >
          {currentMedia?.type === 'video' ? (
            <video
              src={currentMedia.url}
              className="w-full h-full object-cover opacity-60"
              autoPlay
              muted
              loop
            />
          ) : (
            <img
              src={currentMedia?.url || 'https://images.unsplash.com/photo-1614850523459-c2f4c699c52e?w=1200&h=400&fit=crop'}
              alt="Cover"
              className="w-full h-full object-cover opacity-60"
            />
          )}
        </motion.div>
      </AnimatePresence>

      {/* Navigation Controls */}
      {coverMedia.length > 1 && (
        <>
          <button
            onClick={goToPrevious}
            className="absolute left-4 top-1/2 -translate-y-1/2 p-2 bg-black/50 hover:bg-black/70 border border-gray-800 transition-all"
          >
            <ChevronLeft className="w-5 h-5 text-white" />
          </button>
          <button
            onClick={goToNext}
            className="absolute right-4 top-1/2 -translate-y-1/2 p-2 bg-black/50 hover:bg-black/70 border border-gray-800 transition-all"
          >
            <ChevronRight className="w-5 h-5 text-white" />
          </button>

          {/* Dots Indicator */}
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
            {coverMedia.map((_, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setCurrentIndex(idx);
                  setIsAutoPlaying(false);
                }}
                className={`w-2 h-2 rounded-full transition-all ${
                  idx === currentIndex ? 'bg-white w-6' : 'bg-white/50'
                }`}
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
}