import React from 'react';
import { motion } from 'framer-motion';
import { Camera, CarIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function GarageBanner({ user, garage, carCount, isOwnProfile }) {
  const bannerImage = garage?.cover_image || 'https://images.unsplash.com/photo-1552820728-8ac41f1ce891?w=1200&h=400&fit=crop';

  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="relative h-64 overflow-hidden bg-gray-800 mb-6 group"
    >
      {bannerImage && (
        <img
          src={bannerImage}
          alt="Garage"
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
      )}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-gray-900" />
      
      {isOwnProfile && (
        <Button
          variant="secondary"
          size="sm"
          className="absolute top-4 right-4 bg-white/90 hover:bg-white text-gray-900"
        >
          <Camera className="w-4 h-4 mr-2" />
          Edit Banner
        </Button>
      )}

      <div className="absolute bottom-0 left-0 right-0 p-4">
        <h3 className="text-2xl font-bold text-white mb-2">{garage.name}</h3>
        <div className="flex items-center gap-4 text-gray-100">
          <div className="flex items-center gap-1">
            <CarIcon className="w-4 h-4 text-cyan-400" />
            <span className="text-sm font-medium">{carCount} car{carCount !== 1 ? 's' : ''}</span>
          </div>
          {garage.description && (
            <p className="text-sm text-gray-300 truncate">{garage.description}</p>
          )}
        </div>
      </div>
    </motion.div>
  );
}