import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight, Video, Trash2, Plus, Share2 } from 'lucide-react';

export default function GarageSlideshow({ items = [], videos = [], isOwnGarage = false, onDeleteItem, onDeleteVideo, onAddImage, onShare }) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [autoPlay, setAutoPlay] = useState(true);
  const thumbnailContainerRef = useRef(null);

  // Combine images from items and videos
  const slides = [
    ...items.filter(item => item.image_url).map(item => ({
      type: 'image',
      url: item.image_url,
      title: item.name,
      id: item.id
    })),
    ...videos.map(video => ({
      type: 'video',
      url: `https://img.youtube.com/vi/${video.youtube_video_id}/maxresdefault.jpg`,
      videoId: video.youtube_video_id,
      title: video.title,
      id: video.id
    }))
  ];

  useEffect(() => {
    if (!autoPlay || slides.length === 0) return;
    
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % slides.length);
    }, 5000);

    return () => clearInterval(timer);
  }, [autoPlay, slides.length]);

  // Move this effect before any early return to satisfy Rules of Hooks
  useEffect(() => {
    if (thumbnailContainerRef.current) {
      const activeButton = thumbnailContainerRef.current.children[currentIndex];
      if (activeButton) {
        activeButton.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
      }
    }
  }, [currentIndex]);

  if (slides.length === 0) return null;

  const currentSlide = slides[currentIndex];

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + slides.length) % slides.length);
    setAutoPlay(false);
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % slides.length);
    setAutoPlay(false);
  };

  const handleSlideClick = (index) => {
    setCurrentIndex(index);
    setAutoPlay(false);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="mb-8"
    >
      <div className="relative bg-black border border-gray-900 overflow-hidden">
        {/* Main Slideshow */}
        <div className="relative h-96 md:h-[500px]">
          <AnimatePresence mode="fade">
            <motion.div
              key={currentIndex}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.5 }}
              className="absolute inset-0"
            >
              <img
                src={currentSlide.url}
                alt={currentSlide.title}
                className="w-full h-full object-cover"
              />
              {currentSlide.type === 'video' && (
                <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                  <Video className="w-16 h-16 text-[#E22718]" />
                </div>
              )}
              
              {/* Action Buttons */}
              {isOwnGarage && (
                <div className="absolute top-4 right-4 z-20 flex flex-col gap-2">
                  <button
                    onClick={onAddImage}
                    className="bg-black/60 hover:bg-[#0066B1] p-2 text-white transition"
                    title="Add image"
                  >
                    <Plus className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => onShare?.(currentSlide)}
                    className="bg-black/60 hover:bg-[#0066B1] p-2 text-white transition"
                    title="Share"
                  >
                    <Share2 className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => {
                      if (currentSlide.type === 'video') {
                        onDeleteVideo?.(currentSlide.id);
                      } else {
                        onDeleteItem?.(currentSlide.id);
                      }
                    }}
                    className="bg-black/60 hover:bg-[#E22718] p-2 text-white transition"
                    title="Delete image"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              )}
            </motion.div>
          </AnimatePresence>

          {/* Navigation Buttons */}
          {slides.length > 1 && (
            <>
              <button
                onClick={handlePrev}
                className="absolute left-4 top-1/2 -translate-y-1/2 z-10 bg-black/60 hover:bg-black/80 p-2 text-white transition"
              >
                <ChevronLeft className="w-6 h-6" />
              </button>
              <button
                onClick={handleNext}
                className="absolute right-4 top-1/2 -translate-y-1/2 z-10 bg-black/60 hover:bg-black/80 p-2 text-white transition"
              >
                <ChevronRight className="w-6 h-6" />
              </button>
            </>
          )}

          {/* Counter */}
          {slides.length > 1 && (
            <div className="absolute bottom-4 right-4 bg-black/60 text-white text-xs px-3 py-1">
              {currentIndex + 1} / {slides.length}
            </div>
          )}
        </div>

        {/* Four Thumbnails */}
        {slides.length > 0 && (
          <div className="bg-gray-950 border-t border-gray-900 p-3">
            <div className="grid grid-cols-4 gap-2">
              {slides.slice(0, 4).map((slide, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSlideClick(idx)}
                  className={`w-full h-24 border-2 transition relative ${
                    currentIndex === idx
                      ? 'border-[#0066B1]'
                      : 'border-gray-800 hover:border-gray-700'
                  }`}
                >
                  <img
                    src={slide.url}
                    alt={`Slide ${idx + 1}`}
                    className="w-full h-full object-cover"
                  />
                  {slide.type === 'video' && (
                    <div className="absolute inset-0 flex items-center justify-center bg-black/40">
                      <Video className="w-4 h-4 text-[#E22718]" />
                    </div>
                  )}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
}