import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { Fuel, Plus, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';

export default function FuelSection({ carId, garageId, userEmail, isOwner }) {
  const [isOpen, setIsOpen] = useState(false);
  const [form, setForm] = useState({
    date: new Date().toISOString().split('T')[0],
    mileage: '',
    fuel_amount: '',
    cost: '',
    fuel_type: 'petrol',
    full_tank: false,
    location: '',
    notes: ''
  });
  const queryClient = useQueryClient();

  const { data: logs = [] } = useQuery({
    queryKey: ['fuel', carId],
    queryFn: () => base44.entities.FuelLog.filter({ car_id: carId }),
    enabled: !!carId,
  });

  const addMutation = useMutation({
    mutationFn: (data) => base44.entities.FuelLog.create({
      car_id: carId,
      garage_id: garageId,
      owner_email: userEmail,
      ...data,
      mileage: parseInt(data.mileage) || 0,
      fuel_amount: parseFloat(data.fuel_amount) || 0,
      cost: parseFloat(data.cost) || 0
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['fuel'] });
      setForm({
        date: new Date().toISOString().split('T')[0],
        mileage: '',
        fuel_amount: '',
        cost: '',
        fuel_type: 'petrol',
        full_tank: false,
        location: '',
        notes: ''
      });
      setIsOpen(false);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.FuelLog.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['fuel'] }),
  });

  const calculateMPG = (log1, log2) => {
    const distance = log2.mileage - log1.mileage;
    return (distance / log2.fuel_amount).toFixed(2);
  };

  const calculateL100km = (log1, log2) => {
    const distance = log2.mileage - log1.mileage;
    return ((log2.fuel_amount / distance) * 100).toFixed(2);
  };

  const sortedLogs = [...logs].sort((a, b) => new Date(b.date) - new Date(a.date));
  const totalFuel = logs.reduce((sum, l) => sum + l.fuel_amount, 0);
  const totalCost = logs.reduce((sum, l) => sum + (l.cost || 0), 0);

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-xl font-light uppercase tracking-wider">Fuel Consumption</h3>
          <p className="text-gray-500 text-sm mt-1">{totalFuel.toFixed(1)}L consumed • ${totalCost.toFixed(2)} spent</p>
        </div>
        {isOwner && (
          <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>
              <Button className="bg-[#0066B1] hover:bg-[#0055A0]">
                <Plus className="w-4 h-4 mr-2" />
                Log Fuel
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-black border-gray-900">
              <DialogHeader>
                <DialogTitle className="text-white">Log Fuel Fill-up</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <Input type="date" value={form.date} onChange={(e) => setForm({...form, date: e.target.value})} className="bg-gray-950 border-gray-800 text-white" />
                <Input placeholder="Odometer (km)" type="number" value={form.mileage} onChange={(e) => setForm({...form, mileage: e.target.value})} className="bg-gray-950 border-gray-800 text-white" />
                <Input placeholder="Fuel Amount (L)" type="number" step="0.01" value={form.fuel_amount} onChange={(e) => setForm({...form, fuel_amount: e.target.value})} className="bg-gray-950 border-gray-800 text-white" />
                <Input placeholder="Cost ($)" type="number" step="0.01" value={form.cost} onChange={(e) => setForm({...form, cost: e.target.value})} className="bg-gray-950 border-gray-800 text-white" />
                <Select value={form.fuel_type} onValueChange={(val) => setForm({...form, fuel_type: val})}>
                  <SelectTrigger className="bg-gray-950 border-gray-800 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-black border-gray-800">
                    <SelectItem value="petrol">Petrol</SelectItem>
                    <SelectItem value="diesel">Diesel</SelectItem>
                    <SelectItem value="hybrid">Hybrid</SelectItem>
                    <SelectItem value="electric">Electric</SelectItem>
                  </SelectContent>
                </Select>
                <Input placeholder="Location (optional)" value={form.location} onChange={(e) => setForm({...form, location: e.target.value})} className="bg-gray-950 border-gray-800 text-white" />
                <Input placeholder="Notes (optional)" value={form.notes} onChange={(e) => setForm({...form, notes: e.target.value})} className="bg-gray-950 border-gray-800 text-white" />
                <Button onClick={() => addMutation.mutate(form)} className="w-full bg-[#0066B1] hover:bg-[#0055A0]" disabled={!form.mileage || !form.fuel_amount}>Log Fuel</Button>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {sortedLogs.length > 0 ? (
        <div className="space-y-2">
          {sortedLogs.map((log, idx) => {
            const prevLog = sortedLogs[idx + 1];
            const mpg = prevLog ? calculateMPG(prevLog, log) : null;
            const l100km = prevLog ? calculateL100km(prevLog, log) : null;
            
            return (
              <motion.div key={log.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-gray-950 border border-gray-900 p-4 hover:border-gray-800 transition group">
                <div className="flex justify-between items-start">
                  <div className="flex gap-3 flex-1">
                    <Fuel className="w-5 h-5 text-[#0066B1] flex-shrink-0 mt-1" />
                    <div>
                      <p className="text-white font-light uppercase tracking-wide">{new Date(log.date).toLocaleDateString()}</p>
                      <div className="text-gray-500 text-sm space-y-1 mt-1">
                        <p>{log.mileage.toLocaleString()} km • {log.fuel_amount.toFixed(2)}L • ${log.cost.toFixed(2)}</p>
                        {mpg && l100km && <p className="text-[#0066B1]">Efficiency: {mpg} MPG • {l100km}L/100km</p>}
                        {log.location && <p>{log.location}</p>}
                      </div>
                    </div>
                  </div>
                  {isOwner && (
                    <button onClick={() => deleteMutation.mutate(log.id)} className="text-gray-500 hover:text-[#E22718] transition opacity-0 group-hover:opacity-100">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>
      ) : (
        <div className="bg-gray-950 border border-gray-900 p-6 text-center text-gray-500 text-sm">No fuel logs</div>
      )}
    </div>
  );
}