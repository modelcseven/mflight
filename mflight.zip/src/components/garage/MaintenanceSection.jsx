import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { Wrench, Plus, Trash2, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';

export default function MaintenanceSection({ carId, garageId, userEmail, isOwner }) {
  const [isOpen, setIsOpen] = useState(false);
  const [form, setForm] = useState({
    service_type: 'oil_change',
    service_date: new Date().toISOString().split('T')[0],
    cost: '',
    service_provider: '',
    mileage: '',
    description: '',
    notes: ''
  });
  const queryClient = useQueryClient();

  const { data: records = [] } = useQuery({
    queryKey: ['maintenance', carId],
    queryFn: () => base44.entities.MaintenanceRecord.filter({ car_id: carId }),
    enabled: !!carId,
  });

  const addMutation = useMutation({
    mutationFn: (data) => base44.entities.MaintenanceRecord.create({
      car_id: carId,
      garage_id: garageId,
      owner_email: userEmail,
      ...data,
      cost: parseFloat(data.cost) || 0,
      mileage: parseInt(data.mileage) || 0
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['maintenance'] });
      setForm({
        service_type: 'oil_change',
        service_date: new Date().toISOString().split('T')[0],
        cost: '',
        service_provider: '',
        mileage: '',
        description: '',
        notes: ''
      });
      setIsOpen(false);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.MaintenanceRecord.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['maintenance'] }),
  });

  const sortedRecords = [...records].sort((a, b) => new Date(b.service_date) - new Date(a.service_date));
  const totalCost = records.reduce((sum, r) => sum + (r.cost || 0), 0);

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-xl font-light uppercase tracking-wider">Maintenance Records</h3>
          {totalCost > 0 && <p className="text-gray-500 text-sm mt-1">Total spent: ${totalCost.toFixed(2)}</p>}
        </div>
        {isOwner && (
          <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>
              <Button className="bg-[#0066B1] hover:bg-[#0055A0]">
                <Plus className="w-4 h-4 mr-2" />
                Log Service
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-black border-gray-900">
              <DialogHeader>
                <DialogTitle className="text-white">Log Maintenance Service</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <Select value={form.service_type} onValueChange={(val) => setForm({...form, service_type: val})}>
                  <SelectTrigger className="bg-gray-950 border-gray-800 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-black border-gray-800">
                    <SelectItem value="oil_change">Oil Change</SelectItem>
                    <SelectItem value="tire_rotation">Tire Rotation</SelectItem>
                    <SelectItem value="brake_service">Brake Service</SelectItem>
                    <SelectItem value="transmission">Transmission</SelectItem>
                    <SelectItem value="engine_rebuild">Engine Rebuild</SelectItem>
                    <SelectItem value="inspection">Inspection</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
                <Input type="date" value={form.service_date} onChange={(e) => setForm({...form, service_date: e.target.value})} className="bg-gray-950 border-gray-800 text-white" />
                <Input placeholder="Cost ($)" type="number" step="0.01" value={form.cost} onChange={(e) => setForm({...form, cost: e.target.value})} className="bg-gray-950 border-gray-800 text-white" />
                <Input placeholder="Service Provider" value={form.service_provider} onChange={(e) => setForm({...form, service_provider: e.target.value})} className="bg-gray-950 border-gray-800 text-white" />
                <Input placeholder="Mileage" type="number" value={form.mileage} onChange={(e) => setForm({...form, mileage: e.target.value})} className="bg-gray-950 border-gray-800 text-white" />
                <Input placeholder="Description" value={form.description} onChange={(e) => setForm({...form, description: e.target.value})} className="bg-gray-950 border-gray-800 text-white" />
                <Input placeholder="Notes (optional)" value={form.notes} onChange={(e) => setForm({...form, notes: e.target.value})} className="bg-gray-950 border-gray-800 text-white" />
                <Button onClick={() => addMutation.mutate(form)} className="w-full bg-[#0066B1] hover:bg-[#0055A0]" disabled={!form.service_date}>Add Record</Button>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {sortedRecords.length > 0 ? (
        <div className="space-y-2">
          {sortedRecords.map((record) => (
            <motion.div key={record.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-gray-950 border border-gray-900 p-4 hover:border-gray-800 transition group">
              <div className="flex justify-between items-start">
                <div className="flex gap-3 flex-1">
                  <Wrench className="w-5 h-5 text-[#0066B1] flex-shrink-0 mt-1" />
                  <div>
                    <h4 className="text-white font-light uppercase tracking-wide">{record.service_type.replace(/_/g, ' ')}</h4>
                    <p className="text-gray-500 text-sm">{record.description}</p>
                    <div className="flex gap-4 text-xs text-gray-500 mt-2">
                      <span className="flex items-center gap-1"><Calendar className="w-3 h-3" />{new Date(record.service_date).toLocaleDateString()}</span>
                      {record.cost && <span>${record.cost.toFixed(2)}</span>}
                      {record.mileage && <span>{record.mileage.toLocaleString()} km</span>}
                      {record.service_provider && <span>{record.service_provider}</span>}
                    </div>
                  </div>
                </div>
                {isOwner && (
                  <button onClick={() => deleteMutation.mutate(record.id)} className="text-gray-500 hover:text-[#E22718] transition opacity-0 group-hover:opacity-100">
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            </motion.div>
          ))}
        </div>
      ) : (
        <div className="bg-gray-950 border border-gray-900 p-6 text-center text-gray-500 text-sm">No maintenance records</div>
      )}
    </div>
  );
}