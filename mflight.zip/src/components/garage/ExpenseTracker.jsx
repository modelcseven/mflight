import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { DollarSign, Plus, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';

export default function ExpenseTracker({ carId, garageId, userEmail, isOwner }) {
  const [isOpen, setIsOpen] = useState(false);
  const [form, setForm] = useState({
    expense_type: 'maintenance',
    description: '',
    amount: '',
    date: new Date().toISOString().split('T')[0],
    category: 'one_time',
    payment_method: '',
    notes: ''
  });
  const queryClient = useQueryClient();

  const { data: expenses = [] } = useQuery({
    queryKey: ['expenses', carId],
    queryFn: () => base44.entities.CarExpense.filter({ car_id: carId }),
    enabled: !!carId,
  });

  const addMutation = useMutation({
    mutationFn: (data) => base44.entities.CarExpense.create({
      car_id: carId,
      garage_id: garageId,
      owner_email: userEmail,
      ...data,
      amount: parseFloat(data.amount) || 0
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['expenses'] });
      setForm({
        expense_type: 'maintenance',
        description: '',
        amount: '',
        date: new Date().toISOString().split('T')[0],
        category: 'one_time',
        payment_method: '',
        notes: ''
      });
      setIsOpen(false);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.CarExpense.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['expenses'] }),
  });

  const sortedExpenses = [...expenses].sort((a, b) => new Date(b.date) - new Date(a.date));
  const totalExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);
  const monthlyExpenses = expenses.filter(e => {
    const expDate = new Date(e.date);
    const today = new Date();
    return expDate.getMonth() === today.getMonth() && expDate.getFullYear() === today.getFullYear();
  }).reduce((sum, e) => sum + e.amount, 0);

  const expenseTypes = [
    { value: 'insurance', label: 'Insurance' },
    { value: 'registration', label: 'Registration' },
    { value: 'maintenance', label: 'Maintenance' },
    { value: 'fuel', label: 'Fuel' },
    { value: 'modification', label: 'Modification' },
    { value: 'parking', label: 'Parking' },
    { value: 'tolls', label: 'Tolls' },
    { value: 'cleaning', label: 'Cleaning' },
    { value: 'other', label: 'Other' }
  ];

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-xl font-light uppercase tracking-wider">Expense Tracker</h3>
          <div className="flex gap-6 text-sm text-gray-500 mt-1">
            <span>Total: ${totalExpenses.toFixed(2)}</span>
            <span>This Month: ${monthlyExpenses.toFixed(2)}</span>
          </div>
        </div>
        {isOwner && (
          <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>
              <Button className="bg-[#0066B1] hover:bg-[#0055A0]">
                <Plus className="w-4 h-4 mr-2" />
                Log Expense
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-black border-gray-900">
              <DialogHeader>
                <DialogTitle className="text-white">Log Car Expense</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <Select value={form.expense_type} onValueChange={(val) => setForm({...form, expense_type: val})}>
                  <SelectTrigger className="bg-gray-950 border-gray-800 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-black border-gray-800">
                    {expenseTypes.map(t => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}
                  </SelectContent>
                </Select>
                <Input placeholder="Description" value={form.description} onChange={(e) => setForm({...form, description: e.target.value})} className="bg-gray-950 border-gray-800 text-white" />
                <Input placeholder="Amount ($)" type="number" step="0.01" value={form.amount} onChange={(e) => setForm({...form, amount: e.target.value})} className="bg-gray-950 border-gray-800 text-white" />
                <Input type="date" value={form.date} onChange={(e) => setForm({...form, date: e.target.value})} className="bg-gray-950 border-gray-800 text-white" />
                <Select value={form.category} onValueChange={(val) => setForm({...form, category: val})}>
                  <SelectTrigger className="bg-gray-950 border-gray-800 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-black border-gray-800">
                    <SelectItem value="one_time">One-time</SelectItem>
                    <SelectItem value="recurring">Recurring</SelectItem>
                  </SelectContent>
                </Select>
                <Input placeholder="Payment Method (optional)" value={form.payment_method} onChange={(e) => setForm({...form, payment_method: e.target.value})} className="bg-gray-950 border-gray-800 text-white" />
                <Input placeholder="Notes (optional)" value={form.notes} onChange={(e) => setForm({...form, notes: e.target.value})} className="bg-gray-950 border-gray-800 text-white" />
                <Button onClick={() => addMutation.mutate(form)} className="w-full bg-[#0066B1] hover:bg-[#0055A0]" disabled={!form.amount}>Log Expense</Button>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {sortedExpenses.length > 0 ? (
        <div className="space-y-2">
          {sortedExpenses.map((expense) => (
            <motion.div key={expense.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-gray-950 border border-gray-900 p-4 hover:border-gray-800 transition group">
              <div className="flex justify-between items-start">
                <div className="flex gap-3 flex-1">
                  <DollarSign className="w-5 h-5 text-[#0066B1] flex-shrink-0 mt-1" />
                  <div>
                    <h4 className="text-white font-light uppercase tracking-wide">{expense.expense_type.replace(/_/g, ' ')}</h4>
                    <p className="text-gray-500 text-sm">{expense.description}</p>
                    <div className="flex gap-4 text-xs text-gray-500 mt-2">
                      <span>${expense.amount.toFixed(2)}</span>
                      <span>{new Date(expense.date).toLocaleDateString()}</span>
                      {expense.category === 'recurring' && <span className="text-[#0066B1]">Recurring</span>}
                      {expense.payment_method && <span>{expense.payment_method}</span>}
                    </div>
                  </div>
                </div>
                {isOwner && (
                  <button onClick={() => deleteMutation.mutate(expense.id)} className="text-gray-500 hover:text-[#E22718] transition opacity-0 group-hover:opacity-100">
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            </motion.div>
          ))}
        </div>
      ) : (
        <div className="bg-gray-950 border border-gray-900 p-6 text-center text-gray-500 text-sm">No expenses logged</div>
      )}
    </div>
  );
}