import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { AlertCircle, Plus, Trash2, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';

export default function InsuranceSection({ carId, garageId, userEmail, isOwner }) {
  const [isOpen, setIsOpen] = useState(false);
  const [form, setForm] = useState({
    insurance_type: 'comprehensive',
    provider: '',
    policy_number: '',
    expiry_date: '',
    premium_amount: '',
    registration_expiry: '',
    renewal_reminder: true,
    notes: ''
  });
  const queryClient = useQueryClient();

  const { data: insurances = [] } = useQuery({
    queryKey: ['insurance', carId],
    queryFn: () => base44.entities.CarInsurance.filter({ car_id: carId }),
    enabled: !!carId,
  });

  const addMutation = useMutation({
    mutationFn: (data) => base44.entities.CarInsurance.create({
      car_id: carId,
      garage_id: garageId,
      owner_email: userEmail,
      ...data,
      premium_amount: parseFloat(data.premium_amount) || 0
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['insurance'] });
      setForm({
        insurance_type: 'comprehensive',
        provider: '',
        policy_number: '',
        expiry_date: '',
        premium_amount: '',
        registration_expiry: '',
        renewal_reminder: true,
        notes: ''
      });
      setIsOpen(false);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.CarInsurance.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['insurance'] }),
  });

  const getExpiryDays = (date) => {
    const days = Math.ceil((new Date(date) - new Date()) / (1000 * 60 * 60 * 24));
    return days;
  };

  const isExpired = (date) => getExpiryDays(date) < 0;
  const isExpiring = (date) => {
    const days = getExpiryDays(date);
    return days >= 0 && days <= 30;
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-xl font-light uppercase tracking-wider">Insurance & Registration</h3>
        {isOwner && (
          <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>
              <Button className="bg-[#0066B1] hover:bg-[#0055A0]">
                <Plus className="w-4 h-4 mr-2" />
                Add Policy
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-black border-gray-900">
              <DialogHeader>
                <DialogTitle className="text-white">Add Insurance Policy</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <Select value={form.insurance_type} onValueChange={(val) => setForm({...form, insurance_type: val})}>
                  <SelectTrigger className="bg-gray-950 border-gray-800 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-black border-gray-800">
                    <SelectItem value="comprehensive">Comprehensive</SelectItem>
                    <SelectItem value="third_party_fire_theft">Third Party Fire & Theft</SelectItem>
                    <SelectItem value="third_party">Third Party</SelectItem>
                  </SelectContent>
                </Select>
                <Input placeholder="Provider" value={form.provider} onChange={(e) => setForm({...form, provider: e.target.value})} className="bg-gray-950 border-gray-800 text-white" />
                <Input placeholder="Policy Number" value={form.policy_number} onChange={(e) => setForm({...form, policy_number: e.target.value})} className="bg-gray-950 border-gray-800 text-white" />
                <div>
                  <label className="text-xs text-gray-400 mb-2 block">Expiry Date</label>
                  <Input type="date" value={form.expiry_date} onChange={(e) => setForm({...form, expiry_date: e.target.value})} className="bg-gray-950 border-gray-800 text-white" />
                </div>
                <Input placeholder="Annual Premium ($)" type="number" step="0.01" value={form.premium_amount} onChange={(e) => setForm({...form, premium_amount: e.target.value})} className="bg-gray-950 border-gray-800 text-white" />
                <div>
                  <label className="text-xs text-gray-400 mb-2 block">Registration Expiry (optional)</label>
                  <Input type="date" value={form.registration_expiry} onChange={(e) => setForm({...form, registration_expiry: e.target.value})} className="bg-gray-950 border-gray-800 text-white" />
                </div>
                <Input placeholder="Notes (optional)" value={form.notes} onChange={(e) => setForm({...form, notes: e.target.value})} className="bg-gray-950 border-gray-800 text-white" />
                <Button onClick={() => addMutation.mutate(form)} className="w-full bg-[#0066B1] hover:bg-[#0055A0]" disabled={!form.provider || !form.expiry_date}>Add Policy</Button>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {insurances.length > 0 ? (
        <div className="space-y-2">
          {insurances.map((ins) => {
            const expDays = getExpiryDays(ins.expiry_date);
            const regDays = ins.registration_expiry ? getExpiryDays(ins.registration_expiry) : null;
            return (
              <div key={ins.id} className={`border p-4 group transition ${
                isExpired(ins.expiry_date) ? 'bg-red-950 border-red-900' : 
                isExpiring(ins.expiry_date) ? 'bg-yellow-950 border-yellow-900' : 
                'bg-gray-950 border-gray-900 hover:border-gray-800'
              }`}>
                <div className="flex justify-between items-start">
                  <div className="flex gap-3 flex-1">
                    {(isExpired(ins.expiry_date) || (regDays && isExpiring(ins.registration_expiry))) && (
                      <AlertCircle className="w-5 h-5 text-[#E22718] flex-shrink-0 mt-1" />
                    )}
                    <div>
                      <h4 className="text-white font-light uppercase tracking-wide">{ins.provider}</h4>
                      <p className="text-gray-500 text-sm">{ins.insurance_type.replace(/_/g, ' ')}</p>
                      <div className="flex gap-4 text-xs text-gray-500 mt-2">
                        <span className="flex items-center gap-1"><Calendar className="w-3 h-3" />Expires: {new Date(ins.expiry_date).toLocaleDateString()}</span>
                        {ins.premium_amount && <span>${ins.premium_amount.toFixed(2)}/year</span>}
                        {regDays !== null && <span className={regDays < 0 ? 'text-[#E22718]' : ''}>Reg: {new Date(ins.registration_expiry).toLocaleDateString()}</span>}
                      </div>
                    </div>
                  </div>
                  {isOwner && (
                    <button onClick={() => deleteMutation.mutate(ins.id)} className="text-gray-500 hover:text-[#E22718] transition opacity-0 group-hover:opacity-100">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="bg-gray-950 border border-gray-900 p-6 text-center text-gray-500 text-sm">No insurance policies</div>
      )}
    </div>
  );
}