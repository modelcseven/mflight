import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { 
  Search, 
  Home, 
  Users, 
  Tv, 
  ShoppingBag, 
  Gamepad2,
  Menu,
  MessageCircle,
  Bell,
  Grid3X3,
  ChevronDown,
  LogOut,
  Settings,
  HelpCircle,
  Moon,
  Gauge,
  MapPin
} from 'lucide-react';
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from '@/components/ui/dropdown-menu';
import { Input } from '@/components/ui/input';
import { base44 } from '@/api/base44Client';
import { Badge } from '@/components/ui/badge';

const navItems = [
  { icon: Home, label: 'Home', page: 'Home' },
  { icon: Gauge, label: 'Models', page: 'BMWModels' },
  { icon: Gauge, label: 'Garages', page: 'Garages' },
  { icon: MapPin, label: 'Community Map', page: 'CommunityMap' },
  { icon: Users, label: 'Friends', page: 'Friends' },
];

export default function Navbar({ user, notificationCount, messageCount }) {
  const [searchQuery, setSearchQuery] = useState('');
  
  const avatar = user?.avatar || `https://ui-avatars.com/api/?name=${user?.full_name || 'User'}&background=random`;

  const handleLogout = async () => {
    await base44.auth.logout();
  };

  return (
    <header className="fixed top-0 left-0 right-0 h-14 bg-gray-900 border-b border-gray-800 z-50 px-4">
      <div className="h-full max-w-[1920px] mx-auto flex items-center justify-between">
        {/* Left Section */}
        <div className="flex items-center gap-2">
          <Link to={createPageUrl('Home')} className="flex-shrink-0">
            <div className="w-10 h-10 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-lg flex items-center justify-center font-bold text-white text-lg">
              E
            </div>
          </Link>
          <div className="relative hidden md:block">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <Input
              placeholder="Search Facebook"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-60 pl-10 bg-gray-800 border-gray-700 rounded-full focus-visible:ring-0 text-white placeholder-gray-400"
            />
          </div>
          <button className="md:hidden p-2 bg-gray-100 rounded-full">
            <Search className="w-5 h-5 text-gray-600" />
          </button>
        </div>

        {/* Center Navigation */}
        <nav className="hidden md:flex items-center gap-2 absolute left-1/2 -translate-x-1/2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = window.location.pathname.includes(item.page);
            
            const content = (
              <div
                className={`px-10 py-2 rounded-lg transition-colors relative group ${
                  isActive 
                    ? 'text-cyan-400' 
                    : 'text-gray-400 hover:text-cyan-400'
                }`}
              >
                <Icon className="w-6 h-6" />
                {isActive && (
                  <div className="absolute bottom-0 left-0 right-0 h-[3px] bg-cyan-400 rounded-t-full" />
                )}
                <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-3 py-1.5 bg-gray-800 text-white text-xs rounded-lg opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap">
                  {item.label}
                </div>
              </div>
            );

            return item.page ? (
              <Link key={item.label} to={createPageUrl(item.page)}>
                {content}
              </Link>
            ) : (
              <div key={item.label} className="cursor-pointer">{content}</div>
            );
          })}
        </nav>

        {/* Right Section */}
        <div className="flex items-center gap-2">
          <button className="p-2 bg-gray-800 hover:bg-gray-700 rounded-full transition-colors hidden md:flex">
            <Menu className="w-5 h-5 text-gray-300" />
          </button>
          
          <Link 
            to={createPageUrl('Messages')} 
            className="relative p-2 bg-gray-800 hover:bg-gray-700 rounded-full transition-colors"
          >
            <MessageCircle className="w-5 h-5 text-gray-300" />
            {messageCount > 0 && (
              <Badge className="absolute -top-1 -right-1 h-5 min-w-[20px] flex items-center justify-center bg-red-500 text-white text-xs rounded-full px-1">
                {messageCount}
              </Badge>
            )}
          </Link>
          
          <Link 
            to={createPageUrl('Notifications')} 
            className="relative p-2 bg-gray-800 hover:bg-gray-700 rounded-full transition-colors"
          >
            <Bell className="w-5 h-5 text-gray-300" />
            {notificationCount > 0 && (
              <Badge className="absolute -top-1 -right-1 h-5 min-w-[20px] flex items-center justify-center bg-red-500 text-white text-xs rounded-full px-1">
                {notificationCount}
              </Badge>
            )}
          </Link>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="relative">
                <img
                  src={avatar}
                  alt={user?.full_name}
                  className="w-10 h-10 rounded-full object-cover border-2 border-transparent hover:border-gray-200 transition-colors"
                />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-80 p-2 bg-gray-800 border-gray-700">
              <Link to={createPageUrl(`Profile?email=${user?.email}`)}>
                <DropdownMenuItem className="flex items-center gap-3 p-3 cursor-pointer">
                  <img
                    src={avatar}
                    alt={user?.full_name}
                    className="w-10 h-10 rounded-full object-cover"
                  />
                  <div>
                    <p className="font-semibold text-white">{user?.full_name}</p>
                    <p className="text-sm text-gray-400">See your profile</p>
                  </div>
                </DropdownMenuItem>
              </Link>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="flex items-center gap-3 p-3 cursor-pointer text-gray-300 hover:bg-gray-700">
                <div className="w-9 h-9 bg-gray-700 rounded-full flex items-center justify-center">
                  <Settings className="w-5 h-5 text-cyan-400" />
                </div>
                <span className="font-medium">Settings & privacy</span>
              </DropdownMenuItem>
              <DropdownMenuItem className="flex items-center gap-3 p-3 cursor-pointer text-gray-300 hover:bg-gray-700">
                <div className="w-9 h-9 bg-gray-700 rounded-full flex items-center justify-center">
                  <HelpCircle className="w-5 h-5 text-cyan-400" />
                </div>
                <span className="font-medium">Help & support</span>
              </DropdownMenuItem>
              <DropdownMenuItem className="flex items-center gap-3 p-3 cursor-pointer text-gray-300 hover:bg-gray-700">
                <div className="w-9 h-9 bg-gray-700 rounded-full flex items-center justify-center">
                  <Moon className="w-5 h-5 text-cyan-400" />
                </div>
                <span className="font-medium">Display & accessibility</span>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem 
                onClick={handleLogout}
                className="flex items-center gap-3 p-3 cursor-pointer text-gray-300 hover:bg-gray-700"
              >
                <div className="w-9 h-9 bg-gray-700 rounded-full flex items-center justify-center">
                  <LogOut className="w-5 h-5 text-cyan-400" />
                </div>
                <span className="font-medium">Log Out</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}