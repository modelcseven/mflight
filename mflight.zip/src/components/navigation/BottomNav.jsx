import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Home, Gauge, MapPin, Users, MessageCircle, Bell, User } from 'lucide-react';

export default function BottomNav({ notificationCount, messageCount }) {
  const navItems = [
    { icon: Home, label: 'Home', page: 'Home' },
    { icon: Gauge, label: 'Garages', page: 'Garages' },
    { icon: MapPin, label: 'Map', page: 'CommunityMap' },
    { icon: Users, label: 'Groups', page: 'Groups' },
    { icon: User, label: 'Profile', page: 'Profile' }
  ];

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-gray-800 border-t border-gray-700 z-40">
      <div className="flex justify-around items-center h-16">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = window.location.pathname.includes(item.page);
          
          return (
            <Link
              key={item.page}
              to={createPageUrl(item.page)}
              className={`flex flex-col items-center justify-center w-full h-full transition-colors ${
                isActive ? 'text-cyan-400' : 'text-gray-400 hover:text-gray-300'
              }`}
            >
              <Icon className="w-6 h-6" />
              <span className="text-xs mt-1">{item.label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}