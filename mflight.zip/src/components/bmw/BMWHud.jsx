import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Navigation, Bluetooth, Wifi, Battery, Volume2, Fan, Droplet } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

// Event data
const upcomingEvents = [
  {
    id: 1,
    name: 'BMW M Winter Track Day',
    date: new Date(2026, 0, 25, 9, 0),
    location: 'Nürburgring, Germany',
    address: 'Nürburgring Boulevard, 53520 Nürburg, Germany'
  },
  {
    id: 2,
    name: 'M Performance Meet & Greet',
    date: new Date(2026, 1, 8, 14, 0),
    location: 'BMW Welt München',
    address: 'Am Olympiapark 1, 80809 München, Germany'
  },
  {
    id: 3,
    name: 'Mountain Road Tour',
    date: new Date(2026, 1, 22, 8, 0),
    location: 'Swiss Alps Route',
    address: 'Grimselpass, 3864 Guttannen, Switzerland'
  },
  {
    id: 4,
    name: 'M Tech Workshop',
    date: new Date(2026, 2, 5, 10, 0),
    location: 'Turner Motorsport HQ',
    address: '29 Cobble Hill Rd, Amesbury, MA 01913, USA'
  }
];

export default function BMWHud() {
  const [speed, setSpeed] = useState(120);
  const [rpm, setRpm] = useState(4500);
  const [gear, setGear] = useState('D');
  const [fuel, setFuel] = useState(75);
  const [boost, setBoost] = useState(1.8);
  const [gForce, setGForce] = useState(0.9);
  const [torque, setTorque] = useState(750);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [turnSignal, setTurnSignal] = useState('left');
  
  // Performance Metrics
  const [currentLapTime, setCurrentLapTime] = useState(0);
  const [bestLapTime, setBestLapTime] = useState(94.3);
  const [zeroToSixty, setZeroToSixty] = useState(3.8);
  const [topSpeed, setTopSpeed] = useState(240);
  const [brakingDistance, setBrakingDistance] = useState(32);
  const [quarterMile, setQuarterMile] = useState(11.8);
  const [lateralG, setLateralG] = useState(1.2);
  const [showPerformanceHistory, setShowPerformanceHistory] = useState(false);
  const [showNavigation, setShowNavigation] = useState(false);
  const [navigationExpanded, setNavigationExpanded] = useState(false);
  const [editingDestination, setEditingDestination] = useState(false);
  const [isNavigating, setIsNavigating] = useState(false);

  // Get next upcoming event
  const nextEvent = upcomingEvents
    .filter(event => event.date > new Date())
    .sort((a, b) => a.date - b.date)[0];

  const [destinationInput, setDestinationInput] = useState(nextEvent?.address || 'Nürburgring Nordschleife');
  
  const [performanceHistory] = useState([
    { date: '2025-12-15', lap: 94.3, zeroSixty: 3.8, topSpeed: 240, braking: 32, quarterMile: 11.8 },
    { date: '2025-12-10', lap: 95.7, zeroSixty: 3.9, topSpeed: 238, braking: 33, quarterMile: 12.1 },
    { date: '2025-12-05', lap: 96.1, zeroSixty: 4.0, topSpeed: 235, braking: 34, quarterMile: 12.3 },
    { date: '2025-11-28', lap: 97.2, zeroSixty: 4.1, topSpeed: 232, braking: 35, quarterMile: 12.5 }
  ]);
  
  const [navigationData, setNavigationData] = useState({
    destination: nextEvent?.address || 'Nürburgring Nordschleife',
    eventName: nextEvent?.name || null,
    distance: '487 km',
    eta: '4h 32m',
    nextTurn: 'Right in 850m',
    currentSpeed: 120
  });

  const handleStartNavigation = () => {
    if (destinationInput.trim()) {
      setNavigationData({ ...navigationData, destination: destinationInput });
      setEditingDestination(false);
      setIsNavigating(true);
      window.open(`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(destinationInput)}&travelmode=driving`, '_blank');
    }
  };

  useEffect(() => {
    const interval = setInterval(() => {
      setSpeed(prev => Math.max(0, Math.min(prev + (Math.random() - 0.5) * 5, 240)));
      setRpm(prev => Math.max(0, Math.min(prev + (Math.random() - 0.5) * 200, 8000)));
      setCurrentTime(new Date());
      setCurrentLapTime(prev => prev + 0.1);
    }, 100);
    return () => clearInterval(interval);
  }, []);

  const speedAngle = -135 + (speed / 300) * 270;
  const rpmAngle = -135 + (rpm / 8000) * 270;

  return (
    <div className="relative w-full h-full bg-transparent overflow-hidden">
      {/* Ambient Lighting Background */}
      <div className="absolute inset-0">
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-red-600 to-transparent opacity-60" />
        <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-blue-900/30 to-transparent" />
        <div className="absolute top-1/4 left-0 w-64 h-64 bg-blue-500/10 rounded-full blur-[120px]" />
        <div className="absolute top-1/4 right-0 w-64 h-64 bg-red-500/10 rounded-full blur-[120px]" />
      </div>

      {/* Subtle Scan Lines */}
      <div className="absolute inset-0 opacity-[0.02]" style={{
        backgroundImage: 'repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(255,255,255,0.03) 2px, rgba(255,255,255,0.03) 4px)'
      }} />

      {/* Main Instrument Cluster */}
      <div className="relative z-10 h-full flex flex-col items-center justify-center px-4 md:px-8 lg:px-12 py-4 md:py-6 lg:py-8">
        


        {/* HUD Projection Overlay - Responsive */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, type: "spring", damping: 20 }}
          className="absolute top-16 md:top-24 left-1/2 -translate-x-1/2 w-[90%] max-w-[600px] h-auto aspect-[3.3/1]"
        >
          {/* HUD Glass Effect */}
          <div className="relative w-full h-full backdrop-blur-sm bg-gradient-to-b from-white/5 via-black/10 to-transparent rounded-lg" style={{
            background: 'linear-gradient(135deg, rgba(255,255,255,0.03) 0%, rgba(0,0,0,0.15) 100%)',
            backdropFilter: 'blur(4px) saturate(120%)',
            WebkitBackdropFilter: 'blur(4px) saturate(120%)'
          }}>
            {/* HUD Content - Centered */}
            <div className="absolute inset-0 p-3 md:p-6 flex flex-col items-center justify-center">
              {/* Central Speed Display */}
              <motion.div
                key={Math.round(speed)}
                initial={{ scale: 1.1, opacity: 0.8 }}
                animate={{ scale: 1, opacity: 1 }}
                className="text-4xl md:text-6xl lg:text-7xl font-light text-green-400 tracking-wider filter drop-shadow-[0_0_20px_rgba(34,197,94,0.6)]"
                style={{ fontVariantNumeric: 'tabular-nums' }}
              >
                {Math.round(speed)}
              </motion.div>
              <div className="text-sm md:text-lg lg:text-xl text-white/60 mt-1">km/h</div>

              {/* Bottom Info Row */}
              <div className="flex items-center gap-3 md:gap-6 mt-2 md:mt-3 text-xs md:text-sm">
                <div className="text-cyan-400">G: {gForce.toFixed(2)}</div>
                <div className="hidden md:flex gap-2">
                  {[2.4, 2.4, 2.4, 2.4].map((pressure, i) => (
                    <div key={i} className="text-green-400">⬤ {pressure}</div>
                  ))}
                </div>
              </div>

              {/* Left: ACC & Mode - repositioned */}
              <div className="absolute left-2 md:left-6 top-2 md:top-6 space-y-1 md:space-y-2 scale-75 md:scale-100 origin-top-left">
                <div className="text-amber-400 text-base md:text-xl filter drop-shadow-[0_0_10px_rgba(251,191,36,0.5)]">
                  ACC 130
                </div>
                <div className="hidden md:flex items-center gap-2 text-green-400">
                  <div className="w-8 h-6 border-2 border-green-400 rounded-sm flex items-center justify-center">
                    <div className="w-1.5 h-1.5 bg-green-400 rounded-full" />
                  </div>
                  <div className="h-1 w-12 bg-green-400/30 rounded-full">
                    <div className="h-full w-2/3 bg-green-400 rounded-full" />
                  </div>
                </div>
                <div className="px-2 md:px-3 py-1 bg-red-600/20 border border-red-500/60 text-red-400 text-xs md:text-sm font-medium backdrop-blur-md">
                  SPORT+
                </div>
              </div>

              {/* Right: Navigation Arrow */}
              <div className="absolute right-2 md:right-6 top-2 md:top-6 text-amber-400 scale-75 md:scale-100 origin-top-right">
                <motion.div
                  animate={{ x: [0, 5, 0] }}
                  transition={{ repeat: Infinity, duration: 1.5 }}
                  className="text-2xl md:text-4xl filter drop-shadow-[0_0_15px_rgba(251,191,36,0.6)]"
                >
                  ➜
                </motion.div>
                <div className="text-xs text-white/60 mt-1 text-center">250m</div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Main Digital Cluster Display */}
        <motion.div 
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3, type: "spring", damping: 25 }}
          className="relative w-full max-w-[1800px] h-auto aspect-[3/1] portrait:aspect-[1/1.2] mt-32 md:mt-40 lg:mt-48"
        >
          <div className="absolute inset-0 backdrop-blur-lg bg-gradient-to-b from-black/40 via-black/50 to-black/60 rounded-3xl shadow-[0_0_60px_rgba(0,0,0,0.8)]" style={{
            background: 'linear-gradient(145deg, rgba(255,255,255,0.03) 0%, rgba(0,0,0,0.6) 50%, rgba(255,255,255,0.02) 100%)',
            backdropFilter: 'blur(20px) saturate(120%)',
            WebkitBackdropFilter: 'blur(20px) saturate(120%)'
          }}>
            {/* Reduced Glass Effect */}
            <div className="absolute inset-0 rounded-3xl" style={{
              background: 'radial-gradient(circle at center, rgba(255,255,255,0.02) 0%, rgba(0,0,0,0.2) 100%)',
              backdropFilter: 'blur(15px)',
              WebkitBackdropFilter: 'blur(15px)'
            }} />

            <div className="relative z-10 h-full flex flex-col portrait:flex-col landscape:flex-row items-center justify-between px-4 md:px-8 lg:px-16 py-4 md:py-6 gap-4 md:gap-6 lg:gap-8">

              {/* Left Speedometer */}
              <motion.div
                initial={{ x: -100, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: 0.2, type: "spring" }}
                className="relative w-48 h-48 md:w-64 md:h-64 lg:w-80 lg:h-80 xl:w-96 xl:h-96 flex-shrink-0"
              >
                {/* Glass Container */}
                <div className="absolute inset-0 backdrop-blur-lg bg-white/[0.03] rounded-full shadow-[0_0_60px_rgba(6,182,212,0.2)]" style={{
                  background: 'radial-gradient(circle at 30% 30%, rgba(255,255,255,0.05) 0%, rgba(0,0,0,0.4) 100%)',
                  backdropFilter: 'blur(20px) saturate(120%)',
                  WebkitBackdropFilter: 'blur(20px) saturate(120%)'
                }}>
                  {/* Speed Gauge Background */}
                  <svg className="absolute inset-0 w-full h-full -rotate-[135deg]" viewBox="0 0 200 200">
                    <defs>
                      <linearGradient id="speedGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.8" />
                        <stop offset="50%" stopColor="#8b5cf6" stopOpacity="0.9" />
                        <stop offset="100%" stopColor="#ec4899" stopOpacity="1" />
                      </linearGradient>
                      <filter id="glow">
                        <feGaussianBlur stdDeviation="2" result="coloredBlur"/>
                        <feMerge>
                          <feMergeNode in="coloredBlur"/>
                          <feMergeNode in="SourceGraphic"/>
                        </feMerge>
                      </filter>
                    </defs>
                    
                    {/* Background Arc */}
                    <circle
                      cx="100" cy="100" r="85"
                      fill="none"
                      stroke="rgba(255,255,255,0.05)"
                      strokeWidth="6"
                      strokeDasharray="424 424"
                      strokeDashoffset="106"
                      strokeLinecap="round"
                    />
                    
                    {/* Active Speed Arc */}
                    <motion.circle
                      cx="100" cy="100" r="85"
                      fill="none"
                      stroke="url(#speedGradient)"
                      strokeWidth="6"
                      strokeDasharray="424 424"
                      strokeDashoffset={106 + (318 - (318 * speed / 300))}
                      strokeLinecap="round"
                      filter="url(#glow)"
                      initial={{ strokeDashoffset: 424 }}
                      animate={{ strokeDashoffset: 106 + (318 - (318 * speed / 300)) }}
                      transition={{ type: "spring", stiffness: 50 }}
                    />

                    {/* Scale Marks */}
                    {[0, 60, 120, 180, 240, 300].map((mark, i) => {
                      const angle = -135 + (mark / 300) * 270;
                      const rad = (angle * Math.PI) / 180;
                      const x1 = 100 + 78 * Math.cos(rad);
                      const y1 = 100 + 78 * Math.sin(rad);
                      const x2 = 100 + 85 * Math.cos(rad);
                      const y2 = 100 + 85 * Math.sin(rad);
                      return (
                        <line
                          key={i}
                          x1={x1} y1={y1} x2={x2} y2={y2}
                          stroke={mark > 240 ? "#ef4444" : "rgba(255,255,255,0.3)"}
                          strokeWidth="2"
                        />
                      );
                    })}
                  </svg>

                  {/* Center Speed Display */}
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <motion.div
                      key={Math.round(speed)}
                      initial={{ scale: 1.2, opacity: 0.7 }}
                      animate={{ scale: 1, opacity: 1 }}
                      className="text-7xl font-extralight text-white tracking-tight"
                      style={{
                        fontVariantNumeric: 'tabular-nums',
                        textShadow: '0 0 30px rgba(255,255,255,0.3)'
                      }}
                    >
                      {Math.round(speed)}
                    </motion.div>
                    <div className="text-sm text-white/40 tracking-widest mt-1">km/h</div>
                  </div>

                  {/* Scale Labels */}
                  <div className="absolute top-8 left-1/2 -translate-x-1/2 text-xs text-white/40">300</div>
                  <div className="absolute bottom-8 left-8 text-xs text-white/40">0</div>
                  <div className="absolute bottom-8 right-8 text-xs text-white/40">60</div>
                </div>
              </motion.div>

              {/* Center Info Display */}
              <motion.div
                initial={{ y: 50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.4 }}
                className="flex flex-col items-center gap-3 md:gap-4 lg:gap-6"
              >
                {/* Gear Indicator */}
                <div className="backdrop-blur-lg bg-white/[0.03] px-6 py-4 md:px-8 md:py-6 lg:px-12 lg:py-8 rounded-2xl shadow-[0_0_30px_rgba(249,115,22,0.15)]">
                  <motion.div
                    key={gear}
                    initial={{ scale: 1.3, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    className="text-4xl md:text-6xl lg:text-8xl font-bold text-orange-500"
                    style={{ textShadow: '0 0 40px rgba(249,115,22,0.6)' }}
                  >
                    {gear}
                  </motion.div>
                </div>

                {/* M Performance Metrics */}
                <div className="grid grid-cols-3 gap-2 md:gap-3 lg:gap-4">
                  {/* Boost */}
                  <div className="backdrop-blur-lg bg-white/[0.02] px-2 py-2 md:px-3 md:py-2.5 lg:px-4 lg:py-3 rounded-lg text-center">
                    <div className="text-[10px] md:text-xs text-yellow-400/60 mb-1">BOOST</div>
                    <motion.div
                      animate={{ color: boost > 2.0 ? '#ef4444' : '#facc15' }}
                      className="text-sm md:text-lg lg:text-xl font-mono"
                    >
                      {boost.toFixed(1)}
                    </motion.div>
                    <div className="text-[8px] md:text-[10px] text-white/30">bar</div>
                  </div>

                  {/* G-Force */}
                  <div className="backdrop-blur-lg bg-white/[0.02] px-2 py-2 md:px-3 md:py-2.5 lg:px-4 lg:py-3 rounded-lg text-center">
                    <div className="text-[10px] md:text-xs text-cyan-400/60 mb-1">G-FORCE</div>
                    <div className="text-sm md:text-lg lg:text-xl font-mono text-cyan-400">{gForce.toFixed(1)}</div>
                    <div className="text-[8px] md:text-[10px] text-white/30">G</div>
                  </div>

                  {/* Torque */}
                  <div className="backdrop-blur-lg bg-white/[0.02] px-2 py-2 md:px-3 md:py-2.5 lg:px-4 lg:py-3 rounded-lg text-center">
                    <div className="text-[10px] md:text-xs text-purple-400/60 mb-1">TORQUE</div>
                    <div className="text-sm md:text-lg lg:text-xl font-mono text-purple-400">{torque}</div>
                    <div className="text-[8px] md:text-[10px] text-white/30">Nm</div>
                  </div>
                </div>

                {/* Fuel & Temp */}
                <div className="flex gap-2 md:gap-4">
                  <div className="backdrop-blur-lg bg-white/[0.02] px-3 py-2 md:px-6 md:py-2 rounded-lg">
                    <div className="flex items-center gap-2">
                      <Droplet className="w-3 h-3 md:w-4 md:h-4 text-cyan-400" />
                      <div className="h-2 w-12 md:w-20 bg-white/10 rounded-full overflow-hidden">
                        <div className="h-full bg-gradient-to-r from-cyan-400 to-blue-500" style={{ width: `${fuel}%` }} />
                      </div>
                      <span className="text-[10px] md:text-xs text-white/60">{fuel}%</span>
                    </div>
                  </div>
                </div>
              </motion.div>

              {/* Right Tachometer */}
              <motion.div
                initial={{ x: 100, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: 0.2, type: "spring" }}
                className="relative w-48 h-48 md:w-64 md:h-64 lg:w-80 lg:h-80 xl:w-96 xl:h-96 flex-shrink-0"
              >
                {/* Glass Container */}
                <div className="absolute inset-0 backdrop-blur-lg bg-white/[0.03] rounded-full shadow-[0_0_60px_rgba(239,68,68,0.2)]" style={{
                  background: 'radial-gradient(circle at 30% 30%, rgba(255,255,255,0.05) 0%, rgba(0,0,0,0.4) 100%)',
                  backdropFilter: 'blur(20px) saturate(120%)',
                  WebkitBackdropFilter: 'blur(20px) saturate(120%)'
                }}>
                  {/* RPM Gauge */}
                  <svg className="absolute inset-0 w-full h-full -rotate-[135deg]" viewBox="0 0 200 200">
                    <circle
                      cx="100" cy="100" r="85"
                      fill="none"
                      stroke="rgba(255,255,255,0.05)"
                      strokeWidth="6"
                      strokeDasharray="424 424"
                      strokeDashoffset="106"
                      strokeLinecap="round"
                    />
                    
                    <motion.circle
                      cx="100" cy="100" r="85"
                      fill="none"
                      stroke={rpm > 7200 ? "#ef4444" : "url(#speedGradient)"}
                      strokeWidth="6"
                      strokeDasharray="424 424"
                      strokeDashoffset={106 + (318 - (318 * rpm / 8000))}
                      strokeLinecap="round"
                      filter="url(#glow)"
                      animate={{
                        stroke: rpm > 7200 ? "#ef4444" : "url(#speedGradient)",
                        strokeDashoffset: 106 + (318 - (318 * rpm / 8000))
                      }}
                      transition={{ type: "spring", stiffness: 50 }}
                    />

                    {/* RPM Scale Marks */}
                    {[0, 2000, 4000, 6000, 7200, 8000].map((mark, i) => {
                      const angle = -135 + (mark / 8000) * 270;
                      const rad = (angle * Math.PI) / 180;
                      const x1 = 100 + 78 * Math.cos(rad);
                      const y1 = 100 + 78 * Math.sin(rad);
                      const x2 = 100 + 85 * Math.cos(rad);
                      const y2 = 100 + 85 * Math.sin(rad);
                      return (
                        <line
                          key={i}
                          x1={x1} y1={y1} x2={x2} y2={y2}
                          stroke={mark >= 7200 ? "#ef4444" : "rgba(255,255,255,0.3)"}
                          strokeWidth="2"
                        />
                      );
                    })}
                  </svg>

                  {/* Center RPM Display */}
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <div className="text-xs text-white/40 tracking-widest mb-2">RPM x1000</div>
                    <motion.div
                      key={Math.round(rpm / 100)}
                      initial={{ scale: 1.2, opacity: 0.7 }}
                      animate={{ 
                        scale: 1, 
                        opacity: 1,
                        color: rpm > 7200 ? '#ef4444' : '#ffffff'
                      }}
                      className="text-6xl font-extralight tracking-tight"
                      style={{
                        fontVariantNumeric: 'tabular-nums',
                        textShadow: rpm > 7200 ? '0 0 40px rgba(239,68,68,0.8)' : '0 0 30px rgba(255,255,255,0.3)'
                      }}
                    >
                      {(rpm / 1000).toFixed(1)}
                    </motion.div>
                  </div>

                  {/* RPM Labels */}
                  <div className="absolute top-8 left-1/2 -translate-x-1/2 text-xs text-white/40">8</div>
                  <div className="absolute bottom-8 left-8 text-xs text-white/40">0</div>
                  <div className="absolute top-12 right-12 text-xs text-red-500/60">REDLINE</div>
                </div>
              </motion.div>

            </div>
          </div>
        </motion.div>

        {/* Performance History Panel */}
        <AnimatePresence>
          {showPerformanceHistory && (
            <motion.div
              initial={{ x: -400, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: -400, opacity: 0 }}
              transition={{ type: "spring", damping: 25 }}
              className="absolute left-0 top-1/2 -translate-y-1/2 w-96 backdrop-blur-xl bg-black/80 border border-cyan-500/30 rounded-r-2xl shadow-[0_0_60px_rgba(6,182,212,0.3)] p-6"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl text-white font-light tracking-wider uppercase">Performance Log</h3>
                <button 
                  onClick={() => setShowPerformanceHistory(false)}
                  className="text-white/60 hover:text-white transition"
                >
                  ✕
                </button>
              </div>

              <div className="space-y-4">
                {performanceHistory.map((record, idx) => (
                  <motion.div
                    key={idx}
                    initial={{ x: -20, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: idx * 0.1 }}
                    className="backdrop-blur-lg bg-white/5 p-4 rounded-lg border border-white/10"
                  >
                    <div className="text-xs text-cyan-400 mb-2">{record.date}</div>
                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div>
                        <div className="text-white/40 text-xs">Best Lap</div>
                        <div className="text-white font-mono">{record.lap}s</div>
                      </div>
                      <div>
                        <div className="text-white/40 text-xs">0-60 mph</div>
                        <div className="text-white font-mono">{record.zeroSixty}s</div>
                      </div>
                      <div>
                        <div className="text-white/40 text-xs">Top Speed</div>
                        <div className="text-white font-mono">{record.topSpeed} km/h</div>
                      </div>
                      <div>
                        <div className="text-white/40 text-xs">Braking (100-0)</div>
                        <div className="text-white font-mono">{record.braking}m</div>
                      </div>
                      <div>
                        <div className="text-white/40 text-xs">1/4 Mile</div>
                        <div className="text-white font-mono">{record.quarterMile}s</div>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Navigation Overlay */}
        <AnimatePresence>
          {showNavigation && (
            <motion.div
              initial={{ x: 400, opacity: 0 }}
              animate={{ 
                x: 0, 
                opacity: 1,
                width: navigationExpanded ? '80%' : '384px'
              }}
              exit={{ x: 400, opacity: 0 }}
              transition={{ type: "spring", damping: 25 }}
              className="absolute right-0 top-1/2 -translate-y-1/2 backdrop-blur-xl bg-black/80 border border-amber-500/30 rounded-l-2xl shadow-[0_0_60px_rgba(251,191,36,0.3)] p-6"
              style={{ height: navigationExpanded ? '90%' : 'auto' }}
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl text-white font-light tracking-wider uppercase">Navigation</h3>
                <div className="flex items-center gap-2">
                  <button 
                    onClick={() => setNavigationExpanded(!navigationExpanded)}
                    className="text-white/60 hover:text-white transition text-xl"
                    title={navigationExpanded ? "Minimize" : "Maximize"}
                  >
                    {navigationExpanded ? '⊡' : '⊞'}
                  </button>
                  <button 
                    onClick={() => setShowNavigation(false)}
                    className="text-white/60 hover:text-white transition"
                  >
                    ✕
                  </button>
                </div>
              </div>

              <div className="space-y-6 h-full overflow-y-auto">
                {/* Destination */}
                <div className="backdrop-blur-lg bg-white/5 p-4 rounded-lg border border-white/10">
                  {navigationData.eventName && (
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-xs text-green-400 uppercase tracking-wider">📅 Next Event</span>
                      <span className="text-xs text-white/60">{navigationData.eventName}</span>
                    </div>
                  )}
                  <div className="text-xs text-amber-400 mb-2">DESTINATION</div>
                  {editingDestination ? (
                    <div className="space-y-3">
                      <input
                        type="text"
                        value={destinationInput}
                        onChange={(e) => setDestinationInput(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleStartNavigation()}
                        className="w-full bg-black/50 border border-amber-500/30 text-white px-3 py-2 rounded focus:outline-none focus:border-amber-500"
                        placeholder="Enter destination..."
                        autoFocus
                      />
                      <div className="flex gap-2">
                        <button
                          onClick={handleStartNavigation}
                          className="flex-1 bg-amber-500 hover:bg-amber-600 text-black font-medium px-4 py-2 rounded transition"
                        >
                          Start Navigation
                        </button>
                        <button
                          onClick={() => {
                            setEditingDestination(false);
                            setDestinationInput(navigationData.destination);
                          }}
                          className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded transition"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  ) : (
                    <>
                      <div 
                        onClick={() => setEditingDestination(true)}
                        className="text-lg text-white font-medium mb-2 cursor-pointer hover:text-amber-400 transition"
                      >
                        {navigationData.destination}
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4 text-sm text-white/60">
                          <span>{navigationData.distance}</span>
                          <span>•</span>
                          <span>ETA {navigationData.eta}</span>
                        </div>
                        <button
                          onClick={handleStartNavigation}
                          className={`flex items-center gap-2 px-4 py-1.5 rounded transition ${
                            isNavigating 
                              ? 'bg-green-500/20 border border-green-500/40 text-green-400' 
                              : 'bg-amber-500 hover:bg-amber-600 text-black font-medium'
                          }`}
                        >
                          {isNavigating ? (
                            <>
                              <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                              Active
                            </>
                          ) : (
                            <>
                              📍 Start GPS
                            </>
                          )}
                        </button>
                      </div>
                    </>
                  )}
                </div>

                {/* Google Maps Embed */}
                <div className="backdrop-blur-lg bg-white/5 rounded-lg border border-white/10 overflow-hidden" 
                     style={{ height: navigationExpanded ? 'calc(100% - 200px)' : '400px' }}>
                  <iframe
                    src={`https://www.google.com/maps/embed/v1/directions?key=AIzaSyBFw0Qbyq9zTFTd-tUY6dZWTgaQzuU17R8&origin=&destination=${encodeURIComponent(navigationData.destination)}&mode=driving`}
                    width="100%"
                    height="100%"
                    style={{ border: 0 }}
                    allowFullScreen=""
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                  />
                </div>

                {!navigationExpanded && (
                  <>
                    {/* Next Turn */}
                    <div className="backdrop-blur-lg bg-amber-500/10 p-4 rounded-lg border border-amber-500/30">
                      <div className="flex items-center gap-3">
                        <div className="text-4xl">↗️</div>
                        <div>
                          <div className="text-xs text-amber-400 mb-1">NEXT TURN</div>
                          <div className="text-lg text-white">{navigationData.nextTurn}</div>
                        </div>
                      </div>
                    </div>

                    {/* Route Preview */}
                    <div className="backdrop-blur-lg bg-white/5 p-4 rounded-lg border border-white/10">
                      <div className="text-xs text-white/40 mb-3 uppercase tracking-wider">Route Overview</div>
                      <div className="space-y-2">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 bg-green-500/20 border border-green-500/40 rounded-full flex items-center justify-center text-green-400 text-xs">1</div>
                          <div className="text-sm text-white/80">A3 - 245 km</div>
                        </div>
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 bg-amber-500/20 border border-amber-500/40 rounded-full flex items-center justify-center text-amber-400 text-xs">2</div>
                          <div className="text-sm text-white/80">A61 - 142 km</div>
                        </div>
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 bg-red-500/20 border border-red-500/40 rounded-full flex items-center justify-center text-red-400 text-xs">3</div>
                          <div className="text-sm text-white/80">B257 - 100 km</div>
                        </div>
                      </div>
                    </div>
                  </>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Control Buttons */}
        <div className="absolute left-2 md:left-6 top-1/2 -translate-y-1/2 flex flex-col gap-2 md:gap-3 z-50">
          <button
            onClick={() => setShowPerformanceHistory(!showPerformanceHistory)}
            className="w-10 h-10 md:w-12 md:h-12 backdrop-blur-lg bg-cyan-500/20 border border-cyan-500/40 rounded-full flex items-center justify-center text-cyan-400 hover:bg-cyan-500/30 transition shadow-[0_0_20px_rgba(6,182,212,0.3)] text-lg md:text-xl"
          >
            📊
          </button>
          <button
            onClick={() => setShowNavigation(!showNavigation)}
            className="w-10 h-10 md:w-12 md:h-12 backdrop-blur-lg bg-amber-500/20 border border-amber-500/40 rounded-full flex items-center justify-center text-amber-400 hover:bg-amber-500/30 transition shadow-[0_0_20px_rgba(251,191,36,0.3)] text-lg md:text-xl"
          >
            🗺️
          </button>
        </div>

        {/* Bottom Status Bar with Infotainment */}
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="absolute bottom-0 left-0 right-0 backdrop-blur-3xl bg-white/5 border-t border-white/5 shadow-[0_-20px_60px_rgba(0,0,0,0.5)]"
        >
          {/* Top Performance Strip */}
          <div className="h-12 md:h-14 lg:h-16 border-b border-white/5 px-3 md:px-6 lg:px-12">
            <div className="max-w-[1600px] mx-auto h-full flex items-center justify-between overflow-x-auto scrollbar-hide">
              <div className="flex items-center gap-3 md:gap-6 lg:gap-8 flex-shrink-0">
                {/* Current Lap Time */}
                <div className="flex items-center gap-2 md:gap-3">
                  <div className="text-[10px] md:text-xs text-white/40 uppercase tracking-wider whitespace-nowrap">Current</div>
                  <div className="text-base md:text-xl lg:text-2xl font-mono text-cyan-400 tabular-nums">
                    {currentLapTime.toFixed(1)}s
                  </div>
                </div>

                {/* Best Lap */}
                <div className="flex items-center gap-2 md:gap-3">
                  <div className="text-[10px] md:text-xs text-white/40 uppercase tracking-wider whitespace-nowrap">Best</div>
                  <div className="text-base md:text-xl lg:text-2xl font-mono text-green-400 tabular-nums">
                    {bestLapTime}s
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 md:gap-4 lg:gap-8 flex-shrink-0">
                {/* 0-60 mph */}
                <div className="backdrop-blur-lg bg-white/5 px-2 py-1.5 md:px-3 md:py-2 lg:px-4 lg:py-2 rounded-lg border border-yellow-500/20">
                  <div className="text-[10px] md:text-xs text-yellow-400/60 mb-0.5 whitespace-nowrap">0-60</div>
                  <div className="text-sm md:text-base lg:text-lg font-mono text-yellow-400 tabular-nums">{zeroToSixty}s</div>
                </div>

                {/* Top Speed */}
                <div className="backdrop-blur-lg bg-white/5 px-2 py-1.5 md:px-3 md:py-2 lg:px-4 lg:py-2 rounded-lg border border-purple-500/20">
                  <div className="text-[10px] md:text-xs text-purple-400/60 mb-0.5 whitespace-nowrap">Top</div>
                  <div className="text-sm md:text-base lg:text-lg font-mono text-purple-400 tabular-nums">{topSpeed}</div>
                </div>

                {/* Braking Distance - Hidden on small screens */}
                <div className="hidden md:block backdrop-blur-lg bg-white/5 px-3 py-2 lg:px-4 lg:py-2 rounded-lg border border-red-500/20">
                  <div className="text-xs text-red-400/60 mb-0.5 whitespace-nowrap">Brake</div>
                  <div className="text-base lg:text-lg font-mono text-red-400 tabular-nums">{brakingDistance}m</div>
                </div>

                {/* Quarter Mile */}
                <div className="backdrop-blur-lg bg-white/5 px-2 py-1.5 md:px-3 md:py-2 lg:px-4 lg:py-2 rounded-lg border border-green-500/20">
                  <div className="text-[10px] md:text-xs text-green-400/60 mb-0.5 whitespace-nowrap">1/4</div>
                  <div className="text-sm md:text-base lg:text-lg font-mono text-green-400 tabular-nums">{quarterMile}s</div>
                </div>

                {/* Lateral G - Hidden on small screens */}
                <div className="hidden lg:block backdrop-blur-lg bg-white/5 px-4 py-2 rounded-lg border border-cyan-500/20">
                  <div className="text-xs text-cyan-400/60 mb-0.5 whitespace-nowrap">Lat G</div>
                  <div className="text-lg font-mono text-cyan-400 tabular-nums">{lateralG}G</div>
                </div>
              </div>
            </div>
          </div>

          {/* Main Status Bar */}
          <div className="h-20 md:h-24 lg:h-32 px-3 md:px-6 lg:px-12">
          <div className="max-w-[1600px] mx-auto h-full flex flex-col md:flex-row items-center justify-between gap-3 md:gap-0">

            {/* Left: Time & Battery */}
            <div className="flex items-center gap-3 md:gap-6 lg:gap-8">
              <div className="text-xl md:text-2xl lg:text-3xl font-light text-white tracking-wider">
                {currentTime.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false })}
              </div>
              <div className="flex items-center gap-2">
                <Battery className="w-4 h-4 md:w-5 md:h-5 lg:w-6 lg:h-6 text-green-400" />
                <span className="text-sm md:text-base lg:text-xl text-green-400">83%</span>
              </div>
              <div className="hidden md:flex items-center gap-2 text-white/60 text-xs lg:text-sm">
                <span>14.1V</span>
                <span>•</span>
                <span>4.2bar</span>
              </div>
            </div>

            {/* Center: Climate & Location */}
            <div className="flex items-center gap-3 md:gap-6 lg:gap-8">
              <div className="flex items-center gap-2 md:gap-4 backdrop-blur-2xl bg-white/5 px-3 py-2 md:px-4 md:py-2.5 lg:px-6 lg:py-3 rounded-xl border border-cyan-500/20">
                <Navigation className="w-4 h-4 md:w-5 md:h-5 text-cyan-400" />
                <div>
                  <div className="text-sm md:text-base lg:text-lg text-white">Berlin</div>
                  <div className="text-[10px] md:text-xs text-white/40 hidden md:block">Partly Cloudy</div>
                </div>
                <div className="text-base md:text-xl lg:text-2xl text-cyan-400 ml-2 md:ml-4">18°C</div>
              </div>

              <div className="hidden lg:flex items-center gap-4">
                <div className="flex items-center gap-2 text-white/60">
                  <Fan className="w-4 h-4" />
                  <span className="text-sm">21°C</span>
                </div>
                <div className="h-8 w-px bg-white/20" />
                <div className="flex items-center gap-2 text-white/60">
                  <Fan className="w-4 h-4" />
                  <span className="text-sm">20°C</span>
                </div>
              </div>
            </div>

            {/* Right: Status */}
            <div className="flex items-center gap-3 md:gap-4 lg:gap-6">
              <div className="px-3 py-1.5 md:px-4 md:py-2 lg:px-6 lg:py-2 backdrop-blur-2xl bg-green-500/20 border border-green-500/60 text-green-400 text-xs md:text-sm lg:text-lg font-medium shadow-lg">
                READY
              </div>
              <div className="flex items-center gap-1.5 md:gap-2">
                <Navigation className="w-4 h-4 md:w-5 md:h-5 text-cyan-400" />
                <span className="text-sm md:text-base lg:text-xl text-white">491km</span>
              </div>
              <div className="hidden md:flex gap-2">
                <Wifi className="w-4 h-4 md:w-5 md:h-5 text-cyan-400" />
                <Bluetooth className="w-4 h-4 md:w-5 md:h-5 text-blue-400" />
              </div>
            </div>
          </div>
          </div>
        </motion.div>

      </div>

      {/* Red M Ambient Strip - Top */}
      <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-transparent via-red-600 to-transparent opacity-40 blur-sm" />
      
      {/* Blue Ambient Footwell Glow */}
      <div className="absolute bottom-32 left-0 w-64 h-64 bg-blue-500/20 rounded-full blur-[100px] opacity-60" />
      <div className="absolute bottom-32 right-0 w-64 h-64 bg-blue-500/20 rounded-full blur-[100px] opacity-60" />
    </div>
  );
}