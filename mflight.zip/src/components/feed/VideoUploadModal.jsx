import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Upload, CheckCircle2, AlertCircle, X } from 'lucide-react';

export default function VideoUploadModal({ open, onOpenChange, onUploadComplete, isUploading, uploadProgress }) {
  const [dragActive, setDragActive] = useState(false);

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    const files = e.dataTransfer.files;
    if (files && files[0]) {
      const file = files[0];
      if (file.type.startsWith('video/')) {
        onUploadComplete?.(file);
      }
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Upload Video</DialogTitle>
          <DialogDescription>
            Add a video to your post. Supported formats: MP4, WebM, Ogg
          </DialogDescription>
        </DialogHeader>

        {isUploading && (
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-[#E7F3FF] flex items-center justify-center">
                <Upload className="w-6 h-6 text-[#1877F2]" />
              </div>
              <div className="flex-1">
                <p className="font-semibold text-gray-900">Uploading video</p>
                <p className="text-sm text-gray-500">{uploadProgress}% uploaded</p>
              </div>
            </div>
            <Progress value={uploadProgress} className="h-2" />
          </div>
        )}

        {!isUploading && (
          <div
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
            className={`border-2 border-dashed rounded-xl p-8 text-center transition-colors cursor-pointer ${
              dragActive ? 'border-[#1877F2] bg-[#E7F3FF]' : 'border-gray-300 hover:border-[#1877F2]'
            }`}
          >
            <div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center mx-auto mb-3">
              <Upload className="w-8 h-8 text-gray-600" />
            </div>
            <p className="text-gray-900 font-semibold mb-1">Drag and drop your video</p>
            <p className="text-sm text-gray-500 mb-4">or click the button below to select a file</p>
            <Button className="bg-[#1877F2] hover:bg-[#166FE5]">
              Select Video
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}