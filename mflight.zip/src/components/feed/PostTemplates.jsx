import React, { useState } from 'react';
import { Flame, Wrench, Share2, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { motion, AnimatePresence } from 'framer-motion';

export default function PostTemplates({ onSelectTemplate }) {
  const templates = [
    {
      id: 'garage_update',
      name: 'Garage Update',
      description: 'Showcase a new car or garage project',
      icon: Flame,
      color: 'from-cyan-500 to-blue-600'
    },
    {
      id: 'mod_spotlight',
      name: 'Mod Spotlight',
      description: 'Highlight a modification with before/after',
      icon: Wrench,
      color: 'from-amber-500 to-orange-600'
    },
    {
      id: 'ride_share',
      name: 'Ride Share',
      description: 'Offer or request a ride to an event',
      icon: Share2,
      color: 'from-green-500 to-emerald-600'
    },
    {
      id: 'event',
      name: 'Event/Meet',
      description: 'Announce a local meet or track day',
      icon: MapPin,
      color: 'from-purple-500 to-pink-600'
    }
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="grid grid-cols-2 md:grid-cols-4 gap-3"
    >
      {templates.map(template => {
        const Icon = template.icon;
        return (
          <Button
            key={template.id}
            onClick={() => onSelectTemplate(template.id)}
            variant="outline"
            className="border-gray-700 hover:border-cyan-500 h-auto py-4 flex flex-col items-center gap-2"
          >
            <Icon className="w-6 h-6 text-cyan-400" />
            <span className="text-xs font-semibold text-white text-center">{template.name}</span>
          </Button>
        );
      })}
    </motion.div>
  );
}