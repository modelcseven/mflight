import React from 'react';
import { Plus } from 'lucide-react';
import { motion } from 'framer-motion';

export default function StoryCard({ story, isCreateStory, onClick }) {
  if (isCreateStory) {
    return (
      <motion.div
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        onClick={onClick}
        className="relative flex-shrink-0 w-56 h-32 overflow-hidden cursor-pointer bg-gray-950 border border-gray-900"
      >
        <div className="absolute bottom-0 w-full h-12 bg-black flex flex-col items-center justify-end pb-2">
          <div className="absolute -top-3 w-8 h-8 rounded-full bg-white flex items-center justify-center border-2 border-black">
            <Plus className="w-4 h-4 text-black" />
          </div>
          <span className="text-xs text-white mt-2 uppercase tracking-wider">Create</span>
        </div>
        <div className="w-full h-20 bg-gradient-to-br from-gray-900 to-gray-950" />
      </motion.div>
    );
  }

  const bmwImages = [
    'https://images.unsplash.com/photo-1555215695-3004980ad54e?w=800',
    'https://images.unsplash.com/photo-1617531653332-bd46c24f2068?w=800',
    'https://images.unsplash.com/photo-1580273916550-e323be2ae537?w=800',
    'https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?w=800',
    'https://images.unsplash.com/photo-1552820728-8ac41f1ce891?w=800'
  ];
  
  const randomBMWImage = bmwImages[Math.floor(Math.random() * bmwImages.length)];

  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      className="relative flex-shrink-0 w-56 h-32 overflow-hidden cursor-pointer group"
    >
      <img
        src={randomBMWImage}
        alt="Story"
        className="w-full h-full object-cover opacity-70 group-hover:opacity-90 transition-opacity duration-300"
      />
      <div className="absolute inset-0 bg-gradient-to-r from-black/60 via-transparent to-black/20" />
      <div className="absolute top-3 left-3">
        <div className="w-10 h-10 rounded-full border-2 border-white p-0.5 bg-black">
          <img
            src={story.author_avatar || `https://ui-avatars.com/api/?name=${story.author_name}&background=random`}
            alt={story.author_name}
            className="w-full h-full rounded-full object-cover"
          />
        </div>
      </div>
      <span className="absolute bottom-3 left-3 right-3 text-white text-xs font-light truncate uppercase tracking-wider">
        {story.author_name}
      </span>
    </motion.div>
  );
}