import React, { useState } from 'react';
import { Play, Volume2, VolumeX, Maximize2, X } from 'lucide-react';
import { motion } from 'framer-motion';

export default function MediaDisplay({ imageUrl, videoUrl, videoThumbnail, onRemove, isPreview }) {
  const [isMuted, setIsMuted] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const videoRef = React.useRef(null);

  const toggleMute = (e) => {
    e.stopPropagation();
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  const toggleFullscreen = (e) => {
    e.stopPropagation();
    if (videoRef.current?.requestFullscreen) {
      videoRef.current.requestFullscreen();
    }
  };

  if (videoUrl) {
    return (
      <motion.div
        initial={{ opacity: 0, height: 0 }}
        animate={{ opacity: 1, height: 'auto' }}
        exit={{ opacity: 0, height: 0 }}
        className={`relative rounded-lg overflow-hidden bg-black ${isPreview ? '' : ''}`}
      >
        <video
          ref={videoRef}
          src={videoUrl}
          poster={videoThumbnail}
          className={`w-full ${isPreview ? 'max-h-[400px]' : 'max-h-[500px]'} object-cover`}
          controls
          preload="metadata"
          muted={isMuted}
        />

        {/* Video Controls Overlay */}
        {isPreview && (
          <div className="absolute top-2 right-2 flex gap-2 opacity-0 hover:opacity-100 transition-opacity">
            <button
              onClick={toggleMute}
              className="p-2 bg-gray-800/70 rounded-full hover:bg-gray-800 transition-colors"
            >
              {isMuted ? (
                <VolumeX className="w-4 h-4 text-white" />
              ) : (
                <Volume2 className="w-4 h-4 text-white" />
              )}
            </button>
            {onRemove && (
              <button
                onClick={() => onRemove()}
                className="p-2 bg-gray-800/70 rounded-full hover:bg-gray-800 transition-colors"
              >
                <X className="w-4 h-4 text-white" />
              </button>
            )}
          </div>
        )}
      </motion.div>
    );
  }

  if (imageUrl) {
    return (
      <motion.div
        initial={{ opacity: 0, height: 0 }}
        animate={{ opacity: 1, height: 'auto' }}
        exit={{ opacity: 0, height: 0 }}
        className={`relative rounded-lg overflow-hidden`}
      >
        <img src={imageUrl} alt="Preview" className={`w-full ${isPreview ? 'max-h-[400px]' : 'max-h-[500px]'} object-cover`} />
        {onRemove && (
          <button
            onClick={() => onRemove()}
            className="absolute top-2 right-2 p-1 bg-gray-800/70 rounded-full hover:bg-gray-800 transition-colors"
          >
            <X className="w-4 h-4 text-white" />
          </button>
        )}
      </motion.div>
    );
  }

  return null;
}