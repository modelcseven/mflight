import React from 'react';
import StoryCard from './StoryCard';

export default function StoriesRow({ stories, onCreateStory }) {
  return (
    <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
      <StoryCard isCreateStory onClick={onCreateStory} />
      {stories.map((story) => (
        <StoryCard key={story.id} story={story} />
      ))}
    </div>
  );
}