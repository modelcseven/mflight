import React, { useState } from 'react';
import { Image, Video, Smile, X, Upload, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { motion, AnimatePresence } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import MediaDisplay from './MediaDisplay';

export default function CreatePostBox({ user, onPost }) {
  const [isOpen, setIsOpen] = useState(false);
  const [content, setContent] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [videoUrl, setVideoUrl] = useState('');
  const [videoThumbnail, setVideoThumbnail] = useState('');
  const [isPosting, setIsPosting] = useState(false);
  const [isUploadingVideo, setIsUploadingVideo] = useState(false);
  const fileInputRef = React.useRef(null);

  const handlePost = async () => {
    if (!content.trim()) return;
    setIsPosting(true);
    await onPost({
      content,
      image_url: imageUrl || null,
      video_url: videoUrl || null,
      video_thumbnail: videoThumbnail || null,
      author_name: user.full_name,
      author_avatar: user.avatar,
      author_email: user.email,
      likes: [],
      comments: [],
      shares_count: 0
    });
    setContent('');
    setImageUrl('');
    setVideoUrl('');
    setVideoThumbnail('');
    setIsOpen(false);
    setIsPosting(false);
  };

  const handleVideoUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploadingVideo(true);
    try {
      const response = await base44.integrations.Core.UploadFile({ file });
      setVideoUrl(response.file_url);
      
      // Create thumbnail from video
      const video = document.createElement('video');
      video.src = response.file_url;
      video.onloadedmetadata = () => {
        const canvas = document.createElement('canvas');
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        const ctx = canvas.getContext('2d');
        video.currentTime = Math.min(1, video.duration * 0.25);
        video.oncanplay = () => {
          ctx.drawImage(video, 0, 0);
          setVideoThumbnail(canvas.toDataURL());
        };
      };
    } catch (error) {
      console.error('Video upload failed:', error);
    } finally {
      setIsUploadingVideo(false);
    }
  };

  const avatar = user?.avatar || `https://ui-avatars.com/api/?name=${user?.full_name || 'User'}&background=random`;

  return (
    <>
      <div className="bg-gray-950 border border-gray-900 p-6">
        <div className="flex gap-4">
          <img
            src={avatar}
            alt={user?.full_name}
            className="w-10 h-10 rounded-full object-cover"
          />
          <button
            onClick={() => setIsOpen(true)}
            className="flex-1 bg-black hover:bg-gray-900 border border-gray-900 px-4 py-3 text-left text-gray-600 transition-colors text-xs uppercase tracking-wider"
          >
            Share an update...
          </button>
        </div>
        <div className="flex justify-between mt-4 pt-4 border-t border-gray-900">
          <button className="flex items-center gap-2 px-4 py-2 hover:bg-gray-900 transition-colors flex-1 justify-center">
            <Video className="w-4 h-4 text-white" />
            <span className="text-xs font-medium text-white uppercase tracking-wider">Video</span>
          </button>
          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-2 px-4 py-2 hover:bg-gray-900 transition-colors flex-1 justify-center"
          >
            <Image className="w-4 h-4 text-white" />
            <span className="text-xs font-medium text-white uppercase tracking-wider">Photo</span>
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="video/*,image/*"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file?.type.startsWith('video/')) {
                handleVideoUpload(e);
              } else if (file?.type.startsWith('image/')) {
                const reader = new FileReader();
                reader.onload = (event) => {
                  setImageUrl(event.target?.result);
                  setIsOpen(true);
                };
                reader.readAsDataURL(file);
              }
            }}
            hidden
          />
          <button className="flex items-center gap-2 px-4 py-2 hover:bg-gray-900 transition-colors flex-1 justify-center">
            <Smile className="w-4 h-4 text-white" />
            <span className="text-xs font-medium text-white uppercase tracking-wider">Mood</span>
          </button>
        </div>
      </div>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="sm:max-w-lg bg-black border-gray-900">
          <DialogHeader>
            <DialogTitle className="text-center text-xs font-medium text-white uppercase tracking-widest">Create Post</DialogTitle>
          </DialogHeader>
          <div className="flex items-center gap-3 mt-2">
            <img
              src={avatar}
              alt={user?.full_name}
              className="w-10 h-10 rounded-full object-cover"
            />
            <div>
              <p className="font-light text-white text-sm">{user?.full_name}</p>
              <p className="text-xs text-gray-600 uppercase tracking-wider">Public</p>
            </div>
          </div>
          <Textarea
            placeholder={`Share your thoughts...`}
            value={content}
            onChange={(e) => setContent(e.target.value)}
            className="border-none bg-black text-white text-sm resize-none focus-visible:ring-0 min-h-[120px] placeholder-gray-700"
          />
          
          <AnimatePresence>
            {(imageUrl || videoUrl) && (
              <MediaDisplay
                imageUrl={imageUrl}
                videoUrl={videoUrl}
                videoThumbnail={videoThumbnail}
                onRemove={() => {
                  if (videoUrl) {
                    setVideoUrl('');
                    setVideoThumbnail('');
                  } else {
                    setImageUrl('');
                  }
                }}
                isPreview={true}
              />
            )}
          </AnimatePresence>

          <div className="border border-gray-900 p-3 flex items-center justify-between">
            <span className="font-medium text-gray-600 text-xs uppercase tracking-wider">Add Media</span>
            <div className="flex gap-2">
              <button
                onClick={() => fileInputRef.current?.click()}
                disabled={isUploadingVideo}
                className="p-2 hover:bg-gray-900 transition-colors disabled:opacity-50"
              >
                {isUploadingVideo ? (
                  <Loader2 className="w-5 h-5 text-gray-600 animate-spin" />
                ) : (
                  <Image className="w-5 h-5 text-gray-600" />
                )}
              </button>
              <button className="p-2 hover:bg-gray-900 transition-colors">
                <Smile className="w-5 h-5 text-gray-600" />
              </button>
            </div>
          </div>

          <Button
            onClick={handlePost}
            disabled={!content.trim() || isPosting || isUploadingVideo}
            className="w-full bg-white text-black hover:bg-gray-200 font-medium py-2.5 text-xs uppercase tracking-widest"
          >
            {isPosting ? 'Publishing...' : isUploadingVideo ? 'Uploading...' : 'Publish'}
          </Button>
        </DialogContent>
      </Dialog>
    </>
  );
}