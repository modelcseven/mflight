import React, { useState } from 'react';
import { ThumbsUp, MessageCircle, Share2, MoreHorizontal, Globe, Send, Play } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { motion, AnimatePresence } from 'framer-motion';
import { formatDistanceToNow } from 'date-fns';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import MediaDisplay from './MediaDisplay';

export default function PostCard({ post, currentUser, onLike, onComment, onShare, onDelete }) {
  const isOwner = currentUser?.email === post.author_email;
  const [showComments, setShowComments] = useState(false);
  const [commentText, setCommentText] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const isLiked = post.likes?.includes(currentUser?.email);
  // Security: only owner can delete; likes are scoped to currentUser
  const likeCount = post.likes?.length || 0;
  const commentCount = post.comments?.length || 0;

  const handleLike = () => {
    if (!currentUser) return; // must be logged in
    onLike(post, !isLiked); // server uses currentUser.email, never toggling others' likes
  };

  const handleComment = async () => {
    if (!commentText.trim()) return;
    setIsSubmitting(true);
    await onComment(post, {
      author_name: currentUser.full_name,
      author_avatar: currentUser.avatar,
      author_email: currentUser.email,
      content: commentText,
      created_at: new Date().toISOString()
    });
    setCommentText('');
    setIsSubmitting(false);
  };

  const avatar = post.author_avatar || `https://ui-avatars.com/api/?name=${post.author_name}&background=random`;
  const currentUserAvatar = currentUser?.avatar || `https://ui-avatars.com/api/?name=${currentUser?.full_name || 'User'}&background=random`;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-gray-950 border border-gray-900 overflow-hidden"
    >
      {/* Header */}
      <div className="p-6 flex items-start justify-between">
        <div className="flex gap-3">
          <Link to={createPageUrl(`Profile?email=${post.author_email}`)}>
            <img
              src={avatar}
              alt={post.author_name}
              className="w-10 h-10 rounded-full object-cover hover:opacity-90 transition-opacity"
            />
          </Link>
          <div>
            <Link 
              to={createPageUrl(`Profile?email=${post.author_email}`)}
              className="font-light text-white text-sm hover:opacity-80"
            >
              {post.author_name}
            </Link>
            <div className="flex items-center gap-1 text-xs text-gray-600">
              <span className="uppercase tracking-wider">{formatDistanceToNow(new Date(post.created_date), { addSuffix: true })}</span>
              <span>·</span>
              <Globe className="w-3 h-3" />
            </div>
          </div>
        </div>
        {/* Only show delete option to post owner */}
        {isOwner && onDelete && (
          <button
            onClick={() => onDelete(post)}
            className="p-2 hover:bg-gray-900 transition-colors text-gray-600 hover:text-red-500"
            title="Delete post"
          >
            <MoreHorizontal className="w-5 h-5" />
          </button>
        )}
      </div>

      {/* Content */}
      <div className="px-6 pb-4">
        <p className="text-white text-sm whitespace-pre-wrap leading-relaxed">{post.content}</p>
      </div>

      {/* Media - Image or Video */}
      {(post.image_url || post.video_url) && (
        <div className={post.video_url ? 'bg-black' : 'bg-gray-100'}>
          {post.video_url ? (
            <video
              src={post.video_url}
              poster={post.video_thumbnail}
              className="w-full max-h-[500px] object-cover"
              controls
              preload="metadata"
            />
          ) : (
            <img
              src={post.image_url}
              alt="Post"
              className="w-full max-h-[500px] object-cover"
            />
          )}
        </div>
      )}

      {/* Stats */}
      {(likeCount > 0 || commentCount > 0) && (
        <div className="px-6 py-3 flex items-center justify-between text-xs text-gray-600">
          <div className="flex items-center gap-2">
            {likeCount > 0 && (
              <>
                <div className="w-4 h-4 rounded-full bg-white flex items-center justify-center">
                  <ThumbsUp className="w-2.5 h-2.5 text-black fill-black" />
                </div>
                <span className="uppercase tracking-wider">{likeCount}</span>
              </>
            )}
          </div>
          {commentCount > 0 && (
            <button
              onClick={() => setShowComments(!showComments)}
              className="hover:text-white uppercase tracking-wider"
            >
              {commentCount} Comment{commentCount !== 1 && 's'}
            </button>
          )}
        </div>
      )}

      {/* Actions */}
      <div className="px-6 py-2 border-t border-gray-900">
        <div className="flex">
          <button
            onClick={handleLike}
            className={`flex items-center justify-center gap-2 flex-1 py-3 transition-colors ${
              isLiked ? 'text-white' : 'text-gray-600 hover:bg-gray-900'
            }`}
          >
            <ThumbsUp className={`w-4 h-4 ${isLiked ? 'fill-white' : ''}`} />
            <span className="font-medium text-xs uppercase tracking-wider">Like</span>
          </button>
          <button
            onClick={() => setShowComments(!showComments)}
            className="flex items-center justify-center gap-2 flex-1 py-3 text-gray-600 hover:bg-gray-900 transition-colors"
          >
            <MessageCircle className="w-4 h-4" />
            <span className="font-medium text-xs uppercase tracking-wider">Comment</span>
          </button>
          <button
            onClick={() => onShare(post)}
            className="flex items-center justify-center gap-2 flex-1 py-3 text-gray-600 hover:bg-gray-900 transition-colors"
          >
            <Share2 className="w-4 h-4" />
            <span className="font-medium text-xs uppercase tracking-wider">Share</span>
          </button>
        </div>
      </div>

      {/* Comments Section */}
      <AnimatePresence>
        {showComments && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="border-t border-gray-900 overflow-hidden"
          >
            {/* Comments List */}
            <div className="px-6 py-4 space-y-3 max-h-60 overflow-y-auto">
              {post.comments?.map((comment, idx) => (
                <div key={idx} className="flex gap-3">
                  <img
                    src={comment.author_avatar || `https://ui-avatars.com/api/?name=${comment.author_name}&background=random`}
                    alt={comment.author_name}
                    className="w-8 h-8 rounded-full object-cover flex-shrink-0"
                  />
                  <div className="bg-black border border-gray-900 px-4 py-2">
                    <p className="font-light text-xs text-white mb-1">{comment.author_name}</p>
                    <p className="text-xs text-gray-400">{comment.content}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Comment Input */}
            <div className="px-6 py-4 flex gap-3">
              <img
                src={currentUserAvatar}
                alt={currentUser?.full_name}
                className="w-8 h-8 rounded-full object-cover flex-shrink-0"
              />
              <div className="flex-1 flex gap-2">
                <Input
                  placeholder="Add a comment..."
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && handleComment()}
                  className="bg-black border-gray-900 text-white text-xs placeholder-gray-700"
                />
                <Button
                  size="icon"
                  onClick={handleComment}
                  disabled={!commentText.trim() || isSubmitting}
                  className="bg-white text-black hover:bg-gray-200"
                >
                  <Send className="w-3 h-3" />
                </Button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}