import React from 'react';
import { Search, MoreHorizontal, Video, Edit } from 'lucide-react';

export default function RightSidebar({ friends, onStartChat }) {
  return (
    <div className="w-[280px] fixed right-0 top-14 h-[calc(100vh-56px)] overflow-y-auto p-4 hidden xl:block">
      {/* Sponsored */}
      <div className="mb-4">
        <h3 className="text-gray-500 font-semibold text-sm mb-3">Sponsored</h3>
        <div className="space-y-3">
          <div className="flex gap-3 cursor-pointer hover:bg-gray-100 p-2 rounded-lg transition-colors -mx-2">
            <img
              src="https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=100&h=100&fit=crop"
              alt="Ad"
              className="w-28 h-28 rounded-lg object-cover"
            />
            <div>
              <p className="font-medium text-sm text-gray-900">Premium Sneakers</p>
              <p className="text-xs text-gray-500">sneaker-store.com</p>
            </div>
          </div>
        </div>
      </div>

      <div className="border-t border-gray-200 my-4" />

      {/* Contacts */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-gray-500 font-semibold text-sm">Contacts</h3>
          <div className="flex gap-2">
            <button className="p-2 hover:bg-gray-100 rounded-full transition-colors">
              <Video className="w-4 h-4 text-gray-500" />
            </button>
            <button className="p-2 hover:bg-gray-100 rounded-full transition-colors">
              <Search className="w-4 h-4 text-gray-500" />
            </button>
            <button className="p-2 hover:bg-gray-100 rounded-full transition-colors">
              <MoreHorizontal className="w-4 h-4 text-gray-500" />
            </button>
          </div>
        </div>

        <div className="space-y-1">
          {friends?.length > 0 ? (
            friends.map((friend) => (
              <button
                key={friend.email}
                onClick={() => onStartChat?.(friend)}
                className="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-100 transition-colors w-full"
              >
                <div className="relative">
                  <img
                    src={friend.avatar || `https://ui-avatars.com/api/?name=${friend.full_name}&background=random`}
                    alt={friend.full_name}
                    className="w-9 h-9 rounded-full object-cover"
                  />
                  <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white" />
                </div>
                <span className="font-medium text-gray-900 text-sm">{friend.full_name}</span>
              </button>
            ))
          ) : (
            <p className="text-sm text-gray-500 p-2">No contacts yet</p>
          )}
        </div>
      </div>
    </div>
  );
}