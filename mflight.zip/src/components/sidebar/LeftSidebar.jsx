import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { 
  Users, 
  Clock, 
  Bookmark, 
  Flag, 
  Calendar, 
  Film,
  ShoppingBag,
  Gamepad2,
  Heart,
  ChevronDown
} from 'lucide-react';

const menuItems = [
  { icon: Users, label: 'Friends', page: 'Friends' },
  { icon: Clock, label: 'Memories', page: null },
  { icon: Bookmark, label: 'Saved', page: null },
  { icon: Flag, label: 'Pages', page: null },
  { icon: Calendar, label: 'Events', page: null },
  { icon: Film, label: 'Videos', page: null },
  { icon: ShoppingBag, label: 'Marketplace', page: null },
  { icon: Gamepad2, label: 'Gaming', page: null },
  { icon: Heart, label: 'Fundraisers', page: null },
];

export default function LeftSidebar({ user }) {
  const avatar = user?.avatar || `https://ui-avatars.com/api/?name=${user?.full_name || 'User'}&background=random`;

  return (
    <div className="w-[280px] fixed left-0 top-14 h-[calc(100vh-56px)] overflow-y-auto p-2 hidden lg:block">
      <nav className="space-y-1">
        <Link
          to={createPageUrl(`Profile?email=${user?.email}`)}
          className="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-100 transition-colors"
        >
          <img
            src={avatar}
            alt={user?.full_name}
            className="w-9 h-9 rounded-full object-cover"
          />
          <span className="font-medium text-gray-900">{user?.full_name}</span>
        </Link>

        {menuItems.map((item) => {
          const Icon = item.icon;
          const content = (
            <div className="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-100 transition-colors cursor-pointer">
              <div className="w-9 h-9 rounded-full bg-gray-200 flex items-center justify-center">
                <Icon className="w-5 h-5 text-[#1877F2]" />
              </div>
              <span className="font-medium text-gray-900">{item.label}</span>
            </div>
          );

          return item.page ? (
            <Link key={item.label} to={createPageUrl(item.page)}>
              {content}
            </Link>
          ) : (
            <div key={item.label}>{content}</div>
          );
        })}

        <button className="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-100 transition-colors w-full">
          <div className="w-9 h-9 rounded-full bg-gray-200 flex items-center justify-center">
            <ChevronDown className="w-5 h-5 text-gray-800" />
          </div>
          <span className="font-medium text-gray-900">See more</span>
        </button>
      </nav>

      <div className="mt-4 pt-4 border-t border-gray-200">
        <p className="px-2 text-xs text-gray-500">
          Privacy · Terms · Advertising · Cookies · More · Meta © 2024
        </p>
      </div>
    </div>
  );
}