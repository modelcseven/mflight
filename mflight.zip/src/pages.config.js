/**
 * pages.config.js - Page routing configuration
 * 
 * This file is AUTO-GENERATED. Do not add imports or modify PAGES manually.
 * Pages are auto-registered when you create files in the ./pages/ folder.
 * 
 * THE ONLY EDITABLE VALUE: mainPage
 * This controls which page is the landing page (shown when users visit the app).
 * 
 * Example file structure:
 * 
 *   import HomePage from './pages/HomePage';
 *   import Dashboard from './pages/Dashboard';
 *   import Settings from './pages/Settings';
 *   
 *   export const PAGES = {
 *       "HomePage": HomePage,
 *       "Dashboard": Dashboard,
 *       "Settings": Settings,
 *   }
 *   
 *   export const pagesConfig = {
 *       mainPage: "HomePage",
 *       Pages: PAGES,
 *   };
 * 
 * Example with Layout (wraps all pages):
 *
 *   import Home from './pages/Home';
 *   import Settings from './pages/Settings';
 *   import __Layout from './Layout.jsx';
 *
 *   export const PAGES = {
 *       "Home": Home,
 *       "Settings": Settings,
 *   }
 *
 *   export const pagesConfig = {
 *       mainPage: "Home",
 *       Pages: PAGES,
 *       Layout: __Layout,
 *   };
 *
 * To change the main page from HomePage to Dashboard, use find_replace:
 *   Old: mainPage: "HomePage",
 *   New: mainPage: "Dashboard",
 *
 * The mainPage value must match a key in the PAGES object exactly.
 */
import Admin from './pages/Admin';
import AdminAPIs from './pages/AdminAPIs';
import AdminCMS from './pages/AdminCMS';
import AdminCRM from './pages/AdminCRM';
import AdminDashboard from './pages/AdminDashboard';
import AdminMarketing from './pages/AdminMarketing';
import AdminTuners from './pages/AdminTuners';
import BMWHUD from './pages/BMWHUD';
import BMWModels from './pages/BMWModels';
import Bio from './pages/Bio';
import CarDetail from './pages/CarDetail';
import CommunityMap from './pages/CommunityMap';
import Events from './pages/Events';
import Friends from './pages/Friends';
import Garage from './pages/Garage';
import GarageDetail from './pages/GarageDetail';
import Garages from './pages/Garages';
import Groups from './pages/Groups';
import Home from './pages/Home';
import JoinTheClub from './pages/JoinTheClub';
import Landing from './pages/Landing';
import Marketplace from './pages/Marketplace';
import Messages from './pages/Messages';
import Notifications from './pages/Notifications';
import Performance from './pages/Performance';
import PerformanceDashboard from './pages/PerformanceDashboard';
import Profile from './pages/Profile';
import ProfileSetup from './pages/ProfileSetup';
import SignIn from './pages/SignIn';
import TunerDirectory from './pages/TunerDirectory';
import __Layout from './Layout.jsx';


export const PAGES = {
    "Admin": Admin,
    "AdminAPIs": AdminAPIs,
    "AdminCMS": AdminCMS,
    "AdminCRM": AdminCRM,
    "AdminDashboard": AdminDashboard,
    "AdminMarketing": AdminMarketing,
    "AdminTuners": AdminTuners,
    "BMWHUD": BMWHUD,
    "BMWModels": BMWModels,
    "Bio": Bio,
    "CarDetail": CarDetail,
    "CommunityMap": CommunityMap,
    "Events": Events,
    "Friends": Friends,
    "Garage": Garage,
    "GarageDetail": GarageDetail,
    "Garages": Garages,
    "Groups": Groups,
    "Home": Home,
    "JoinTheClub": JoinTheClub,
    "Landing": Landing,
    "Marketplace": Marketplace,
    "Messages": Messages,
    "Notifications": Notifications,
    "Performance": Performance,
    "PerformanceDashboard": PerformanceDashboard,
    "Profile": Profile,
    "ProfileSetup": ProfileSetup,
    "SignIn": SignIn,
    "TunerDirectory": TunerDirectory,
}

export const pagesConfig = {
    mainPage: "Home",
    Pages: PAGES,
    Layout: __Layout,
};